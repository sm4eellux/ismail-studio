/* APEX FITNESS — contact form: validation, summary, optional EmailJS. Never fakes delivery. */
document.addEventListener('DOMContentLoaded', function () {
  var C = window.SITE_CONFIG, f = document.getElementById('contact-form'); if (!f) return;
  var out = document.getElementById('form-result'), qs = new URLSearchParams(location.search);
  if (qs.get('subject')) f.subject.value = qs.get('subject');
  if (qs.get('plan')) { var pl = C.plans.filter(function (p) { return p.id === qs.get('plan'); })[0]; if (pl) f.subject.value = 'Membership inquiry — ' + pl.name; }

  var rules = {
    name: function (v) { return v.length >= 2 ? '' : 'Please enter your full name.'; },
    email: function (v) { return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v) ? '' : 'Please enter a valid email address.'; },
    phone: function (v) { return /^\+?[0-9\s().-]{7,18}$/.test(v) && v.replace(/\D/g, '').length >= 7 ? '' : 'Please enter a valid phone number (7–15 digits).'; },
    subject: function (v) { return v.length >= 3 ? '' : 'Please add a subject.'; },
    message: function (v) { return v.length >= 10 ? '' : 'Your message should be at least 10 characters.'; }
  };
  var check = function (el) {
    var err = rules[el.name](el.value.trim()), box = el.parentNode.querySelector('.err');
    el.setAttribute('aria-invalid', !!err); box.textContent = err; return !err;
  };
  f.querySelectorAll('input,textarea').forEach(function (el) { el.addEventListener('blur', function () { check(el); }); el.addEventListener('input', function () { if (el.getAttribute('aria-invalid') === 'true') check(el); }); });

  var ready = C.emailjs.publicKey && C.emailjs.serviceId && C.emailjs.templateId;
  var show = function (cls, html) { out.className = 'result ' + cls; out.innerHTML = html; out.hidden = false; out.focus(); };

  f.addEventListener('submit', function (e) {
    e.preventDefault();
    var ok = true, first; [].forEach.call(f.querySelectorAll('input,textarea'), function (el) { if (!check(el) && ok) { ok = false; first = el; } });
    if (!ok) { first.focus(); return; }
    var d = { name: f.name.value.trim(), email: f.email.value.trim(), phone: f.phone.value.trim(), subject: f.subject.value.trim(), message: f.message.value.trim() };
    var E = window.esc, summary = '<dl><dt>Name</dt><dd>' + E(d.name) + '</dd><dt>Email</dt><dd>' + E(d.email) + '</dd><dt>Phone</dt><dd>' + E(d.phone) + '</dd><dt>Subject</dt><dd>' + E(d.subject) + '</dd><dt>Message</dt><dd>' + E(d.message) + '</dd></dl>';
    var mail = 'mailto:' + C.contact.email + '?subject=' + encodeURIComponent(d.subject) + '&body=' + encodeURIComponent(d.message + '\n\n' + d.name + ' · ' + d.phone);
    var wa = 'https://wa.me/' + C.whatsappNumber + '?text=' + encodeURIComponent(d.subject + ' — ' + d.message + ' (' + d.name + ')');
    if (!ready) {
      show('result--warn', '<h3>Message not sent</h3><p>Email sending is not configured on this demo site, so nothing was delivered. Add your EmailJS keys in <code>js/config.js</code>, or use an alternative:</p><p class="btn-row"><a class="btn btn--solid" href="' + mail + '">Send by email</a><a class="btn" href="' + wa + '" target="_blank" rel="noopener">Send on WhatsApp</a></p><h4>Your details</h4>' + summary);
      return;
    }
    var btn = f.querySelector('button[type=submit]'); btn.disabled = true; btn.textContent = 'Sending…';
    var s = document.createElement('script'); s.src = 'https://cdn.jsdelivr.net/npm/@emailjs/browser@4/dist/email.min.js';
    s.onload = function () {
      emailjs.send(C.emailjs.serviceId, C.emailjs.templateId, d, { publicKey: C.emailjs.publicKey }).then(function () {
        show('result--ok', '<h3>Message sent</h3><p>Thank you — we will reply soon.</p>' + summary); f.reset(); btn.disabled = false; btn.textContent = 'Send message';
      }, function () { show('result--warn', '<h3>Sending failed</h3><p>Please use an alternative:</p><p class="btn-row"><a class="btn btn--solid" href="' + mail + '">Email</a><a class="btn" href="' + wa + '" target="_blank" rel="noopener">WhatsApp</a></p>'); btn.disabled = false; btn.textContent = 'Send message'; });
    };
    s.onerror = function () { show('result--warn', '<h3>Could not load the email service</h3><p class="btn-row"><a class="btn btn--solid" href="' + mail + '">Email</a></p>'); btn.disabled = false; btn.textContent = 'Send message'; };
    document.head.appendChild(s);
  });
  var wl = document.getElementById('wa-link'); if (wl) wl.href = 'https://wa.me/' + C.whatsappNumber;
});

/* Fill the contact details block from config.js (single place to edit) */
document.addEventListener('DOMContentLoaded', function () {
  var C = window.SITE_CONFIG, t = function (id, v) { var e = document.getElementById(id); if (e) e.textContent = v; };
  t('c-addr', C.contact.address.join(', ')); t('c-phone', C.contact.phone); t('c-mail', C.contact.email);
  t('c-hours', C.hours.map(function (h) { return h.days + ' ' + h.time; }).join(' · '));
  var set = function (id, href) { var e = document.getElementById(id); if (e) e.href = href; };
  set('c-mail', 'mailto:' + C.contact.email); set('c-ig', C.contact.instagram); set('c-map', C.contact.mapsLink);
});
