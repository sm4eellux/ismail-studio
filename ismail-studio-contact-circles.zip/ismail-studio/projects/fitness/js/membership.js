/* APEX FITNESS — membership selection, summary and FAQ accordion. No payment processing. */
document.addEventListener('DOMContentLoaded', function () {
  var C = window.SITE_CONFIG, wrap = document.getElementById('plans'), sum = document.getElementById('summary');
  var select = function (id) {
    var p = C.plans.filter(function (x) { return x.id === id; })[0]; if (!p) return;
    wrap.querySelectorAll('.plan').forEach(function (el) { el.classList.toggle('is-selected', el.dataset.plan === id); });
    sum.hidden = false;
    sum.querySelector('[data-name]').textContent = p.name;
    sum.querySelector('[data-price]').textContent = '$' + p.price + ' / month (demo price)';
    sum.querySelector('[data-feats]').innerHTML = p.features.map(function (f) { return '<li>' + window.esc(f) + '</li>'; }).join('');
    sum.querySelector('a').href = 'contact.html?plan=' + id;
    sum.classList.remove('pop'); void sum.offsetWidth; sum.classList.add('pop');
  };
  window.renderPlans(wrap, select);
  window.initReveal(wrap);
  var pre = new URLSearchParams(location.search).get('plan'); if (pre) select(pre);

  /* Comparison table */
  var feats = ['Gym access', 'Locker access', 'Group classes', 'Fitness assessment', 'Personal training sessions', 'Priority class booking'];
  var has = { basic: [1,1,0,0,0,0], premium: [1,1,1,1,0,0], elite: [1,1,1,1,1,1] };
  document.getElementById('compare').innerHTML = '<table><thead><tr><th scope="col">Feature</th>' + C.plans.map(function (p) { return '<th scope="col">' + p.name + '</th>'; }).join('') + '</tr></thead><tbody>' +
    feats.map(function (f, i) { return '<tr><th scope="row">' + f + '</th>' + C.plans.map(function (p) { return '<td>' + (has[p.id][i] ? '<span class="yes" aria-label="Included">✓</span>' : '<span class="no" aria-label="Not included">—</span>') + '</td>'; }).join('') + '</tr>'; }).join('') + '</tbody></table>';

  /* FAQ accordion */
  document.querySelectorAll('.faq__q').forEach(function (b) {
    b.addEventListener('click', function () {
      var open = b.getAttribute('aria-expanded') === 'true', a = document.getElementById(b.getAttribute('aria-controls'));
      b.setAttribute('aria-expanded', !open); a.hidden = open;
    });
  });
});
