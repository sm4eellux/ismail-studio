/* APEX FITNESS — program data + filtering/search/modal.
   To add a program: copy one object in PROGRAMS and edit it. `cat` must match a filter below. */
window.PROGRAMS = [
  { id: 'strength', cat: 'Strength', title: 'Strength Training', level: 'All levels', img: 'photo-1534438327276-14e5300c3a48',
    short: 'Resistance training focused on building raw, lasting strength.',
    long: 'Progressive barbell and dumbbell work built around the main lifts, with technique coaching and clear progression.',
    benefits: ['Greater maximal strength', 'Better movement technique', 'Structured progression'] },
  { id: 'muscle', cat: 'Strength', title: 'Muscle Building', level: 'Intermediate', img: 'photo-1581009146145-b5ef050c2e1e',
    short: 'Structured resistance sessions designed for muscle development.',
    long: 'Split-based training that balances volume, intensity and recovery to support steady muscle growth.',
    benefits: ['Targeted muscle development', 'Planned weekly volume', 'Recovery guidance'] },
  { id: 'functional', cat: 'Functional', title: 'Functional Training', level: 'All levels', img: 'photo-1517836357463-d25dfeac3438',
    short: 'Improve movement, coordination and everyday physical performance.',
    long: 'Full-body patterns using kettlebells, sleds and bodyweight to make strength useful outside the gym.',
    benefits: ['Better coordination', 'Everyday strength', 'Balanced conditioning'] },
  { id: 'cardio', cat: 'Conditioning', title: 'Cardio Training', level: 'Beginner', img: 'photo-1571019613454-1cb2f99b2d8b',
    short: 'Develop cardiovascular endurance at a pace that suits you.',
    long: 'Steady-state and interval sessions on rowers, bikes and treadmills with heart-rate based pacing.',
    benefits: ['Improved endurance', 'Pacing you can sustain', 'Low-impact options'] },
  { id: 'hiit', cat: 'Conditioning', title: 'HIIT Training', level: 'Intermediate', img: 'photo-1518611012118-696072aa579a',
    short: 'High-intensity intervals adapted to different fitness levels.',
    long: 'Short, structured work-and-rest rounds with scaling options so every level can train hard safely.',
    benefits: ['Time-efficient sessions', 'Scalable intensity', 'Group energy'] },
  { id: 'mobility', cat: 'Mobility', title: 'Mobility & Flexibility', level: 'All levels', img: 'photo-1599058917212-d750089bc07e',
    short: 'Improve mobility and movement quality.',
    long: 'Guided flows and controlled stretching that restore range of motion and support the rest of your training.',
    benefits: ['Greater range of motion', 'Better movement quality', 'Training recovery'] }
];

(function () {
  var data = window.PROGRAMS, esc = window.esc || String;
  var card = function (p) {
    return '<article class="pcard reveal" data-id="' + p.id + '"><div class="pcard__img"><img loading="lazy" src="' + window.U(p.img, 800) + '" alt="' + esc(p.title) + ' session at APEX FITNESS"></div>' +
      '<div class="pcard__body"><span class="chip">' + p.level + '</span><h3>' + p.title + '</h3><p class="muted">' + p.short + '</p>' +
      '<ul class="ticks">' + p.benefits.slice(0, 2).map(function (b) { return '<li>' + b + '</li>'; }).join('') + '</ul>' +
      '<button class="link" data-more="' + p.id + '">Learn more</button></div></article>';
  };
  var openMore = function (id) {
    var p = data.filter(function (x) { return x.id === id; })[0]; if (!p) return;
    window.openModal('<img class="modal__img" src="' + window.U(p.img, 900) + '" alt="' + esc(p.title) + '"><div class="modal__body"><span class="chip">' + p.level + ' · ' + p.cat + '</span><h3>' + p.title + '</h3><p>' + p.long + '</p><ul class="ticks">' + p.benefits.map(function (b) { return '<li>' + b + '</li>'; }).join('') + '</ul><a class="btn btn--solid" href="contact.html?subject=' + encodeURIComponent(p.title) + '">Ask about this program</a></div>');
  };
  var bind = function (root) { root.querySelectorAll('[data-more]').forEach(function (b) { b.addEventListener('click', function () { openMore(b.dataset.more); }); }); };

  document.addEventListener('DOMContentLoaded', function () {
    var feat = document.getElementById('featured-programs');
    if (feat) { feat.innerHTML = data.slice(0, 4).map(card).join(''); bind(feat); window.guardImages(feat); window.initReveal(feat); }
    var grid = document.getElementById('program-grid'); if (!grid) return;
    var cats = ['All'].concat(data.map(function (p) { return p.cat; }).filter(function (c, i, a) { return a.indexOf(c) === i; }));
    var bar = document.getElementById('program-filters'), q = document.getElementById('program-search'), empty = document.getElementById('program-empty');
    var state = { cat: 'All', q: '' };
    bar.innerHTML = cats.map(function (c) { return '<button class="filter" aria-pressed="' + (c === 'All') + '" data-cat="' + c + '">' + c + '</button>'; }).join('');
    var render = function () {
      var list = data.filter(function (p) { return (state.cat === 'All' || p.cat === state.cat) && (p.title + ' ' + p.short + ' ' + p.cat).toLowerCase().indexOf(state.q) > -1; });
      grid.classList.add('is-swapping');
      setTimeout(function () {
        grid.innerHTML = list.map(card).join(''); bind(grid); window.guardImages(grid); window.initReveal(grid);
        grid.classList.remove('is-swapping'); empty.hidden = list.length > 0;
        document.getElementById('program-count').textContent = list.length + (list.length === 1 ? ' program' : ' programs');
      }, 160);
    };
    bar.addEventListener('click', function (e) { var b = e.target.closest('[data-cat]'); if (!b) return; state.cat = b.dataset.cat; bar.querySelectorAll('.filter').forEach(function (f) { f.setAttribute('aria-pressed', f === b); }); render(); });
    q.addEventListener('input', function () { state.q = q.value.trim().toLowerCase(); render(); });
    render();
  });
})();
