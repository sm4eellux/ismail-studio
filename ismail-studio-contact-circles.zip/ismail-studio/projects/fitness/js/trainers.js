/* APEX FITNESS — FICTIONAL trainer profiles (demo content only; no real people or credentials). */
window.TRAINERS = [
  { id: 't1', name: 'Adam Lorenz', cat: 'Strength', role: 'Strength & Conditioning', img: 'photo-1567013127542-490d757e51fc',
    bio: 'Fictional coach who builds simple, progressive strength programs.', philosophy: 'Master the basics, then add load patiently.' },
  { id: 't2', name: 'Maya Chen', cat: 'Muscle', role: 'Muscle Development', img: 'photo-1594381898411-846e7d193883',
    bio: 'Fictional coach focused on structured hypertrophy training.', philosophy: 'Consistency beats intensity for a single week.' },
  { id: 't3', name: 'Leo Marin', cat: 'Functional', role: 'Functional Training', img: 'photo-1548690312-e3b507d8c110',
    bio: 'Fictional coach who turns gym strength into everyday capability.', philosophy: 'Train movement, not just muscles.' },
  { id: 't4', name: 'Sara Bell', cat: 'Mobility', role: 'Mobility & Performance', img: 'photo-1583454110551-21f2fa2afe61',
    bio: 'Fictional coach helping members move freely and recover well.', philosophy: 'Better range of motion makes every lift safer.' }
];
(function () {
  var data = window.TRAINERS, esc = window.esc || String, ig = (window.SITE_CONFIG || {}).contact;
  var social = '<div class="social"><a href="' + ig.instagram + '" target="_blank" rel="noopener">Instagram</a><a href="https://wa.me/' + window.SITE_CONFIG.whatsappNumber + '" target="_blank" rel="noopener">WhatsApp</a></div>';
  var card = function (t, i) {
    return '<article class="tcard reveal' + (i % 2 ? ' tcard--down' : '') + '"><button class="tcard__btn" data-t="' + t.id + '" aria-label="View profile of ' + esc(t.name) + '"><img loading="lazy" src="' + window.U(t.img, 700) + '" alt="Portrait of fictional trainer ' + esc(t.name) + '"><span class="tcard__info"><small>' + t.role + '</small><b>' + t.name + '</b></span></button></article>';
  };
  var bind = function (root) { root.querySelectorAll('[data-t]').forEach(function (b) { b.addEventListener('click', function () {
    var t = data.filter(function (x) { return x.id === b.dataset.t; })[0];
    window.openModal('<img class="modal__img" src="' + window.U(t.img, 800) + '" alt="Portrait of fictional trainer ' + esc(t.name) + '"><div class="modal__body"><span class="chip">' + t.role + '</span><h3>' + t.name + '</h3><p>' + t.bio + '</p><p class="muted"><b>Philosophy:</b> ' + t.philosophy + '</p><p class="muted small">Fictional demonstration profile.</p>' + social + '</div>');
  }); }); };
  document.addEventListener('DOMContentLoaded', function () {
    var prev = document.getElementById('trainer-preview');
    if (prev) { prev.innerHTML = data.map(card).join(''); bind(prev); window.guardImages(prev); window.initReveal(prev); }
    var grid = document.getElementById('trainer-grid'); if (!grid) return;
    var bar = document.getElementById('trainer-filters'), cats = ['All'].concat(data.map(function (t) { return t.cat; }));
    bar.innerHTML = cats.map(function (c) { return '<button class="filter" aria-pressed="' + (c === 'All') + '" data-cat="' + c + '">' + c + '</button>'; }).join('');
    var render = function (cat) {
      grid.classList.add('is-swapping');
      setTimeout(function () { grid.innerHTML = data.filter(function (t) { return cat === 'All' || t.cat === cat; }).map(card).join(''); bind(grid); window.guardImages(grid); window.initReveal(grid); grid.classList.remove('is-swapping'); }, 160);
    };
    bar.addEventListener('click', function (e) { var b = e.target.closest('[data-cat]'); if (!b) return; bar.querySelectorAll('.filter').forEach(function (f) { f.setAttribute('aria-pressed', f === b); }); render(b.dataset.cat); });
    render('All');
  });
})();
