/* ==========================================================================
   APEX FITNESS — SITE CONFIGURATION
   Edit this single file to change contact details, hours, WhatsApp number,
   EmailJS credentials and membership plans. All values are FICTIONAL DEMO
   PLACEHOLDERS (demonstration project by ISMAIL.STUDIO).
   ========================================================================== */
window.SITE_CONFIG = {
  brand: { name: "APEX FITNESS", demoNotice: "Demonstration project — all content is fictional." },
  contact: {
    address: ["00 Example Avenue", "Your City, Country"],      // placeholder
    phone: "+00 000 000 000",                                   // placeholder
    email: "hello@example.com",                                 // placeholder
    instagram: "https://www.instagram.com/",                    // replace with a real profile
    mapsLink: "https://www.google.com/maps/search/?api=1&query=gym"
  },
  // International format, digits only (e.g. "212600000000"). Placeholder until you set a real one.
  whatsappNumber: "000000000000",
  hours: [
    { days: "Monday – Friday", time: "05:30 – 23:00" },
    { days: "Saturday", time: "07:00 – 21:00" },
    { days: "Sunday", time: "08:00 – 18:00" }
  ],
  /* EmailJS (optional): the form only sends if ALL three values are filled. */
  emailjs: { publicKey: "", serviceId: "", templateId: "" },

  /* Membership plans — fictional demo prices. */
  plans: [
    { id: "basic", name: "Basic", price: 29, blurb: "Everything you need to start training.",
      features: ["Gym access", "Standard equipment", "Locker access", "Flexible training"] },
    { id: "premium", name: "Premium", price: 49, featured: true, blurb: "The complete APEX experience.",
      features: ["Unlimited gym access", "All training equipment", "Group classes", "Fitness assessment", "Locker access"] },
    { id: "elite", name: "Elite", price: 79, blurb: "Coached progress, priority access.",
      features: ["Everything in Premium", "Personal training sessions", "Priority class booking", "Personalized fitness guidance"] }
  ]
};
