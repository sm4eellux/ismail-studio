/* APEX FITNESS — shared behaviour: header/footer, reveal, modal, image fallback */
(function () {
  var C = window.SITE_CONFIG, doc = document, page = doc.body.dataset.page;
  doc.documentElement.classList.add('js');
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* Unsplash helper: window.U('photo-id', width) */
  window.U = function (id, w) { return 'https://images.unsplash.com/' + id + '?auto=format&fit=crop&w=' + (w || 1200) + '&q=70'; };
  window.esc = function (s) { return String(s).replace(/[&<>"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); };

  /* Replace any image that fails to load with the local fallback (never a broken image) */
  window.guardImages = function (root) {
    (root || doc).querySelectorAll('img').forEach(function (img) {
      var fix = function () { if (!img.dataset.failed) { img.dataset.failed = 1; img.src = 'assets/images/fallback.svg'; } };
      img.addEventListener('error', fix);
      if (img.complete && img.naturalWidth === 0 && img.src) fix();
    });
  };

  var links = [['index.html','Home','home'],['membership.html','Membership','membership'],['programs.html','Programs','programs'],['trainers.html','Trainers','trainers'],['about.html','About','about'],['contact.html','Contact','contact']];
  var nav = links.map(function (l) { return '<a href="' + l[0] + '"' + (l[2] === page ? ' class="is-active" aria-current="page"' : '') + '>' + l[1] + '</a>'; }).join('');
  var header = doc.getElementById('site-header');
  if (header) header.innerHTML =
    '<div class="container nav"><a class="logo" href="index.html" aria-label="APEX FITNESS home">APEX<span>FITNESS</span></a>' +
    '<nav id="nav-links" class="nav__links" aria-label="Main">' + nav + '</nav>' +
    '<a class="btn btn--solid nav__cta" href="membership.html">Join Now</a>' +
    '<button class="nav__toggle" aria-label="Open menu" aria-expanded="false" aria-controls="nav-links"><span></span><span></span></button></div>';
  var footer = doc.getElementById('site-footer');
  if (footer) footer.innerHTML =
    '<div class="container footer__grid"><div><a class="logo" href="index.html">APEX<span>FITNESS</span></a><p class="muted">Train with purpose. A fictional premium fitness club.</p></div>' +
    '<div><h4>Navigate</h4><nav class="footer__nav">' + nav.replace(/ class="is-active" aria-current="page"/g, '') + '</nav></div>' +
    '<div><h4>Opening hours</h4><ul class="muted">' + C.hours.map(function (h) { return '<li>' + h.days + ' — ' + h.time + '</li>'; }).join('') + '</ul></div>' +
    '<div><h4>Contact</h4><ul class="muted"><li>' + C.contact.address.join(', ') + '</li><li>' + C.contact.phone + '</li><li><a href="mailto:' + C.contact.email + '">' + C.contact.email + '</a></li>' +
    '<li><a href="' + C.contact.instagram + '" target="_blank" rel="noopener">Instagram</a> · <a href="https://wa.me/' + C.whatsappNumber + '" target="_blank" rel="noopener">WhatsApp</a></li></ul></div></div>' +
    '<div class="container footer__legal">© <span id="yr"></span> APEX FITNESS — ' + C.brand.demoNotice + ' Built by <a href="../../index.html">ISMAIL.STUDIO</a>.</div>';
  var yr = doc.getElementById('yr'); if (yr) yr.textContent = new Date().getFullYear();

  /* Header scroll state + mobile menu */
  var onScroll = function () { header && header.classList.toggle('is-solid', window.scrollY > 40); };
  onScroll(); window.addEventListener('scroll', onScroll, { passive: true });
  var tg = doc.querySelector('.nav__toggle');
  if (tg) {
    var setMenu = function (open) { header.classList.toggle('menu-open', open); tg.setAttribute('aria-expanded', open); doc.body.classList.toggle('no-scroll', open); };
    tg.addEventListener('click', function () { setMenu(!header.classList.contains('menu-open')); });
    doc.getElementById('nav-links').addEventListener('click', function (e) { if (e.target.tagName === 'A') setMenu(false); });
    doc.addEventListener('keydown', function (e) { if (e.key === 'Escape') setMenu(false); });
  }

  /* Shared plan cards: <div data-plans="preview"> or renderPlans(el, onSelect) */
  window.renderPlans = function (el, onSelect) {
    el.innerHTML = C.plans.map(function (p) {
      return '<article class="plan reveal' + (p.featured ? ' plan--featured' : '') + '" data-plan="' + p.id + '">' +
        (p.featured ? '<span class="plan__tag">Recommended</span>' : '') +
        '<h3>' + p.name + '</h3><p class="muted">' + p.blurb + '</p><p class="plan__price"><b>$' + p.price + '</b>/month</p>' +
        '<ul>' + p.features.map(function (f) { return '<li>' + f + '</li>'; }).join('') + '</ul>' +
        '<button class="btn ' + (p.featured ? 'btn--solid' : '') + '" data-select="' + p.id + '">Select ' + p.name + '</button></article>';
    }).join('');
    el.querySelectorAll('[data-select]').forEach(function (b) {
      b.addEventListener('click', function () { onSelect ? onSelect(b.dataset.select) : (location.href = 'membership.html?plan=' + b.dataset.select); });
    });
  };
  doc.querySelectorAll('[data-plans="preview"]').forEach(function (el) { window.renderPlans(el); });

  /* Modal (focus-managed) */
  window.openModal = function (html) {
    var last = doc.activeElement, m = doc.createElement('div');
    m.className = 'modal'; m.innerHTML = '<div class="modal__box" role="dialog" aria-modal="true" tabindex="-1"><button class="modal__close" aria-label="Close">×</button>' + html + '</div>';
    doc.body.appendChild(m); doc.body.classList.add('no-scroll'); window.guardImages(m);
    var box = m.firstChild, key = function (e) { if (e.key === 'Escape') close(); };
    function close() { m.remove(); doc.body.classList.remove('no-scroll'); doc.removeEventListener('keydown', key); last && last.focus(); }
    doc.addEventListener('keydown', key);
    m.addEventListener('click', function (e) { if (e.target === m || e.target.className === 'modal__close') close(); });
    requestAnimationFrame(function () { m.classList.add('is-open'); box.focus(); });
  };

  /* Scroll reveal (IntersectionObserver; static when reduced motion is requested) */
  window.initReveal = function (root) {
    var items = [].slice.call((root || doc).querySelectorAll('.reveal:not(.in)'));
    if (reduce || !('IntersectionObserver' in window)) { items.forEach(function (i) { i.classList.add('in'); }); return; }
    var io = new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }); }, { threshold: 0.12 });
    items.forEach(function (i) { io.observe(i); });
  };

  window.addEventListener('DOMContentLoaded', function () {
    window.guardImages(); window.initReveal();
    /* Hero entrance + subtle parallax (GSAP optional; CSS fallback otherwise) */
    var hero = doc.querySelector('.hero');
    if (hero && window.gsap && !reduce) {
      gsap.from('.hero .line > span', { yPercent: 110, duration: 1, stagger: 0.12, ease: 'power4.out', delay: 0.15 });
      gsap.from('.hero .fade', { y: 24, opacity: 0, duration: 0.9, stagger: 0.12, delay: 0.7, ease: 'power3.out' });
      if (window.ScrollTrigger) { gsap.registerPlugin(ScrollTrigger); gsap.to('.hero__bg img', { yPercent: 12, ease: 'none', scrollTrigger: { trigger: hero, start: 'top top', scrub: true } }); }
    } else if (hero) { hero.classList.add('hero--static'); }
    /* Counters */
    doc.querySelectorAll('[data-count]').forEach(function (el) {
      var to = +el.dataset.count; if (reduce) { el.textContent = to; return; }
      new IntersectionObserver(function (es, o) { if (es[0].isIntersecting) { o.disconnect(); var t0 = performance.now(); (function s(t) { var p = Math.min((t - t0) / 1200, 1); el.textContent = Math.round(to * (1 - Math.pow(1 - p, 3))); if (p < 1) requestAnimationFrame(s); })(t0); } }).observe(el);
    });
  });
})();
