/* ==========================================================================
   NEXORA — insights.js
   EDIT ARTICLES HERE. Each article is one object in ARTICLES.
   Renders: featured article, article grid, category filter, search, article
   reader (modal) with related articles, and the 3-article home teaser.
   All editorial content is FICTIONAL demonstration content.
   ========================================================================== */
(function () {
  "use strict";
  var NX = window.NX || {};
  var esc = NX.esc, $ = NX.$, $$ = NX.$$;

  var CATEGORIES = ["Business Strategy", "Technology", "Innovation", "Leadership", "Digital Transformation", "Market Trends"];

  var ARTICLES = [
    { id: "planning-for-multiple-futures", category: "Business Strategy", featured: true, date: "2026-11-04", read: 7,
      title: "Strategy in an Age of Uncertainty: Planning for Multiple Futures",
      excerpt: "Single-point forecasts rarely survive contact with reality. Scenario-based planning helps leadership teams stay decisive without pretending to know what comes next.",
      author: "Elena Marchetti", image: "assets/illustrations/article-1.svg",
      body: ["Most strategic plans are built around one expected future. That makes them easy to communicate and easy to approve, but fragile the moment conditions change. Scenario-based planning starts from a different premise: that several plausible futures deserve to be taken seriously at the same time.",
        "The goal is not to predict which scenario will occur. It is to identify the moves that make sense in most of them, the options worth keeping open, and the early signals that tell you which way the world is heading.",
        "In practice, this means agreeing on two or three critical uncertainties, describing the futures they create, and testing your current strategy against each one. Teams usually discover a small set of 'no-regret' decisions and a handful of bets that need explicit triggers.",
        "Finally, build the discipline of revisiting scenarios on a regular rhythm. Strategy then becomes a living conversation rather than an annual document."] },
    { id: "why-digital-transformations-stall", category: "Digital Transformation", date: "2026-10-21", read: 6,
      title: "Beyond the Pilot: Why Digital Transformations Stall and How to Keep Them Moving",
      excerpt: "Promising pilots are easy to start and hard to scale. Four patterns explain most stalled programs, and each has a practical remedy.",
      author: "Sofia Lindqvist", image: "assets/illustrations/article-2.svg",
      body: ["Many organizations can point to a successful digital pilot. Far fewer can point to a transformation that reached the whole business. The gap is rarely about technology; it is about ownership, sequencing and adoption.",
        "The first pattern is unclear ownership: when everyone sponsors a program, nobody is accountable for outcomes. The second is a mismatch between pilot conditions and everyday reality, so results do not carry over.",
        "The third is underinvestment in the people side, including training, role changes and communication. The fourth is measuring activity instead of outcomes, which hides the point where value stops flowing.",
        "Remedies are straightforward but demand discipline: name a single accountable owner, design pilots under realistic conditions, fund adoption as seriously as build, and track a small set of outcome measures from day one."] },
    { id: "technology-roadmap-leaders-can-fund", category: "Technology", date: "2026-10-07", read: 5,
      title: "The Technology Roadmap Leaders Can Actually Fund",
      excerpt: "A roadmap full of platforms and acronyms rarely wins budget. Here is how to express technology plans in the language of business outcomes.",
      author: "Marcus Tanaka", image: "assets/illustrations/article-3.svg",
      body: ["Technology roadmaps often fail at the approval stage for a simple reason: they describe what will be built, not why it matters. Executives fund outcomes, risk reduction and capability, not components.",
        "Start by linking every initiative to a business objective, and be explicit about the decision it enables or the cost it removes. Group work into a few themes that leadership can recognize.",
        "Then show sequencing and dependencies honestly. A roadmap that acknowledges trade-offs builds more trust than one that promises everything at once.",
        "Finally, define how progress will be reported. Clear milestones and a small set of indicators make funding conversations easier every quarter."] },
    { id: "innovation-is-a-system", category: "Innovation", date: "2026-09-23", read: 6,
      title: "Innovation Is a System, Not a Moment",
      excerpt: "Breakthrough ideas get the attention, but sustained innovation depends on routines, incentives and a clear path from idea to impact.",
      author: "Priya Raman", image: "assets/illustrations/article-4.svg",
      body: ["When organizations talk about innovation, they often picture a workshop, a hackathon or a flash of insight. Those moments matter, but they are the visible tip of a much larger system.",
        "A healthy innovation system has four parts: a way to surface ideas, a method for testing them cheaply, a process for deciding what to scale, and leaders who protect time and attention for the work.",
        "Without the later stages, early enthusiasm turns into cynicism. Without the earlier stages, the pipeline dries up. The system only works when every stage is owned.",
        "Start small: pick one problem worth solving, run a short experiment, and be transparent about what you learn. Repeated often, that rhythm builds the capability."] },
    { id: "five-habits-of-resilient-leadership-teams", category: "Leadership", date: "2026-09-09", read: 5,
      title: "Leading Through Change: Five Habits of Resilient Leadership Teams",
      excerpt: "Change tests leadership teams more than any plan. Resilient teams share a handful of observable habits that anyone can start practicing.",
      author: "Daniel Okafor", image: "assets/illustrations/article-5.svg",
      body: ["Every transformation eventually becomes a leadership challenge. Plans can be sound and the technology can work, yet progress stalls if the leadership team is not aligned and resilient.",
        "The habits are simple to describe. Resilient teams agree on a small number of shared priorities, speak candidly in the room, make decisions at the right level, and communicate the same story.",
        "They also treat setbacks as information. Reviews focus on what was learned and what will change, not on assigning blame.",
        "None of these habits require a reorganization. They require consistency, and a willingness to hold one another to the standard."] },
    { id: "four-trends-reshaping-growth", category: "Market Trends", date: "2026-08-26", read: 8,
      title: "Reading the Market: Four Trends Reshaping Mid-Market Growth",
      excerpt: "From customer expectations to partnership models, four broad shifts are changing how ambitious mid-sized companies think about growth.",
      author: "Priya Raman", image: "assets/illustrations/article-6.svg",
      body: ["Growth for mid-sized organizations is being reshaped by forces that are easy to name and harder to act on. This article outlines four broad shifts worth watching; it is illustrative commentary rather than a market forecast.",
        "First, customers increasingly expect connected, digital-first experiences regardless of company size. Second, partnership and ecosystem models are replacing do-it-yourself expansion in many sectors.",
        "Third, data capability is becoming a differentiator rather than a back-office function. Fourth, talent expectations are changing how organizations structure work and attract people.",
        "The practical question for any leadership team is which of these shifts changes your own growth plan, and what you would need to believe to act on it."] },
    { id: "eliminating-hidden-friction", category: "Business Strategy", date: "2026-08-12", read: 5,
      title: "Operational Clarity: Eliminating the Hidden Friction in Everyday Work",
      excerpt: "Strategy is executed through everyday processes. Small frictions compound quickly — and removing them is often the fastest route to better performance.",
      author: "Julien Moreau", image: "assets/illustrations/article-7.svg",
      body: ["Ask any team about the work that slows them down and the answers are remarkably specific: unclear handoffs, duplicated approvals, information that lives in three places. Individually these are small. Together they shape how fast an organization can move.",
        "A practical way to start is to map one end-to-end process as it actually runs, not as it is documented. Look for waiting time, rework and decisions that no one owns.",
        "Prioritize fixes by impact and effort, and make the first few visible and quick. Early wins build credibility for the harder changes.",
        "Then embed the habit: regular reviews, clear ownership, and metrics that reflect flow rather than activity."] }
  ];
  NX.data = NX.data || {};
  NX.data.ARTICLES = ARTICLES;

  var fmtDate = function (iso) {
    var d = new Date(iso + "T12:00:00");
    return d.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
  };
  var byId = function (id) { return ARTICLES.filter(function (a) { return a.id === id; })[0]; };

  function meta(a) {
    return '<div class="post-card__meta"><span class="post-card__cat">' + esc(a.category) + "</span><span>" + fmtDate(a.date) + "</span><span>" + a.read + " min read</span></div>";
  }
  function card(a) {
    return '<button type="button" class="post-card reveal" data-article="' + esc(a.id) + '" data-cat="' + esc(a.category) + '" aria-label="Read article: ' + esc(a.title) + '">' +
      '<div class="post-card__img">' + NX.img(a, a.title + " — abstract illustration", 1600, 1000) + "</div>" +
      '<div class="post-card__body">' + meta(a) + "<h3>" + esc(a.title) + "</h3><p>" + esc(a.excerpt) + '</p><span class="link-arrow">Read article <span aria-hidden="true">→</span></span></div></button>';
  }
  function featured(a) {
    return '<button type="button" class="featured-post reveal" data-article="' + esc(a.id) + '" aria-label="Read featured article: ' + esc(a.title) + '">' +
      '<div class="featured-post__img">' + NX.img(a, a.title + " — abstract illustration", 1600, 1000, true) + "</div>" +
      '<div class="featured-post__body"><span class="demo-tag">Featured · Demo article</span>' + meta(a) + "<h3>" + esc(a.title) + "</h3><p>" + esc(a.excerpt) + '</p><span class="link-arrow">Read article <span aria-hidden="true">→</span></span></div></button>';
  }

  /* Article reader (modal) */
  var modal = null;
  function openArticle(id, trigger, pushHash) {
    var a = byId(id); if (!a) return;
    modal = modal || NX.dialog("article-modal", "Article reader");
    var related = ARTICLES.filter(function (x) { return x.id !== a.id; })
      .sort(function (x, y) { return (y.category === a.category) - (x.category === a.category); }).slice(0, 3);
    modal.open(
      '<article class="article"><div class="article__img">' + NX.img(a, a.title + " — abstract illustration", 1600, 700, true) + "</div>" +
      '<div class="article__body"><span class="demo-tag" style="justify-self:start">Demonstration article — fictional content</span>' + meta(a) +
      '<h2 class="h-section" style="font-size:clamp(1.7rem,3.4vw,2.6rem);text-transform:none;letter-spacing:-.025em">' + esc(a.title) + "</h2>" +
      '<p class="label">By ' + esc(a.author) + " · NEXORA (fictional)</p>" +
      a.body.map(function (p) { return "<p>" + esc(p) + "</p>"; }).join("") + "</div>" +
      '<div class="article__related"><h3 class="label">Related articles</h3>' + related.map(function (r) { return '<button type="button" data-related="' + esc(r.id) + '"><span>' + esc(r.title) + '</span><span aria-hidden="true">→</span></button>'; }).join("") + "</div></article>", trigger);
    if (pushHash && history.replaceState) history.replaceState(null, "", "#" + id);
    $$("[data-related]", modal.content).forEach(function (b) {
      b.addEventListener("click", function () { openArticle(b.getAttribute("data-related"), trigger, true); });
    });
  }

  /* Listing page */
  function initListing(host) {
    var grid = $("#post-grid", host), feat = $("#featured-slot", host), bar = $("[data-filters='articles']", host.ownerDocument), search = $("#article-search");
    var state = { cat: "all", q: "" };
    var f = ARTICLES.filter(function (a) { return a.featured; })[0];
    if (feat && f) feat.innerHTML = featured(f);
    grid.innerHTML = ARTICLES.map(card).join("");
    NX.reveal(host);

    var cats = [{ id: "all", label: "All" }].concat(CATEGORIES.map(function (c) { return { id: c, label: c }; }));
    bar.insertAdjacentHTML("afterbegin", NX.filterButtons(cats));
    var status = $(".filter-status", bar);

    function apply() {
      var q = state.q.trim().toLowerCase(), n = 0;
      $$(".post-card", grid).forEach(function (el) {
        var a = byId(el.getAttribute("data-article"));
        var hay = (a.title + " " + a.excerpt + " " + a.category + " " + a.author + " " + a.body.join(" ")).toLowerCase();
        var show = (state.cat === "all" || a.category === state.cat) && (!q || q.split(/\s+/).every(function (w) { return hay.indexOf(w) > -1; }));
        el.classList.toggle("is-hidden", !show); if (show) { n++; el.classList.add("in"); }
      });
      status.textContent = n + (n === 1 ? " article" : " articles") + (state.q ? ' matching "' + state.q + '"' : "");
      var empty = $("#no-results", grid);
      if (!n && !empty) grid.insertAdjacentHTML("beforeend", '<div class="empty-state" id="no-results"><strong>No articles found</strong>Try a different keyword or choose another category.</div>');
      if (n && empty) empty.remove();
      if (feat) feat.classList.toggle("is-hidden", state.cat !== "all" || !!q);
    }
    bar.addEventListener("click", function (e) {
      var b = e.target.closest("[data-filter]"); if (!b) return;
      $$("[data-filter]", bar).forEach(function (x) { x.setAttribute("aria-pressed", String(x === b)); });
      state.cat = b.getAttribute("data-filter"); apply();
    });
    if (search) search.addEventListener("input", NX.debounce(function () { state.q = search.value; apply(); }, 150));
    apply();
  }

  function boot() {
    // delegated: any [data-article] button opens the reader
    document.addEventListener("click", function (e) {
      var b = e.target.closest("[data-article]"); if (!b) return;
      openArticle(b.getAttribute("data-article"), b, true);
    });
    var list = $("[data-render='articles']"); if (list) initListing(list);
    var home = $("[data-render='home-insights']");
    if (home) {
      // home teaser: three articles, links go to the insights page reader via hash
      home.innerHTML = ARTICLES.slice(0, 3).map(function (a) {
        return '<a class="post-card reveal" href="insights.html#' + esc(a.id) + '"><div class="post-card__img">' + NX.img(a, a.title + " — abstract illustration", 1600, 1000) + '</div><div class="post-card__body">' + meta(a) + "<h3>" + esc(a.title) + "</h3><p>" + esc(a.excerpt) + '</p><span class="link-arrow">Read article <span aria-hidden="true">→</span></span></div></a>';
      }).join("");
      NX.reveal(home);
    }
    // deep link: insights.html#article-id
    if (list && location.hash && byId(location.hash.slice(1))) {
      setTimeout(function () { openArticle(location.hash.slice(1), null, false); }, 400);
    }
  }
  boot();
})();
