/* ==========================================================================
   NEXORA — interactions.js
   - TEAM and JOBS data (edit here) + their renderers, filters and modal
   - FAQ accordion
   - Form validation (contact + careers) with honest submission handling
   - Newsletter forms
   All people, roles and vacancies are FICTIONAL demonstration content.
   ========================================================================== */
(function () {
  "use strict";
  var NX = window.NX || {};
  var CFG = NX.cfg || {};
  var esc = NX.esc, $ = NX.$, $$ = NX.$$;

  /* ======================================================== TEAM (edit here) */
  var TEAM_GROUPS = [
    { id: "all", label: "Everyone" }, { id: "leadership", label: "Leadership" }, { id: "strategy", label: "Strategy & Finance" },
    { id: "technology", label: "Technology & Digital" }, { id: "growth", label: "Growth" }
  ];
  var TEAM = [
    { id: "elena", name: "Elena Marchetti", role: "Managing Director", group: "leadership", image: "assets/illustrations/team-elena.svg",
      bio: "Elena leads NEXORA's overall direction and its most important client relationships. She works with boards and executive teams on questions of ambition, structure and long-term value.",
      expertise: ["Executive advisory", "Organizational strategy", "Client partnerships"],
      philosophy: "Good strategy is clarity about what matters most, and the courage to say no to the rest." },
    { id: "daniel", name: "Daniel Okafor", role: "Chief Strategy Officer", group: "leadership strategy", image: "assets/illustrations/team-daniel.svg",
      bio: "Daniel shapes NEXORA's strategy practice, helping organizations frame complex choices, test assumptions and commit to direction with confidence.",
      expertise: ["Corporate strategy", "Scenario planning", "Market positioning"],
      philosophy: "The best plans stay useful when reality surprises you." },
    { id: "sofia", name: "Sofia Lindqvist", role: "Head of Digital Transformation", group: "technology", image: "assets/illustrations/team-sofia.svg",
      bio: "Sofia leads programs that modernize how organizations work, combining process design, technology and change management so that new ways of working stick.",
      expertise: ["Process modernization", "Change management", "Operating models"],
      philosophy: "Transformation succeeds when people feel it makes their work better." },
    { id: "marcus", name: "Marcus Tanaka", role: "Technology Director", group: "technology", image: "assets/illustrations/team-marcus.svg",
      bio: "Marcus advises on technology strategy and architecture, translating technical options into clear choices for business leaders.",
      expertise: ["Technology strategy", "Architecture advisory", "Vendor-neutral selection"],
      philosophy: "Technology should be the quiet enabler of the business, never its constraint." },
    { id: "priya", name: "Priya Raman", role: "Business Development Director", group: "growth", image: "assets/illustrations/team-priya.svg",
      bio: "Priya helps organizations find and win new growth: new markets, partnerships and commercial models that fit their strengths.",
      expertise: ["Market expansion", "Partnership strategy", "Go-to-market"],
      philosophy: "Growth is built on relationships and on offers people genuinely value." },
    { id: "julien", name: "Julien Moreau", role: "Financial Strategy Consultant", group: "strategy", image: "assets/illustrations/team-julien.svg",
      bio: "Julien builds the financial models and performance frameworks behind major decisions, making trade-offs visible and measurable.",
      expertise: ["Financial planning", "Scenario modeling", "Performance management"],
      philosophy: "Numbers should clarify decisions, not decorate them." }
  ];

  /* ========================================================= JOBS (edit here) */
  var JOB_GROUPS = [
    { id: "all", label: "All roles" }, { id: "strategy", label: "Strategy" }, { id: "technology", label: "Digital & Technology" },
    { id: "growth", label: "Growth" }, { id: "marketing", label: "Marketing" }
  ];
  var JOBS = [
    { id: "strategy-consultant", title: "Business Strategy Consultant", dept: "Strategy", group: "strategy", type: "Full-time", location: "Location placeholder · Hybrid",
      description: "Work with client leadership teams to frame strategic questions, analyze markets and develop recommendations that can be implemented.",
      responsibilities: ["Structure and analyze complex business problems", "Build clear, evidence-based recommendations", "Present findings to senior stakeholders"],
      skills: ["Analytical thinking", "Structured communication", "Market and competitor analysis", "Spreadsheet modeling"] },
    { id: "digital-specialist", title: "Digital Transformation Specialist", dept: "Digital & Technology", group: "technology", type: "Full-time", location: "Location placeholder · Hybrid",
      description: "Support transformation programs by mapping processes, shaping target operating models and helping teams adopt new ways of working.",
      responsibilities: ["Map current-state processes and pain points", "Support design of future-state processes", "Coordinate change and adoption activities"],
      skills: ["Process mapping", "Stakeholder management", "Change management basics", "Data literacy"] },
    { id: "bizdev-manager", title: "Business Development Manager", dept: "Growth", group: "growth", type: "Full-time", location: "Location placeholder · On-site",
      description: "Develop relationships with prospective clients and partners, and shape proposals that connect NEXORA's expertise to client priorities.",
      responsibilities: ["Identify and qualify new opportunities", "Develop proposals with delivery teams", "Build and maintain a healthy pipeline"],
      skills: ["Consultative selling", "Relationship building", "Proposal writing", "CRM familiarity"] },
    { id: "technology-analyst", title: "Technology Analyst", dept: "Digital & Technology", group: "technology", type: "Graduate / Entry level", location: "Location placeholder · Hybrid",
      description: "Support technology advisory engagements by researching options, documenting requirements and preparing analysis for client decisions.",
      responsibilities: ["Research technology options and vendors", "Document business and technical requirements", "Prepare comparison and recommendation material"],
      skills: ["Technical curiosity", "Research skills", "Clear writing", "Basic data analysis"] },
    { id: "marketing-specialist", title: "Marketing Specialist", dept: "Marketing", group: "marketing", type: "Full-time", location: "Location placeholder · Remote-friendly",
      description: "Shape how NEXORA tells its story through thought leadership, campaigns and digital channels, in close partnership with our consultants.",
      responsibilities: ["Plan and produce content and campaigns", "Manage the website and newsletter", "Measure and report on engagement"],
      skills: ["Content creation", "Digital marketing", "Analytics", "Brand consistency"] }
  ];
  NX.data = NX.data || {};
  NX.data.TEAM = TEAM; NX.data.JOBS = JOBS;

  /* ============================================================ TEAM render */
  function renderTeam(host) {
    host.innerHTML = TEAM.map(function (m) {
      return '<button type="button" class="member reveal" data-member="' + m.id + '" data-cat="' + m.group + '" aria-haspopup="dialog" aria-label="View profile: ' + esc(m.name) + ", " + esc(m.role) + '">' +
        '<div class="member__img">' + NX.img(m, "Illustrated portrait of " + m.name + ", " + m.role + " (fictional)", 800, 1000) +
        '<div class="member__over" aria-hidden="true">' + m.expertise.map(function (e) { return '<span class="tag">' + esc(e) + "</span>"; }).join("") + "</div></div>" +
        '<div class="member__info"><h3>' + esc(m.name) + "</h3><span>" + esc(m.role) + '</span><span class="member__more">View profile →</span></div></button>';
    }).join("");
    NX.reveal(host);

    var bar = $("[data-filters='team']");
    if (bar) {
      bar.innerHTML = NX.filterButtons(TEAM_GROUPS) + '<span class="filter-status" role="status" aria-live="polite"></span>';
      NX.filterable({ bar: bar, items: function () { return $$(".member", host); }, status: $(".filter-status", bar), noun: "people" })("all");
    }

    var modal = null;
    host.addEventListener("click", function (e) {
      var b = e.target.closest("[data-member]"); if (!b) return;
      var m = TEAM.filter(function (x) { return x.id === b.getAttribute("data-member"); })[0];
      modal = modal || NX.dialog("team-modal", "Team member profile");
      var L = CFG.contact || {};
      modal.open('<div class="profile"><div class="profile__img">' + NX.img(m, "Illustrated portrait of " + m.name + " (fictional)", 800, 1000, true) + "</div>" +
        '<div class="profile__body"><span class="demo-tag" style="justify-self:start">Fictional demonstration profile</span>' +
        '<div><p class="profile__role">' + esc(m.role) + '</p><h2 class="h-section" style="font-size:clamp(1.8rem,3vw,2.5rem);text-transform:none;margin-top:6px">' + esc(m.name) + "</h2></div>" +
        "<p>" + esc(m.bio) + "</p>" +
        '<div><h3 class="label" style="margin-bottom:10px">Areas of expertise</h3><div class="chips">' + m.expertise.map(function (x) { return '<span class="tag">' + esc(x) + "</span>"; }).join("") + "</div></div>" +
        '<div><h3 class="label" style="margin-bottom:10px">Professional philosophy</h3><blockquote>“' + esc(m.philosophy) + '”</blockquote></div>' +
        '<div class="social-row" aria-label="Social profiles (placeholder links)"><a href="' + esc(L.linkedin || "#") + '" target="_blank" rel="noopener noreferrer" aria-label="' + esc(m.name) + ' on LinkedIn (placeholder link)">' + NX.socialIcon("linkedin") + '</a><a href="' + esc(L.x || "#") + '" target="_blank" rel="noopener noreferrer" aria-label="' + esc(m.name) + ' on X (placeholder link)">' + NX.socialIcon("x") + "</a></div>" +
        '<a class="btn btn--sm" href="contact.html" style="justify-self:start">Get in touch <span class="arr" aria-hidden="true">→</span></a></div></div>', b);
    });
  }

  /* ============================================================= JOBS render */
  function renderJobs(host) {
    host.innerHTML = JOBS.map(function (j) {
      return '<article class="job reveal" id="' + j.id + '" data-cat="' + j.group + '">' +
        '<div class="job__top"><div><h3 class="job__title">' + esc(j.title) + '</h3><div class="job__meta"><span>' + NX.icon("briefcase", "ico") .replace("<svg ", '<svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" ') + esc(j.dept) + "</span><span>" + NX.icon("clock").replace("<svg ", '<svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" ') + esc(j.type) + "</span><span>" + NX.icon("pin").replace("<svg ", '<svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" ') + esc(j.location) + '</span></div></div>' +
        '<div class="job__actions"><button type="button" class="btn btn--ghost btn--sm toggle-btn" aria-expanded="false" aria-controls="job-more-' + j.id + '"><span class="toggle-label">View details</span> <span class="arr" aria-hidden="true">＋</span></button><a class="btn btn--sm" href="#apply" data-apply="' + j.id + '">Apply now <span class="arr" aria-hidden="true">→</span></a></div></div>' +
        '<div class="expand" id="job-more-' + j.id + '" inert><div><div class="expand__inner"><span class="demo-tag" style="justify-self:start">Fictional demonstration vacancy</span><p>' + esc(j.description) + "</p>" +
        '<div><h4>Responsibilities</h4><ul class="check-list">' + j.responsibilities.map(function (r) { return "<li>" + esc(r) + "</li>"; }).join("") + "</ul></div>" +
        '<div><h4>Required skills</h4><div class="chips">' + j.skills.map(function (s) { return '<span class="tag">' + esc(s) + "</span>"; }).join("") + "</div></div></div></div></div></article>";
    }).join("");
    NX.reveal(host);

    host.addEventListener("click", function (e) {
      var b = e.target.closest(".toggle-btn");
      if (b) {
        var open = NX.toggleExpand(b, document.getElementById(b.getAttribute("aria-controls")));
        b.closest(".job").classList.toggle("is-open", open);
        b.querySelector(".toggle-label").textContent = open ? "Hide details" : "View details";
        b.querySelector(".arr").textContent = open ? "－" : "＋";
        return;
      }
      var a = e.target.closest("[data-apply]");
      if (a) {
        var sel = $("#a-role"); if (sel) { sel.value = a.getAttribute("data-apply"); sel.dispatchEvent(new Event("change")); }
      }
    });
    var bar = $("[data-filters='jobs']");
    if (bar) {
      bar.innerHTML = NX.filterButtons(JOB_GROUPS) + '<span class="filter-status" role="status" aria-live="polite"></span>';
      NX.filterable({ bar: bar, items: function () { return $$(".job", host); }, status: $(".filter-status", bar), noun: "roles" })("all");
    }
    // role dropdown in the application form
    var sel = $("#a-role");
    if (sel) sel.innerHTML = '<option value="">Select a role</option>' + JOBS.map(function (j) { return '<option value="' + j.id + '">' + esc(j.title) + "</option>"; }).join("") + '<option value="general">General application</option>';
  }

  /* ================================================================== FAQ */
  function initAccordions() {
    $$("[data-accordion]").forEach(function (acc) {
      $$(".acc__panel", acc).forEach(function (p) { if ("inert" in p) p.inert = true; });
      acc.addEventListener("click", function (e) {
        var b = e.target.closest(".acc__btn"); if (!b) return;
        NX.toggleExpand(b, document.getElementById(b.getAttribute("aria-controls")));
      });
    });
  }

  /* ============================================================ VALIDATION */
  var FREE = null;
  var RULES = {
    required: function (v, el) {
      if (el.type === "checkbox") return el.checked;
      if (el.type === "file") return el.files && el.files.length > 0;
      return String(v).trim() !== "";
    },
    email: function (v) { return !v.trim() || /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()); },
    phone: function (v) { if (!v.trim()) return true; var d = v.replace(/\D/g, ""); return /^\+?[\d\s().-]+$/.test(v.trim()) && d.length >= 7 && d.length <= 15; },
    url: function (v) { if (!v.trim()) return true; try { var u = new URL(v.trim()); return /^https?:$/.test(u.protocol); } catch (e) { return false; } },
    minlength: function (v, el, n) { return !v.trim() || v.trim().length >= n; },
    cv: function (v, el) {
      var f = el.files && el.files[0]; if (!f) return true;
      var ok = /\.(pdf|docx?|DOCX?)$/i.test(f.name); return ok && f.size <= 5 * 1024 * 1024;
    }
  };
  var MSG = {
    required: function (l, el) { return el.type === "checkbox" ? "Please confirm to continue." : el.type === "file" ? "Please attach your CV." : el.tagName === "SELECT" ? "Please select " + l + "." : "Please enter " + l + "."; },
    email: function () { return "Enter a valid email address, for example name@company.com."; },
    phone: function () { return "Enter a valid phone number (7–15 digits, with optional + and spaces)."; },
    url: function () { return "Enter a full web address starting with https://"; },
    minlength: function (l, el, n) { return "Please write at least " + n + " characters so we can understand your needs."; },
    cv: function (l, el) { var f = el.files[0]; return /\.(pdf|docx?)$/i.test(f.name) ? "Your CV must be 5 MB or smaller." : "Upload your CV as a PDF or Word document (.pdf, .doc, .docx)."; }
  };

  function validateField(el) {
    var rules = (el.getAttribute("data-rules") || "").split(/\s+/).filter(Boolean);
    var label = el.getAttribute("data-label") || "this field";
    var wrap = el.closest(".field") || el.closest(".check-field");
    var err = wrap && $(".field__error", wrap);
    var msg = "";
    for (var i = 0; i < rules.length; i++) {
      var parts = rules[i].split(":"), name = parts[0], arg = parts[1] ? parseInt(parts[1], 10) : undefined;
      if (RULES[name] && !RULES[name](el.value || "", el, arg)) { msg = MSG[name](label, el, arg); break; }
    }
    if (wrap) wrap.classList.toggle("has-error", !!msg);
    if (err) err.textContent = msg;
    if (msg) el.setAttribute("aria-invalid", "true"); else el.removeAttribute("aria-invalid");
    return !msg;
  }
  function validateForm(form) {
    var bad = [];
    $$("[data-rules]", form).forEach(function (el) { if (!validateField(el)) bad.push(el); });
    return bad;
  }
  function liveValidate(form) {
    form.addEventListener("focusout", function (e) { if (e.target.matches && e.target.matches("[data-rules]")) validateField(e.target); });
    form.addEventListener("input", function (e) { var w = e.target.closest && e.target.closest(".has-error"); if (w && e.target.matches("[data-rules]")) validateField(e.target); });
    form.addEventListener("change", function (e) { if (e.target.matches && e.target.matches("[data-rules]")) validateField(e.target); });
  }

  function summaryHTML(rows) {
    return '<dl class="summary">' + rows.filter(function (r) { return r[1]; }).map(function (r) { return "<div><dt>" + esc(r[0]) + "</dt><dd>" + esc(r[1]) + "</dd></div>"; }).join("") + "</dl>";
  }
  function show(status, kind, html) {
    status.innerHTML = '<div class="notice notice--' + kind + '" role="' + (kind === "err" ? "alert" : "status") + '">' + html + "</div>";
    status.scrollIntoView({ behavior: NX.reduceMotion ? "auto" : "smooth", block: "nearest" });
  }
  function emailJsReady() { var e = CFG.emailjs || {}; return !!(e.publicKey && e.serviceId && e.templateId); }
  function loadEmailJs() {
    return new Promise(function (resolve, reject) {
      if (window.emailjs) return resolve(window.emailjs);
      var s = document.createElement("script"); s.src = (CFG.emailjs || {}).sdkUrl; s.async = true; s.crossOrigin = "anonymous";
      s.onload = function () { window.emailjs ? resolve(window.emailjs) : reject(new Error("EmailJS did not initialise")); };
      s.onerror = function () { reject(new Error("Could not load the EmailJS library")); };
      document.head.appendChild(s);
    });
  }
  function alternatives(subject, body) {
    var L = NX.links(), html = '<div class="row">';
    if (L.email) html += '<a class="btn btn--sm" href="' + L.email + "?subject=" + encodeURIComponent(subject) + "&body=" + encodeURIComponent(body) + '">Send by email <span class="arr" aria-hidden="true">→</span></a>';
    if (L.whatsapp) html += '<a class="btn btn--ghost btn--sm" href="' + L.whatsapp + '" target="_blank" rel="noopener noreferrer">Chat on WhatsApp</a>';
    return html + "</div>";
  }

  /* -------------------------------------------------------------- contact */
  function initContact(form) {
    var status = $("#form-status");
    var svcSel = $("#f-service");
    var SV = (NX.data && NX.data.SERVICES) || [];
    svcSel.innerHTML = '<option value="">Select a service</option>' + SV.map(function (s) { return '<option value="' + esc(s.name) + '">' + esc(s.name) + "</option>"; }).join("") + '<option value="Strategic advisory / not sure yet">Strategic advisory / not sure yet</option><option value="Partnerships & media">Partnerships &amp; media</option>';
    liveValidate(form);

    // Prefill from ?service=Name (links from services / solutions / industries pages)
    var q = new URLSearchParams(location.search).get("service");
    if (q) {
      var match = Array.prototype.some.call(svcSel.options, function (o) { if (o.value === q) { svcSel.value = q; return true; } return false; });
      if (!match) { var subj = $("#f-subject"); if (subj && !subj.value) subj.value = "Enquiry: " + q; }
    }

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      if ($("#f-website", form).value) return; // honeypot: bots fill this
      var bad = validateForm(form);
      if (bad.length) {
        show(status, "err", "<strong>Please check the highlighted fields</strong><span>" + bad.length + (bad.length === 1 ? " field needs" : " fields need") + " your attention before we can continue.</span>");
        bad[0].focus(); return;
      }
      var d = {
        name: $("#f-name").value.trim(), email: $("#f-email").value.trim(), company: $("#f-company").value.trim(), phone: $("#f-phone").value.trim(),
        service: svcSel.value, budget: $("#f-budget").value, subject: $("#f-subject").value.trim(), message: $("#f-message").value.trim()
      };
      var rows = [["Name", d.name], ["Email", d.email], ["Company", d.company], ["Phone", d.phone], ["Service", d.service], ["Budget", d.budget], ["Subject", d.subject], ["Message", d.message]];
      var plain = rows.filter(function (r) { return r[1]; }).map(function (r) { return r[0] + ": " + r[1]; }).join("\n");
      var btn = $("button[type=submit]", form);

      if (!emailJsReady()) {
        show(status, "warn", "<strong>Your enquiry is valid — but it has not been sent</strong><span>Email delivery is not configured on this demonstration website, so nothing was transmitted or stored. Add your EmailJS keys in <code>js/config.js</code> to enable sending, or reach us directly:</span>" + alternatives(d.subject, plain) + '<h4 class="label" style="margin-top:8px">Submission summary</h4>' + summaryHTML(rows));
        return;
      }
      btn.disabled = true; btn.setAttribute("aria-busy", "true");
      show(status, "info", "<strong>Sending…</strong><span>Please wait a moment.</span>");
      loadEmailJs().then(function (ejs) {
        var c = CFG.emailjs;
        return ejs.send(c.serviceId, c.templateId, { from_name: d.name, from_email: d.email, company: d.company, phone: d.phone, service: d.service, budget: d.budget || "Not specified", subject: d.subject, message: d.message, reply_to: d.email }, { publicKey: c.publicKey });
      }).then(function () {
        show(status, "ok", "<strong>Thank you — your message has been sent</strong><span>We'll reply to " + esc(d.email) + " as soon as we can.</span>" + '<h4 class="label" style="margin-top:8px">Submission summary</h4>' + summaryHTML(rows));
        form.reset();
      }).catch(function (err) {
        show(status, "err", "<strong>We couldn't send your message</strong><span>" + esc((err && (err.text || err.message)) || "Unknown error") + ". Please try again, or contact us directly:</span>" + alternatives(d.subject, plain));
      }).then(function () { btn.disabled = false; btn.removeAttribute("aria-busy"); });
    });
  }

  /* -------------------------------------------------------------- careers */
  function initCareers(form) {
    var status = $("#apply-status"), cv = $("#a-cv"), up = $(".upload", form);
    liveValidate(form);
    function showFile() {
      var f = cv.files && cv.files[0];
      $(".upload__name", up).textContent = f ? f.name + " (" + Math.max(1, Math.round(f.size / 1024)) + " KB)" : "PDF, DOC or DOCX · max 5 MB";
      up.classList.toggle("has-file", !!f);
    }
    cv.addEventListener("change", showFile);
    ["dragenter", "dragover"].forEach(function (ev) { up.addEventListener(ev, function () { up.classList.add("is-drag"); }); });
    ["dragleave", "drop"].forEach(function (ev) { up.addEventListener(ev, function () { up.classList.remove("is-drag"); }); });

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      if ($("#a-website", form).value) return;
      var bad = validateForm(form);
      if (bad.length) {
        show(status, "err", "<strong>Please check the highlighted fields</strong><span>" + bad.length + (bad.length === 1 ? " field needs" : " fields need") + " your attention.</span>");
        bad[0].focus(); return;
      }
      var roleEl = $("#a-role"), role = roleEl.options[roleEl.selectedIndex].text;
      var rows = [["Role", role], ["Name", $("#a-name").value.trim()], ["Email", $("#a-email").value.trim()], ["Phone", $("#a-phone").value.trim()], ["LinkedIn", $("#a-linkedin").value.trim()], ["CV", cv.files[0].name], ["Message", $("#a-message").value.trim()]];
      var plain = rows.filter(function (r) { return r[1]; }).map(function (r) { return r[0] + ": " + r[1]; }).join("\n") + "\n\n(Please attach your CV to this email.)";
      var endpoint = (CFG.careers && CFG.careers.endpoint) || "";
      var L = NX.links();

      if (!endpoint) {
        show(status, "warn", "<strong>Your application is valid — but it has not been submitted</strong><span>This demonstration website has no recruitment backend, so your details and CV were not sent or stored anywhere. To apply for real, email " + esc((CFG.contact || {}).careersEmail || "the careers address") + " and attach your CV.</span>" +
          '<div class="row">' + (L.careers ? '<a class="btn btn--sm" href="' + L.careers + "?subject=" + encodeURIComponent("Application: " + role) + "&body=" + encodeURIComponent(plain) + '">Email your application <span class="arr" aria-hidden="true">→</span></a>' : "") + "</div>" +
          '<h4 class="label" style="margin-top:8px">Application summary</h4>' + summaryHTML(rows));
        return;
      }
      var btn = $("button[type=submit]", form); btn.disabled = true;
      show(status, "info", "<strong>Submitting…</strong>");
      fetch(endpoint, { method: "POST", body: new FormData(form), headers: { Accept: "application/json" } })
        .then(function (r) { if (!r.ok) throw new Error("The server responded with status " + r.status); })
        .then(function () { show(status, "ok", "<strong>Application received</strong><span>Thank you — we'll be in touch.</span>" + summaryHTML(rows)); form.reset(); showFile(); })
        .catch(function (err) { show(status, "err", "<strong>We couldn't submit your application</strong><span>" + esc(err.message) + ". Please email " + esc((CFG.contact || {}).careersEmail || "us") + " instead.</span>"); })
        .then(function () { btn.disabled = false; });
    });
  }

  /* ----------------------------------------------------------- newsletter */
  function initNewsletters() {
    $$("[data-newsletter]").forEach(function (form) {
      var input = $("input[type=email]", form), msg = $(".newsletter__msg", form);
      function set(kind, text) { msg.className = "newsletter__msg " + (kind ? "is-" + kind : ""); msg.textContent = text; }
      form.addEventListener("submit", function (e) {
        e.preventDefault();
        var v = input.value.trim();
        if (!v) { set("error", "Please enter your email address."); input.setAttribute("aria-invalid", "true"); input.focus(); return; }
        if (!RULES.email(v)) { set("error", "Enter a valid email address, for example name@company.com."); input.setAttribute("aria-invalid", "true"); input.focus(); return; }
        input.removeAttribute("aria-invalid");
        var ep = (CFG.newsletter && CFG.newsletter.endpoint) || "";
        if (!ep) { set("info", "Demo mode: no newsletter service is connected, so your address was not sent or saved."); return; }
        set("info", "Subscribing…");
        fetch(ep, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email: v }) })
          .then(function (r) { if (!r.ok) throw new Error("status " + r.status); set("info", "Thank you — you're subscribed."); form.reset(); })
          .catch(function () { set("error", "Sorry, we couldn't subscribe you right now. Please try again later."); });
      });
    });
  }

  /* ================================================================== boot */
  function boot() {
    $$("[data-render]").forEach(function (h) {
      var k = h.getAttribute("data-render");
      try {
        if (k === "team") renderTeam(h);
        else if (k === "jobs") renderJobs(h);
      } catch (err) { if (window.console) console.error("[NEXORA] render failed:", k, err); }
    });
    var cf = $("#contact-form"); if (cf && cf.tagName === "FORM") initContact(cf);
    var af = $("#apply-form"); if (af) initCareers(af);
    initAccordions();
    initNewsletters();
  }
  boot();
})();
