/* ==========================================================================
   NEXORA — navigation.js
   Sticky header state, scroll progress bar, accessible mobile menu and
   active-link detection.
   ========================================================================== */
(function () {
  "use strict";
  var NX = window.NX || {};
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  var header = $(".site-header");
  var toggle = $(".nav-toggle");
  var menu = $(".mobile-menu");
  var bar = $(".scroll-progress");

  /* ---- Active page (static aria-current is set in the HTML; this is a safety net) ---- */
  var file = (location.pathname.split("/").pop() || "index.html").toLowerCase();
  if (file === "") file = "index.html";
  $$(".nav__link, .mobile-menu__link").forEach(function (a) {
    var href = (a.getAttribute("href") || "").split("#")[0].toLowerCase();
    if (href === file) a.setAttribute("aria-current", "page");
  });

  /* ---- Header: transparent over hero → solid on scroll; progress bar ---- */
  var ticking = false;
  function onScroll() {
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(function () {
      var y = window.pageYOffset || document.documentElement.scrollTop;
      if (header) header.classList.toggle("is-scrolled", y > 24);
      if (bar) {
        var max = document.documentElement.scrollHeight - window.innerHeight;
        bar.style.transform = "scaleX(" + (max > 0 ? Math.min(y / max, 1) : 0) + ")";
      }
      ticking = false;
    });
  }
  window.addEventListener("scroll", onScroll, { passive: true });
  window.addEventListener("resize", onScroll);
  onScroll();

  /* ---- Mobile menu ---- */
  if (!toggle || !menu) return;
  var lastFocus = null;

  function focusables() {
    return $$("a[href], button:not([disabled])", menu).concat([toggle]);
  }
  function open() {
    lastFocus = document.activeElement;
    menu.classList.add("is-open");
    menu.removeAttribute("aria-hidden");
    if ("inert" in menu) menu.inert = false;
    toggle.setAttribute("aria-expanded", "true");
    toggle.setAttribute("aria-label", "Close menu");
    document.body.classList.add("no-scroll");
    var first = $("a", menu); if (first) setTimeout(function () { first.focus({ preventScroll: true }); }, 350);
  }
  function close(returnFocus) {
    menu.classList.remove("is-open");
    menu.setAttribute("aria-hidden", "true");
    if ("inert" in menu) menu.inert = true;
    toggle.setAttribute("aria-expanded", "false");
    toggle.setAttribute("aria-label", "Open menu");
    document.body.classList.remove("no-scroll");
    if (returnFocus !== false && lastFocus) lastFocus.focus({ preventScroll: true });
  }
  menu.setAttribute("aria-hidden", "true");
  if ("inert" in menu) menu.inert = true;

  toggle.addEventListener("click", function () {
    toggle.getAttribute("aria-expanded") === "true" ? close() : open();
  });
  menu.addEventListener("click", function (e) { if (e.target.closest("a")) close(false); });
  document.addEventListener("keydown", function (e) {
    if (!menu.classList.contains("is-open")) return;
    if (e.key === "Escape") { close(); return; }
    if (e.key === "Tab") { // keep focus inside the open menu
      var f = focusables(), first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });
  window.addEventListener("resize", NX.debounce ? NX.debounce(function () { if (window.innerWidth > 1100 && menu.classList.contains("is-open")) close(false); }, 120) : function () {});
})();
