/* ==========================================================================
   NEXORA — scene.js  (homepage hero, Three.js r128, global THREE)
   An architectural "growth tower": stacked glass & metal slabs that step
   upward, orbiting rings, satellites and floating particles over a dark
   reflective floor. Mouse moves the camera, scroll lifts it, lights follow
   the cursor.

   Safety: if WebGL / THREE is missing, on error, or when reduced motion is
   requested, the static hero image stays visible. Rendering pauses when the
   hero is off-screen or the tab is hidden. Mobile gets fewer particles and
   no antialiasing.

   Tweak look & feel in js/config.js → scene.
   ========================================================================== */
(function () {
  "use strict";
  var canvas = document.getElementById("hero-canvas");
  if (!canvas) return;
  var hero = canvas.closest(".hero");
  var cfg = (window.NEXORA_CONFIG && window.NEXORA_CONFIG.scene) || {};
  var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  function fallback(why) {
    if (hero) hero.classList.remove("has-webgl");
    if (window.console && why) console.info("[NEXORA] 3D hero disabled:", why);
  }
  if (cfg.enabled === false) return fallback("disabled in config");
  if (reduce) return fallback("prefers-reduced-motion");
  if (!window.THREE) return fallback("Three.js not loaded");

  try {
    var test = document.createElement("canvas");
    if (!(test.getContext("webgl") || test.getContext("experimental-webgl"))) return fallback("WebGL unavailable");

    var THREE = window.THREE;
    var mobile = window.innerWidth < 768;
    var renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: !mobile, alpha: true, powerPreference: "high-performance" });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, mobile ? 1.25 : 2));
    renderer.outputEncoding = THREE.sRGBEncoding;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;

    var scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x0b1322, 0.045);
    var camera = new THREE.PerspectiveCamera(34, 1, 0.1, 100);
    var camBase = new THREE.Vector3(0, 2.2, 15);

    /* ---- procedural environment map (soft studio strips) for glass/metal reflections ---- */
    var ec = document.createElement("canvas"); ec.width = 512; ec.height = 256;
    var ex = ec.getContext("2d");
    var g = ex.createLinearGradient(0, 0, 0, 256);
    g.addColorStop(0, "#1a2c52"); g.addColorStop(0.5, "#0b1322"); g.addColorStop(1, "#050a14");
    ex.fillStyle = g; ex.fillRect(0, 0, 512, 256);
    ex.fillStyle = "rgba(160,190,255,.9)"; ex.fillRect(60, 40, 90, 14); ex.fillRect(300, 30, 140, 10);
    ex.fillStyle = "rgba(49,94,245,.85)"; ex.fillRect(200, 80, 60, 40);
    var envTex = new THREE.CanvasTexture(ec); envTex.mapping = THREE.EquirectangularReflectionMapping; envTex.encoding = THREE.sRGBEncoding;
    var pmrem = new THREE.PMREMGenerator(renderer);
    var envRT = pmrem.fromEquirectangular(envTex);
    scene.environment = envRT.texture;
    envTex.dispose(); pmrem.dispose();

    /* ---- lights ---- */
    scene.add(new THREE.AmbientLight(0x6b8cff, 0.35));
    var key = new THREE.DirectionalLight(0xffffff, 1.1); key.position.set(-6, 10, 8); scene.add(key);
    var blue = new THREE.PointLight(cfg.accent || 0x315ef5, 60, 40, 2); blue.position.set(4, 5, 5); scene.add(blue);
    var sky = new THREE.PointLight(cfg.accent2 || 0x6b8cff, 30, 40, 2); sky.position.set(-5, 2, -3); scene.add(sky);

    /* ---- materials ---- */
    var glass = new THREE.MeshPhysicalMaterial({ color: 0x9db4ff, metalness: 0.1, roughness: 0.08, transmission: 0.0, transparent: true, opacity: 0.38, clearcoat: 1, clearcoatRoughness: 0.1, envMapIntensity: 1.6 });
    var navy = new THREE.MeshStandardMaterial({ color: 0x14243a, metalness: 0.85, roughness: 0.28, envMapIntensity: 1.4 });
    var chrome = new THREE.MeshStandardMaterial({ color: 0xd7e0f5, metalness: 1, roughness: 0.16, envMapIntensity: 1.6 });
    var glow = new THREE.MeshStandardMaterial({ color: 0x315ef5, emissive: 0x315ef5, emissiveIntensity: 1.6, metalness: 0.2, roughness: 0.3 });

    var root = new THREE.Group(); scene.add(root);
    var tower = new THREE.Group(); root.add(tower);

    /* ---- the stepped tower: slabs shrinking as they rise, alternating glass / metal ---- */
    var slabs = [];
    var levels = 7, y = 0;
    for (var i = 0; i < levels; i++) {
      var s = 3.4 - i * 0.36, h = 0.55 + (i % 2) * 0.12;
      var geo = new THREE.BoxGeometry(s, h, s);
      var mat = i % 2 === 0 ? navy : glass;
      var m = new THREE.Mesh(geo, mat);
      m.position.y = y + h / 2; m.rotation.y = i * 0.22;
      tower.add(m); slabs.push(m);
      // glowing edge line on each slab
      var edges = new THREE.LineSegments(new THREE.EdgesGeometry(geo), new THREE.LineBasicMaterial({ color: 0x6b8cff, transparent: true, opacity: 0.55 }));
      m.add(edges);
      y += h + 0.18;
    }
    // apex: glowing octahedron
    var apex = new THREE.Mesh(new THREE.OctahedronGeometry(0.5, 0), glow); apex.position.y = y + 0.7; tower.add(apex);
    var apexLight = new THREE.PointLight(0x6b8cff, 16, 10, 2); apexLight.position.copy(apex.position); tower.add(apexLight);

    /* ---- orbiting rings ---- */
    var rings = [];
    [[3.2, 0.03, 0.4, 0.2], [4.2, 0.02, -0.5, 0.9], [5.2, 0.015, 0.15, -0.4]].forEach(function (r, idx) {
      var ring = new THREE.Mesh(new THREE.TorusGeometry(r[0], r[1], 16, 160), idx === 0 ? chrome : glow);
      ring.rotation.x = Math.PI / 2 + r[2]; ring.rotation.z = r[3]; ring.position.y = 2.6 + idx * 0.6;
      root.add(ring); rings.push(ring);
    });

    /* ---- satellites orbiting the tower ---- */
    var sats = [];
    for (var k = 0; k < 5; k++) {
      var sm = new THREE.Mesh(k % 2 ? new THREE.IcosahedronGeometry(0.2, 0) : new THREE.OctahedronGeometry(0.22, 0), k % 2 ? chrome : glass);
      sm.userData = { r: 3.6 + k * 0.5, a: (k / 5) * Math.PI * 2, s: 0.25 + k * 0.05, y: 1.2 + k * 0.9 };
      root.add(sm); sats.push(sm);
    }

    /* ---- floor ---- */
    var floor = new THREE.Mesh(new THREE.CircleGeometry(22, 64), new THREE.MeshStandardMaterial({ color: 0x0a1120, metalness: 0.9, roughness: 0.32, envMapIntensity: 0.8 }));
    floor.rotation.x = -Math.PI / 2; floor.position.y = -0.02; root.add(floor);
    var grid = new THREE.GridHelper(40, 40, 0x315ef5, 0x1c2f55); grid.position.y = 0.0; grid.material.transparent = true; grid.material.opacity = 0.25; root.add(grid);

    /* ---- floating particles ---- */
    var pCount = mobile ? Math.round((cfg.particles || 140) * 0.35) : (cfg.particles || 140);
    var pos = new Float32Array(pCount * 3);
    for (var p = 0; p < pCount; p++) { pos[p * 3] = (Math.random() - 0.5) * 22; pos[p * 3 + 1] = Math.random() * 12; pos[p * 3 + 2] = (Math.random() - 0.5) * 16; }
    var pg = new THREE.BufferGeometry(); pg.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    var points = new THREE.Points(pg, new THREE.PointsMaterial({ color: 0x9db4ff, size: 0.055, transparent: true, opacity: 0.7, depthWrite: false }));
    scene.add(points);

    /* ---- layout: tower sits right of the headline on wide screens ---- */
    function layout() {
      var w = hero.clientWidth, h = hero.clientHeight;
      renderer.setSize(w, h, false);
      camera.aspect = w / h; camera.updateProjectionMatrix();
      var wide = camera.aspect > 1.15;
      root.position.set(wide ? 4.4 : 0, wide ? -2.2 : 0.2, 0);
      root.scale.setScalar(wide ? 1 : 0.72);
      camBase.set(0, wide ? 2.2 : 3.5, wide ? 15 : 18);
    }
    layout();
    window.addEventListener("resize", layout);

    /* ---- interaction ---- */
    var mouse = { x: 0, y: 0, tx: 0, ty: 0 };
    var strength = cfg.mouseStrength == null ? 0.35 : cfg.mouseStrength;
    window.addEventListener("pointermove", function (e) {
      mouse.tx = (e.clientX / window.innerWidth) * 2 - 1;
      mouse.ty = (e.clientY / window.innerHeight) * 2 - 1;
    }, { passive: true });
    var scrollP = 0;
    window.addEventListener("scroll", function () { scrollP = Math.min(window.pageYOffset / (hero.clientHeight || 1), 1.2); }, { passive: true });

    /* ---- loop (paused offscreen / hidden tab) ---- */
    var running = false, visible = true, clock = new THREE.Clock(), rotSpeed = cfg.rotationSpeed == null ? 0.12 : cfg.rotationSpeed;
    function frame() {
      if (!running) return;
      requestAnimationFrame(frame);
      try {
      var t = clock.getElapsedTime();
      mouse.x += (mouse.tx - mouse.x) * 0.04; mouse.y += (mouse.ty - mouse.y) * 0.04;

      tower.rotation.y = t * rotSpeed;
      slabs.forEach(function (m, i) { m.rotation.y = i * 0.22 + Math.sin(t * 0.4 + i) * 0.08; });
      apex.rotation.y = t * 0.9; apex.rotation.x = t * 0.5; apex.position.y += Math.sin(t * 1.6) * 0.002;
      rings.forEach(function (r, i) { r.rotation.z += 0.0015 * (i % 2 ? -1 : 1) * (i + 1); });
      sats.forEach(function (s) {
        var d = s.userData; d.a += d.s * 0.01;
        s.position.set(Math.cos(d.a) * d.r, d.y + Math.sin(t + d.r) * 0.2, Math.sin(d.a) * d.r);
        s.rotation.x += 0.01; s.rotation.y += 0.014;
      });
      points.rotation.y = t * 0.012; points.position.y = Math.sin(t * 0.3) * 0.3;

      // camera: mouse parallax + scroll lift
      camera.position.x = camBase.x + mouse.x * 2.2 * strength * 3;
      camera.position.y = camBase.y - mouse.y * 1.2 * strength * 3 + scrollP * 2.2;
      camera.position.z = camBase.z + scrollP * 2;
      camera.lookAt(root.position.x * 0.6, 2.6 + scrollP * 1.4, 0);
      // lights respond to cursor
      blue.position.x = 4 + mouse.x * 6; blue.position.y = 5 - mouse.y * 3;
      sky.position.x = -5 - mouse.x * 4;

      renderer.render(scene, camera);
      } catch (loopErr) { stop(); fallback(loopErr && loopErr.message); } // never leave a broken canvas on screen
    }
    function start() { if (!running && visible && !document.hidden) { running = true; clock.start(); frame(); } }
    function stop() { running = false; }
    if ("IntersectionObserver" in window) {
      new IntersectionObserver(function (en) { visible = en[0].isIntersecting; visible ? start() : stop(); }, { threshold: 0 }).observe(hero);
    }
    document.addEventListener("visibilitychange", function () { document.hidden ? stop() : start(); });
    canvas.addEventListener("webglcontextlost", function (e) { e.preventDefault(); stop(); fallback("context lost"); });

    renderer.render(scene, camera);            // first frame before revealing the canvas
    hero.classList.add("has-webgl");
    start();
  } catch (err) {
    fallback(err && err.message);
  }
})();
