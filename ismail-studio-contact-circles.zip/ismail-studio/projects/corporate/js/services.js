/* ==========================================================================
   NEXORA — services.js
   EDIT CONTENT HERE: SERVICES, SOLUTIONS and INDUSTRIES are plain data arrays.
   Pages render themselves from this data — no HTML changes needed.
   All content is FICTIONAL demonstration copy.

   Image fields: `image` is the bundled local illustration. To use a real photo,
   add `photo: "assets/images/your-photo.jpg"` — the illustration remains the
   automatic fallback if the photo fails to load.
   ========================================================================== */
(function () {
  "use strict";
  var NX = window.NX || {};
  var esc = NX.esc, $ = NX.$, $$ = NX.$$;

  /* ------------------------------------------------------------------ DATA */
  var SERVICE_GROUPS = [
    { id: "all", label: "All services" },
    { id: "strategy", label: "Strategy & Finance" },
    { id: "technology", label: "Technology" },
    { id: "growth", label: "Growth & Operations" }
  ];

  var SERVICES = [
    { id: "strategy", num: "01", group: "strategy", icon: "target", name: "Business Strategy",
      summary: "Strategic planning, market positioning, business models and long-term growth strategies.",
      description: "We help leadership teams decide where to play and how to win. From market positioning and business-model design to multi-year growth roadmaps, our strategists turn ambiguity into a clear, prioritized plan that the whole organization can execute.",
      benefits: ["A shared view of priorities and trade-offs", "Business models built for durable advantage", "Roadmaps linked to measurable outcomes", "Alignment from boardroom to front line"],
      expertise: ["Strategic planning", "Market positioning", "Business model design", "Competitive analysis", "Long-term growth strategy"],
      related: ["growth", "advisory"], image: "assets/illustrations/service-strategy.svg" },
    { id: "digital", num: "02", group: "technology", icon: "layers", name: "Digital Transformation",
      summary: "Modernizing processes, adopting new technologies and improving digital capabilities.",
      description: "Technology only creates value when people, processes and platforms move together. We design and guide transformation programs that modernize how work gets done, strengthen digital capabilities and make change stick.",
      benefits: ["Faster, simpler end-to-end processes", "Technology choices tied to business goals", "Stronger data and analytics foundations", "Change that teams actually adopt"],
      expertise: ["Process modernization", "Digital operating models", "Change management", "Data & analytics enablement", "Customer journey redesign"],
      related: ["transformation", "innovation"], image: "assets/illustrations/service-digital.svg" },
    { id: "technology", num: "03", group: "technology", icon: "chip", name: "Technology Consulting",
      summary: "Technology strategy, digital infrastructure, software solutions and innovation advisory.",
      description: "Independent, vendor-neutral advice on the technology that supports your strategy. We help you plan architecture, evaluate software and infrastructure options, and build a technology roadmap that balances ambition with risk.",
      benefits: ["Vendor-neutral recommendations", "Architecture that scales with the business", "Lower risk in technology investments", "A roadmap leadership can fund with confidence"],
      expertise: ["Technology strategy", "Digital infrastructure", "Software solution selection", "Architecture advisory", "Innovation advisory"],
      related: ["enterprise", "innovation"], image: "assets/illustrations/service-technology.svg" },
    { id: "development", num: "04", group: "growth", icon: "trend", name: "Business Development",
      summary: "Market expansion, partnership strategies, growth opportunities and commercial development.",
      description: "We identify where the next stage of growth will come from and build the commercial approach to capture it: new markets, strategic partnerships, new offers and the go-to-market plans that bring them to life.",
      benefits: ["A prioritized pipeline of growth opportunities", "Partnership models with clear value for both sides", "Go-to-market plans ready to execute", "Faster, better-informed expansion decisions"],
      expertise: ["Market expansion", "Partnership strategy", "Go-to-market planning", "Commercial development", "Opportunity assessment"],
      related: ["growth", "advisory"], image: "assets/illustrations/service-development.svg" },
    { id: "financial", num: "05", group: "strategy", icon: "pie", name: "Financial Advisory",
      summary: "Business financial planning, performance optimization and strategic financial insights.",
      description: "Clear financial thinking behind big decisions. We build the models, scenarios and performance frameworks that help leaders allocate capital wisely, protect margins and fund growth.",
      benefits: ["Decision-ready financial models", "Visibility into the drivers of performance", "Scenario planning for uncertain markets", "Sharper capital allocation"],
      expertise: ["Financial planning", "Performance optimization", "Scenario modeling", "Investment case development", "Strategic financial insight"],
      related: ["performance", "advisory"], image: "assets/illustrations/service-financial.svg" },
    { id: "operations", num: "06", group: "growth", icon: "gear", name: "Operational Excellence",
      summary: "Process optimization, organizational efficiency and operational transformation.",
      description: "We make organizations run better. By simplifying processes, clarifying roles and embedding continuous improvement, we help teams deliver more with less friction and build operations that can scale.",
      benefits: ["Leaner, more reliable processes", "Clear accountability and ownership", "Sustainable productivity gains", "A culture of continuous improvement"],
      expertise: ["Process optimization", "Organizational efficiency", "Lean operating models", "Operational transformation", "Performance management"],
      related: ["performance", "transformation"], image: "assets/illustrations/service-operations.svg" }
  ];

  var SOLUTIONS = [
    { id: "transformation", num: "01", name: "Business Transformation", tagline: "Modernize organizational structures and business operations.",
      explanation: "When markets shift, the way an organization is structured and run has to shift with it. We redesign operating models, governance and ways of working so that strategy and day-to-day execution pull in the same direction.",
      challenges: ["Legacy structures that slow decisions", "Siloed teams and unclear ownership", "Transformation programs that lose momentum", "Change fatigue across the organization"],
      benefits: ["Faster, clearer decision-making", "A structure aligned to strategy", "Higher engagement through change", "Durable, measurable results"],
      method: ["Diagnose current state", "Design target operating model", "Plan phased roll-out", "Embed and measure"],
      services: ["digital", "operations"], image: "assets/illustrations/solution-transformation.svg" },
    { id: "innovation", num: "02", name: "Digital Innovation", tagline: "Build better digital experiences and technology-driven business models.",
      explanation: "We help organizations turn emerging technology into new products, services and revenue models, testing ideas quickly and scaling only what proves its value.",
      challenges: ["Ideas that never leave the workshop", "Unclear return on digital investment", "Customers expecting seamless experiences", "Limited in-house innovation capacity"],
      benefits: ["New digital revenue opportunities", "Validated concepts before big spend", "Better customer experiences", "An innovation pipeline that keeps flowing"],
      method: ["Frame the opportunity", "Prototype and test", "Build the business case", "Scale what works"],
      services: ["digital", "technology"], image: "assets/illustrations/solution-innovation.svg" },
    { id: "growth", name: "Growth Strategy", num: "03", tagline: "Identify opportunities and develop scalable business strategies.",
      explanation: "We map where sustainable growth is available — new markets, segments, offers and partnerships — and turn the best options into a scalable plan with clear milestones.",
      challenges: ["Plateauing core business", "Unclear priorities among growth options", "Expansion that outpaces operations", "Entering unfamiliar markets"],
      benefits: ["A ranked set of growth options", "Plans designed to scale", "Reduced expansion risk", "Shared targets across leadership"],
      method: ["Size the opportunities", "Prioritize and sequence", "Design the go-to-market", "Launch and track"],
      services: ["strategy", "development"], image: "assets/illustrations/solution-growth.svg" },
    { id: "enterprise", num: "04", name: "Enterprise Technology", tagline: "Implement modern technology solutions that support organizational goals.",
      explanation: "From selecting the right platforms to planning delivery and adoption, we help enterprises implement technology that supports — rather than constrains — how the business wants to operate.",
      challenges: ["Fragmented, aging systems", "Costly or stalled implementations", "Security and integration complexity", "Low adoption of new tools"],
      benefits: ["A coherent technology landscape", "Lower total cost of ownership", "Smoother implementation and adoption", "Technology aligned to strategy"],
      method: ["Assess the landscape", "Select and architect", "Govern the delivery", "Drive adoption"],
      services: ["technology", "digital"], image: "assets/illustrations/solution-enterprise.svg" },
    { id: "performance", num: "05", name: "Performance Optimization", tagline: "Improve efficiency, productivity and business performance.",
      explanation: "We find where value leaks — in processes, costs, handoffs and decisions — and put in place the metrics, routines and improvements that raise performance and keep it there.",
      challenges: ["Rising costs and thin margins", "Inconsistent process quality", "Limited visibility of performance drivers", "Improvements that fade over time"],
      benefits: ["Measurable efficiency gains", "Transparent performance metrics", "Healthier margins", "A habit of continuous improvement"],
      method: ["Baseline performance", "Identify value levers", "Implement improvements", "Track and sustain"],
      services: ["operations", "financial"], image: "assets/illustrations/solution-performance.svg" },
    { id: "advisory", num: "06", name: "Strategic Advisory", tagline: "Provide informed strategic guidance for complex business decisions.",
      explanation: "For decisions that are complex, high-stakes or hard to reverse, we act as a trusted, independent sounding board — structuring the problem, testing assumptions and clarifying the options.",
      challenges: ["High-stakes decisions with incomplete information", "Competing internal views", "Pressure to act quickly", "Need for an independent perspective"],
      benefits: ["Clearer, better-structured decisions", "Assumptions tested before commitment", "Confident, aligned leadership", "Reduced risk of costly missteps"],
      method: ["Define the decision", "Gather and test evidence", "Evaluate the options", "Recommend and support"],
      services: ["strategy", "financial"], image: "assets/illustrations/solution-advisory.svg" }
  ];

  /* "Which solution fits?" finder: each challenge points to solution ids. */
  var CHALLENGES = [
    { id: "legacy", label: "Our structure and processes feel outdated", solutions: ["transformation", "performance"] },
    { id: "digital", label: "Customers expect better digital experiences", solutions: ["innovation", "enterprise"] },
    { id: "market", label: "We need new markets or revenue streams", solutions: ["growth", "innovation"] },
    { id: "tech", label: "Our systems are fragmented or aging", solutions: ["enterprise", "transformation"] },
    { id: "costs", label: "Costs are rising and margins are shrinking", solutions: ["performance", "advisory"] },
    { id: "decision", label: "We face a complex, high-stakes decision", solutions: ["advisory", "growth"] }
  ];

  /* Comparison table (illustrative). dots: 1–4 scale. */
  var COMPARE = [
    { s: "transformation", focus: "Operating model & structure", horizon: "6–18 months", effort: 4, tech: 2 },
    { s: "innovation", focus: "New digital products & models", horizon: "3–9 months", effort: 3, tech: 4 },
    { s: "growth", focus: "Markets, segments & offers", horizon: "2–6 months", effort: 2, tech: 1 },
    { s: "enterprise", focus: "Platforms & architecture", horizon: "6–24 months", effort: 4, tech: 4 },
    { s: "performance", focus: "Efficiency & margins", horizon: "3–12 months", effort: 3, tech: 2 },
    { s: "advisory", focus: "High-stakes decisions", horizon: "1–3 months", effort: 1, tech: 1 }
  ];

  var IND_GROUPS = [
    { id: "all", label: "All industries" },
    { id: "digital", label: "Digital & Finance" },
    { id: "consumer", label: "Consumer & Care" },
    { id: "industrial", label: "Industrial & Property" }
  ];

  var INDUSTRIES = [
    { id: "technology", name: "Technology & Software", group: "digital", icon: "chip", image: "assets/illustrations/industry-technology.svg",
      overview: "Software and technology companies compete on speed, talent and product-market fit. We help them scale without losing the agility that got them started.",
      challenges: ["Scaling teams and processes quickly", "Balancing product innovation with profitability", "Crowded, fast-moving competitive landscapes"],
      services: ["strategy", "technology", "development"],
      opportunities: ["Platform and ecosystem partnerships", "Expansion into adjacent segments", "AI-enabled product features"],
      recommendations: ["Align roadmap investment to a small set of strategic bets", "Build repeatable go-to-market motions before scaling spend", "Treat architecture as a growth enabler, not a cost"] },
    { id: "financial", name: "Financial Services", group: "digital", icon: "pie", image: "assets/illustrations/industry-financial.svg",
      overview: "Banks, insurers and fintechs face rising expectations for digital service alongside rigorous regulation. We help them modernize while managing risk.",
      challenges: ["Legacy platforms limiting agility", "Regulatory change and compliance cost", "Competition from digital-first entrants"],
      services: ["digital", "financial", "operations"],
      opportunities: ["Digital onboarding and servicing", "Data-driven personalization", "Process automation in operations"],
      recommendations: ["Modernize in phases, starting with the highest-friction journeys", "Build compliance into process design", "Use data to shift from products to customer outcomes"] },
    { id: "healthcare", name: "Healthcare", group: "consumer", icon: "heart", image: "assets/illustrations/industry-healthcare.svg",
      overview: "Healthcare organizations must improve outcomes and access while controlling cost and protecting data. We support operational and digital change that respects those priorities.",
      challenges: ["Capacity and cost pressure", "Fragmented data and systems", "Complex regulatory and privacy requirements"],
      services: ["operations", "digital", "technology"],
      opportunities: ["Streamlined patient journeys", "Better use of operational data", "Care-delivery model innovation"],
      recommendations: ["Start with patient and staff pain points, then choose technology", "Improve data interoperability before layering new tools", "Pilot changes in one unit, then scale"] },
    { id: "retail", name: "Retail & E-commerce", group: "consumer", icon: "bag", image: "assets/illustrations/industry-retail.svg",
      overview: "Retailers need to connect physical and digital channels while protecting margin. We help them build resilient, customer-centric commercial models.",
      challenges: ["Rising customer acquisition costs", "Omnichannel complexity", "Margin pressure and inventory risk"],
      services: ["development", "digital", "financial"],
      opportunities: ["Loyalty and personalization", "New marketplaces and channels", "Smarter inventory and pricing"],
      recommendations: ["Unify customer data across channels", "Focus on contribution margin, not just revenue", "Test new channels with low-cost pilots"] },
    { id: "manufacturing", name: "Manufacturing", group: "industrial", icon: "gear", image: "assets/illustrations/industry-manufacturing.svg",
      overview: "Manufacturers are balancing efficiency, resilience and digital modernization. We help them improve operations and plan technology investments with clear returns.",
      challenges: ["Supply chain volatility", "Aging equipment and processes", "Skills gaps on the shop floor"],
      services: ["operations", "technology", "financial"],
      opportunities: ["Connected, data-driven production", "Supplier diversification", "Service-based revenue models"],
      recommendations: ["Prioritize process stability before automation", "Build a business case for each digital use case", "Invest in skills alongside technology"] },
    { id: "realestate", name: "Real Estate", group: "industrial", icon: "building", image: "assets/illustrations/industry-realestate.svg",
      overview: "Property owners and developers are rethinking how space is used, financed and managed. We bring strategic and financial clarity to portfolio decisions.",
      challenges: ["Shifting demand for space", "Capital allocation across a portfolio", "Rising sustainability expectations"],
      services: ["strategy", "financial", "development"],
      opportunities: ["Repositioning assets for new uses", "Digital tenant and asset management", "Sustainability-led value creation"],
      recommendations: ["Segment the portfolio by strategic role", "Model scenarios before committing capital", "Use building data to improve operations"] },
    { id: "logistics", name: "Logistics & Transportation", group: "industrial", icon: "truck", image: "assets/illustrations/industry-logistics.svg",
      overview: "Logistics providers operate on thin margins and tight timelines. We help them optimize networks, adopt technology and create differentiated services.",
      challenges: ["Network complexity and cost", "Visibility across the chain", "Capacity and workforce constraints"],
      services: ["operations", "technology", "development"],
      opportunities: ["Real-time tracking and analytics", "Value-added service offerings", "Partnership-led network expansion"],
      recommendations: ["Improve visibility before optimizing routes", "Standardize processes across sites", "Explore partnerships to extend reach"] },
    { id: "professional", name: "Professional Services", group: "digital", icon: "briefcase", image: "assets/illustrations/industry-professional.svg",
      overview: "Firms built on expertise must scale knowledge and protect utilization. We help them modernize delivery and build differentiated offers.",
      challenges: ["Utilization and pricing pressure", "Knowledge locked in individuals", "Client expectations for digital delivery"],
      services: ["strategy", "digital", "operations"],
      opportunities: ["Productized and recurring services", "Digital delivery platforms", "New advisory niches"],
      recommendations: ["Codify repeatable methods into reusable assets", "Align pricing to value delivered", "Invest in a client-facing digital experience"] }
  ];

  /* Expose for other scripts (e.g. search, home page, forms). */
  NX.data = NX.data || {};
  NX.data.SERVICES = SERVICES; NX.data.SOLUTIONS = SOLUTIONS; NX.data.INDUSTRIES = INDUSTRIES;

  var byId = function (arr, id) { return arr.filter(function (x) { return x.id === id; })[0]; };
  var contactHref = function (subject) { return "contact.html?service=" + encodeURIComponent(subject) + "#contact-form"; };

  /* ------------------------------------------------------------- RENDERERS */

  /* Home + shared: six service cards */
  function renderServiceCards(host) {
    host.innerHTML = SERVICES.map(function (s) {
      return '<article class="svc-card" id="card-' + s.id + '">' +
        '<a class="svc-card__img" href="services.html#' + s.id + '" tabindex="-1" aria-hidden="true">' + NX.img(s, s.name + " — abstract illustration", 1600, 1000) + '<span class="svc-card__num">' + s.num + "</span></a>" +
        '<div class="svc-card__body">' + NX.iconBox(s.icon) + '<h3 class="h-card">' + esc(s.name) + "</h3><p>" + esc(s.summary) + '</p>' +
        '<a class="link-arrow" href="services.html#' + s.id + '">Discover more <span aria-hidden="true">→</span></a></div></article>';
    }).join("");
    host.setAttribute("data-stagger", "");
    NX.reveal(host);
  }

  /* Services page: expandable list + filters */
  function renderServicesList(host) {
    host.innerHTML = SERVICES.map(function (s) {
      var rel = s.related.map(function (id) { var x = byId(SOLUTIONS, id); return x ? '<a href="solutions.html#' + x.id + '">' + esc(x.name) + "</a>" : ""; }).join("");
      return '<article class="svc-item reveal" id="' + s.id + '" data-cat="' + s.group + '">' +
        '<div class="svc-item__media">' + NX.img(s, s.name + " — abstract illustration", 1600, 1000) + '<span class="svc-item__big" aria-hidden="true">' + s.num + "</span></div>" +
        '<div class="svc-item__body"><span class="svc-item__cat">' + esc((byId(SERVICE_GROUPS, s.group) || {}).label) + "</span>" +
        '<h2 class="h-section" style="font-size:clamp(1.7rem,3vw,2.5rem)">' + esc(s.name) + "</h2><p>" + esc(s.description) + "</p>" +
        '<div class="expand" id="svc-more-' + s.id + '" inert><div><div class="expand__inner">' +
        '<div><h4>Key benefits</h4><ul class="check-list">' + s.benefits.map(function (b) { return "<li>" + esc(b) + "</li>"; }).join("") + "</ul></div>" +
        '<div><h4>Areas of expertise</h4><div class="chips">' + s.expertise.map(function (e) { return '<span class="tag">' + esc(e) + "</span>"; }).join("") + "</div></div>" +
        '<div><h4>Related solutions</h4><div class="rel-links">' + rel + "</div></div></div></div></div>" +
        '<div class="row"><button type="button" class="btn btn--ghost btn--sm toggle-btn" aria-expanded="false" aria-controls="svc-more-' + s.id + '"><span class="toggle-label">Discover more</span> <span class="arr" aria-hidden="true">＋</span></button>' +
        '<a class="btn btn--sm" href="' + contactHref(s.name) + '">Enquire about this service <span class="arr" aria-hidden="true">→</span></a></div></div></article>';
    }).join("");

    host.addEventListener("click", function (e) {
      var b = e.target.closest(".toggle-btn");
      if (!b) return;
      var open = NX.toggleExpand(b, document.getElementById(b.getAttribute("aria-controls")));
      b.querySelector(".toggle-label").textContent = open ? "Show less" : "Discover more";
      b.querySelector(".arr").textContent = open ? "－" : "＋";
    });

    var bar = $("[data-filters='services']");
    if (bar) {
      bar.innerHTML = NX.filterButtons(SERVICE_GROUPS) + '<span class="filter-status" role="status" aria-live="polite"></span>';
      NX.filterable({ bar: bar, items: function () { return $$(".svc-item", host); }, status: $(".filter-status", bar), noun: "services" })("all");
    }
    NX.reveal(host);

    /* Deep link: services.html#digital opens + highlights that service */
    function openFromHash() {
      var id = location.hash.slice(1), el = id && document.getElementById(id);
      if (!el || !el.classList.contains("svc-item")) return;
      var all = $('[data-filter="all"]'); if (all && all.getAttribute("aria-pressed") !== "true") all.click();
      var btn = $(".toggle-btn", el); if (btn && btn.getAttribute("aria-expanded") !== "true") btn.click();
      el.classList.add("is-target"); el.classList.add("in");
      setTimeout(function () { el.scrollIntoView({ behavior: NX.reduceMotion ? "auto" : "smooth", block: "start" }); }, 80);
      setTimeout(function () { el.classList.remove("is-target"); }, 3200);
    }
    openFromHash();
    window.addEventListener("hashchange", openFromHash);
  }

  /* Solutions page */
  function renderSolutions(host) {
    host.innerHTML = SOLUTIONS.map(function (s) {
      return '<section class="sol reveal" id="' + s.id + '" aria-labelledby="h-' + s.id + '">' +
        '<div class="sol__head"><span class="sol__num">' + s.num + '</span><span class="eyebrow">Solution</span></div>' +
        '<h2 class="h-section" id="h-' + s.id + '" style="font-size:clamp(1.8rem,3.4vw,2.9rem)">' + esc(s.name) + "</h2>" +
        '<p class="lead">' + esc(s.explanation) + "</p>" +
        '<div class="sol__media">' + NX.img(s, s.name + " — illustration", 1600, 850) + "</div>" +
        '<div class="sol__cols"><div><h4>Business challenges addressed</h4><ul class="check-list">' + s.challenges.map(function (c) { return "<li>" + esc(c) + "</li>"; }).join("") + "</ul></div>" +
        '<div><h4>Key benefits</h4><ul class="check-list">' + s.benefits.map(function (c) { return "<li>" + esc(c) + "</li>"; }).join("") + "</ul></div></div>" +
        '<div><h4 class="label" style="margin-bottom:14px">Our methodology</h4><ol class="method">' + s.method.map(function (m) { return "<li>" + esc(m) + "</li>"; }).join("") + "</ol></div>" +
        '<div><h4 class="label" style="margin-bottom:12px">Related services</h4><div class="rel-links">' + s.services.map(function (id) { var x = byId(SERVICES, id); return '<a href="services.html#' + id + '">' + esc(x.name) + "</a>"; }).join("") + "</div></div>" +
        '<div class="row"><a class="btn" href="' + contactHref(s.name) + '">Discuss this solution <span class="arr" aria-hidden="true">→</span></a></div></section>';
    }).join("");
    NX.reveal(host);

    var idx = $("[data-render='solutions-index']");
    if (idx) {
      idx.innerHTML = SOLUTIONS.map(function (s) { return '<a href="#' + s.id + '" data-id="' + s.id + '">' + esc(s.name) + "</a>"; }).join("");
      if ("IntersectionObserver" in window) {
        var links = $$("a", idx);
        var obs = new IntersectionObserver(function (entries) {
          entries.forEach(function (en) {
            if (en.isIntersecting) links.forEach(function (l) { l.classList.toggle("is-active", l.getAttribute("data-id") === en.target.id); });
          });
        }, { rootMargin: "-35% 0px -55% 0px" });
        $$(".sol", host).forEach(function (s) { obs.observe(s); });
      }
    }
  }

  /* Solution finder */
  function renderFinder(host) {
    host.innerHTML = '<div><span class="eyebrow">Solution discovery</span><h2 class="h-section" style="margin:20px 0 18px;font-size:clamp(1.8rem,3.2vw,2.8rem)">What are you <em>trying to solve?</em></h2><p class="lead" style="margin-bottom:26px">Pick the challenge that sounds most like yours and we\'ll suggest where to start.</p>' +
      '<div class="finder__opts" role="group" aria-label="Choose a business challenge">' + CHALLENGES.map(function (c) { return '<button type="button" class="finder__opt" data-challenge="' + c.id + '" aria-pressed="false"><span>' + esc(c.label) + '</span><span aria-hidden="true">→</span></button>'; }).join("") + "</div></div>" +
      '<div class="finder__result" aria-live="polite" id="finder-result"><span class="label" style="color:rgba(255,255,255,.6)">Recommendation</span><h3>Select a challenge to see suggested solutions.</h3><p>Recommendations are illustrative and meant to show how the solution-discovery interaction works.</p></div>';
    var out = $("#finder-result", host);
    host.addEventListener("click", function (e) {
      var b = e.target.closest("[data-challenge]"); if (!b) return;
      $$("[data-challenge]", host).forEach(function (x) { x.setAttribute("aria-pressed", String(x === b)); });
      var c = byId(CHALLENGES, b.getAttribute("data-challenge"));
      out.innerHTML = '<span class="label" style="color:rgba(255,255,255,.6)">Suggested starting points</span><h3>' + esc(c.label) + "</h3>" +
        c.solutions.map(function (id, i) { var s = byId(SOLUTIONS, id); return '<a class="pill" href="#' + id + '"><span>' + esc(s.name) + '<br><small>' + (i === 0 ? "Best fit" : "Also relevant") + '</small></span><span aria-hidden="true">→</span></a>'; }).join("") +
        '<a class="btn btn--light btn--sm" href="' + contactHref(c.label) + '" style="justify-self:start">Talk to us about this <span class="arr" aria-hidden="true">→</span></a>';
    });
  }

  /* Comparison table */
  function renderCompare(host) {
    function dots(n) { var h = '<span class="dots" role="img" aria-label="' + n + ' out of 4">'; for (var i = 1; i <= 4; i++) h += '<i class="' + (i <= n ? "on" : "") + '"></i>'; return h + "</span>"; }
    host.innerHTML = '<table class="compare"><caption class="visually-hidden">Illustrative comparison of NEXORA solutions</caption><thead><tr><th scope="col">Solution</th><th scope="col">Primary focus</th><th scope="col">Typical horizon</th><th scope="col">Change effort</th><th scope="col">Technology intensity</th></tr></thead><tbody>' +
      COMPARE.map(function (r) { var s = byId(SOLUTIONS, r.s); return '<tr><th scope="row"><a href="#' + s.id + '">' + esc(s.name) + "</a></th><td>" + esc(r.focus) + "</td><td>" + esc(r.horizon) + "</td><td>" + dots(r.effort) + "</td><td>" + dots(r.tech) + "</td></tr>"; }).join("") + "</tbody></table>";
  }

  /* Industries page grid */
  function renderIndustries(host) {
    host.innerHTML = INDUSTRIES.map(function (n) {
      var g = byId(IND_GROUPS, n.group) || {};
      return '<article class="ind-card reveal" id="' + n.id + '" data-cat="' + n.group + '">' +
        '<div class="ind-card__img">' + NX.img(n, n.name + " — abstract illustration", 1600, 1000) + '<span class="tag">' + esc(g.label) + "</span></div>" +
        '<div class="ind-card__body"><div class="row" style="gap:14px;flex-wrap:nowrap">' + NX.iconBox(n.icon) + '<h2 class="h-card" style="font-size:clamp(1.3rem,2vw,1.7rem)">' + esc(n.name) + "</h2></div><p>" + esc(n.overview) + "</p>" +
        '<div class="expand" id="ind-more-' + n.id + '" inert><div><div class="expand__inner">' +
        '<div><h4>Key business challenges</h4><ul class="check-list">' + n.challenges.map(function (c) { return "<li>" + esc(c) + "</li>"; }).join("") + "</ul></div>" +
        '<div><h4>Relevant NEXORA services</h4><div class="rel-links">' + n.services.map(function (id) { return '<a href="services.html#' + id + '">' + esc(byId(SERVICES, id).name) + "</a>"; }).join("") + "</div></div>" +
        '<div><h4>Potential opportunities</h4><ul class="check-list">' + n.opportunities.map(function (c) { return "<li>" + esc(c) + "</li>"; }).join("") + "</ul></div>" +
        '<div><h4>Strategic recommendations</h4><ul class="check-list">' + n.recommendations.map(function (c) { return "<li>" + esc(c) + "</li>"; }).join("") + "</ul></div>" +
        '<a class="btn btn--sm" href="' + contactHref(n.name) + '" style="justify-self:start">Discuss your industry <span class="arr" aria-hidden="true">→</span></a></div></div></div>' +
        '<div><button type="button" class="link-arrow toggle-btn" aria-expanded="false" aria-controls="ind-more-' + n.id + '"><span class="toggle-label">View industry profile</span> <span class="arr" aria-hidden="true">→</span></button></div></div></article>';
    }).join("");

    host.addEventListener("click", function (e) {
      var b = e.target.closest(".toggle-btn"); if (!b) return;
      var open = NX.toggleExpand(b, document.getElementById(b.getAttribute("aria-controls")));
      b.querySelector(".toggle-label").textContent = open ? "Hide industry profile" : "View industry profile";
    });

    var bar = $("[data-filters='industries']");
    if (bar) {
      bar.innerHTML = NX.filterButtons(IND_GROUPS) + '<span class="filter-status" role="status" aria-live="polite"></span>';
      NX.filterable({ bar: bar, items: function () { return $$(".ind-card", host); }, status: $(".filter-status", bar), noun: "industries" })("all");
    }
    NX.reveal(host);

    function openFromHash() {
      var id = location.hash.slice(1), el = id && document.getElementById(id);
      if (!el || !el.classList.contains("ind-card")) return;
      var all = $('[data-filter="all"]'); if (all && all.getAttribute("aria-pressed") !== "true") all.click();
      var btn = $(".toggle-btn", el); if (btn && btn.getAttribute("aria-expanded") !== "true") btn.click();
      el.classList.add("is-target", "in");
      setTimeout(function () { el.scrollIntoView({ behavior: NX.reduceMotion ? "auto" : "smooth", block: "center" }); }, 80);
      setTimeout(function () { el.classList.remove("is-target"); }, 3200);
    }
    openFromHash();
    window.addEventListener("hashchange", openFromHash);
  }

  /* Home: industries showcase (list ↔ preview) */
  function renderIndShowcase(host) {
    host.innerHTML = '<div class="ind-show__list" role="tablist" aria-label="Industries we serve">' +
      INDUSTRIES.map(function (n, i) { return '<button type="button" role="tab" class="ind-show__item" id="tab-' + n.id + '" aria-selected="' + (i === 0) + '" aria-controls="ind-preview" data-i="' + i + '"><span>' + esc(n.name) + "</span><small>0" + (i + 1) + "</small></button>"; }).join("") + "</div>" +
      '<div class="ind-show__preview" id="ind-preview" role="tabpanel" aria-live="polite">' +
      INDUSTRIES.map(function (n, i) { return NX.img(n, n.name + " — abstract illustration", 1600, 1000).replace("<img ", '<img class="' + (i === 0 ? "is-active" : "") + '" data-i="' + i + '" '); }).join("") +
      '<div class="ind-show__caption"><h3 class="h-card" style="color:#fff;font-size:1.5rem" data-cap-title></h3><p data-cap-text></p><a class="link-arrow" data-cap-link href="industries.html">Explore this industry <span aria-hidden="true">→</span></a></div></div>';
    var tabs = $$(".ind-show__item", host), imgs = $$(".ind-show__preview img", host);
    var t = $("[data-cap-title]", host), p = $("[data-cap-text]", host), l = $("[data-cap-link]", host);
    function select(i) {
      tabs.forEach(function (b, k) { b.setAttribute("aria-selected", String(k === i)); });
      imgs.forEach(function (im, k) { im.classList.toggle("is-active", k === i); });
      var n = INDUSTRIES[i]; t.textContent = n.name; p.textContent = n.overview; l.href = "industries.html#" + n.id;
    }
    tabs.forEach(function (b, i) {
      b.addEventListener("click", function () { select(i); });
      b.addEventListener("mouseenter", function () { if (window.matchMedia("(hover:hover)").matches) select(i); });
      b.addEventListener("focus", function () { select(i); });
    });
    select(0);
  }

  /* ---------------------------------------------------------------- BOOT */
  function boot() {
    $$("[data-render]").forEach(function (h) {
      var k = h.getAttribute("data-render");
      try {
        if (k === "services-cards") renderServiceCards(h);
        else if (k === "services-list") renderServicesList(h);
        else if (k === "solutions") renderSolutions(h);
        else if (k === "finder") renderFinder(h);
        else if (k === "compare") renderCompare(h);
        else if (k === "industries") renderIndustries(h);
        else if (k === "industries-showcase") renderIndShowcase(h);
      } catch (err) { if (window.console) console.error("[NEXORA] render failed:", k, err); }
    });
  }
  boot();
})();
