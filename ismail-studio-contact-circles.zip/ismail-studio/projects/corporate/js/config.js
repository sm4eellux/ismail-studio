/* ==========================================================================
   NEXORA — config.js
   ONE place for contact details, integrations and 3D settings.
   Every value below is a FICTIONAL PLACEHOLDER for this demonstration project.
   Replace them with real details before using the template for a real client.
   ========================================================================== */
window.NEXORA_CONFIG = {

  brand: {
    name: "NEXORA",
    tagline: "STRATEGY. INNOVATION. GROWTH."
  },

  /* ---- Contact details (shown in the footer, contact page and forms) ---- */
  contact: {
    addressLines: ["100 Example Avenue, Floor 12", "Placeholder City, 00000"],
    phone: "+00 000 000 0000",                 // placeholder
    email: "hello@nexora.example",             // placeholder (.example is a reserved, non-routable domain)
    careersEmail: "careers@nexora.example",    // placeholder
    linkedin: "https://www.linkedin.com/",     // replace with your company page URL
    x: "https://x.com/",                       // replace or delete
    youtube: "https://www.youtube.com/",       // replace or delete
    /* WhatsApp number in international format, digits only (e.g. "447700900123").
       Leave empty until you have a real number: the site will then show the
       WhatsApp card as "not configured" instead of linking to a fake number. */
    whatsappNumber: "",
    whatsappMessage: "Hello NEXORA, I'd like to discuss a business challenge.",
    mapsQuery: "100 Example Avenue Placeholder City"  // used to build the Google Maps link
  },

  /* ---- Office hours ---- */
  hours: [
    ["Monday – Friday", "08:30 – 18:00"],
    ["Saturday", "By appointment"],
    ["Sunday", "Closed"]
  ],

  /* ---- EmailJS (contact + careers forms) ----
     The forms are only reported as SENT when EmailJS is fully configured AND the
     request succeeds. With empty values the site shows a configuration notice and
     offers direct email / WhatsApp instead. It never fakes a successful delivery. */
  emailjs: {
    publicKey: "",
    serviceId: "",
    templateId: "",           // contact form template
    careersTemplateId: "",    // optional separate template for job applications
    sdkUrl: "https://cdn.jsdelivr.net/npm/@emailjs/browser@4.4.1/dist/email.min.js"
  },

  /* ---- Optional newsletter endpoint ----
     URL that accepts POST {email}. Leave empty and the newsletter form will say
     that no subscription service is connected (nothing is stored or sent). */
  newsletter: { endpoint: "" },

  /* ---- Optional careers endpoint ----
     URL that accepts a multipart POST (e.g. a Formspree form endpoint) incl. the CV file.
     Empty = applications are validated but NOT submitted (the page says so honestly). */
  careers: { endpoint: "" },

  /* ---- 3D hero (Three.js) ---- */
  scene: {
    enabled: true,          // set false to always use the static hero image
    particles: 140,         // floating particles on desktop (mobile uses fewer)
    accent: 0x315EF5,       // main light colour
    accent2: 0x6B8CFF,      // secondary light colour
    mouseStrength: 0.35,    // camera response to mouse movement (0 = off)
    rotationSpeed: 0.12     // idle rotation speed
  }
};
