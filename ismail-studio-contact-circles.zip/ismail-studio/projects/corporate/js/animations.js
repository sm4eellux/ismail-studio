/* ==========================================================================
   NEXORA — animations.js
   1. Scroll-reveal (IntersectionObserver, no dependencies)
   2. GSAP + ScrollTrigger enhancements (hero entrance, parallax, counters)
   Everything degrades gracefully: without GSAP the CSS reveals still work,
   and with prefers-reduced-motion nothing is animated.
   ========================================================================== */
(function () {
  "use strict";
  var NX = window.NX = window.NX || {};
  var root = document.documentElement;
  var reduce = NX.reduceMotion;
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  /* ---------- 1. scroll reveal ---------- */
  if (!reduce) root.classList.add("nx-anim");

  var io = null;
  if ("IntersectionObserver" in window && !reduce) {
    io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add("in"); io.unobserve(en.target); }
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -6% 0px" });
  }

  function reveal(scope) {
    scope = scope || document;
    // [data-stagger] children reveal one after another
    $$("[data-stagger]", scope).concat(scope.matches && scope.matches("[data-stagger]") ? [scope] : []).forEach(function (p) {
      Array.prototype.forEach.call(p.children, function (c, i) {
        if (!c.classList.contains("reveal")) c.classList.add("reveal");
        if (!c.style.getPropertyValue("--d")) c.style.setProperty("--d", Math.min(i * 0.08, 0.48) + "s");
      });
    });
    var els = $$(".reveal:not(.in), .img-reveal:not(.in)", scope);
    if (scope.matches && scope.matches(".reveal:not(.in)")) els.push(scope);
    els.forEach(function (el) {
      if (!io) { el.classList.add("in"); return; }
      io.observe(el);
    });
    if (window.ScrollTrigger && window.gsap) { clearTimeout(reveal._t); reveal._t = setTimeout(function () { window.ScrollTrigger.refresh(); }, 250); }
  }
  NX.reveal = reveal;
  if (NX._flush) NX._flush();
  reveal(document);

  /* ---------- 2. GSAP enhancements ---------- */
  function initGsap() {
    var gsap = window.gsap, ST = window.ScrollTrigger;
    if (!gsap || reduce) return;
    try {
      if (ST) gsap.registerPlugin(ST);
      root.classList.add("gsap-on");

      /* Hero headline: line-by-line mask reveal (starts once the loader is done) */
      var lines = $$(".hero__title .line > span, .page-hero__title .line > span");
      var heroItems = $$(".hero-in");
      if (lines.length) gsap.set(lines, { yPercent: 115 });
      if (heroItems.length) gsap.set(heroItems, { opacity: 0, y: 28 });
      var started = false;
      function playHero() {
        if (started) return; started = true;
        var tl = gsap.timeline({ defaults: { ease: "power4.out" } });
        if (lines.length) tl.to(lines, { yPercent: 0, duration: 1.2, stagger: 0.12 });
        if (heroItems.length) tl.to(heroItems, { opacity: 1, y: 0, duration: 0.9, stagger: 0.1, clearProps: "transform" }, lines.length ? "-=0.7" : 0);
      }
      if (NX.isReady) playHero(); else document.addEventListener("nx:ready", playHero);
      setTimeout(playHero, 5200); // failsafe

      if (!ST) return;

      /* Gentle parallax: any element with data-parallax="0.15" */
      $$("[data-parallax]").forEach(function (el) {
        var s = parseFloat(el.getAttribute("data-parallax")) || 0.12;
        gsap.to(el, { yPercent: -s * 100, ease: "none", scrollTrigger: { trigger: el.parentElement || el, start: "top bottom", end: "bottom top", scrub: 0.6 } });
      });

      /* Hero: content drifts up & fades while scrolling away */
      var heroInner = document.querySelector(".hero__inner");
      if (heroInner) gsap.to(heroInner, { y: -70, opacity: 0.2, ease: "none", scrollTrigger: { trigger: ".hero", start: "top top", end: "bottom top", scrub: true } });

      /* Approach timeline line draws as you scroll */
      var line = document.querySelector(".approach__line");
      if (line && window.matchMedia("(min-width: 1025px)").matches) {
        gsap.to(line, { scaleX: 1, ease: "none", scrollTrigger: { trigger: ".approach", start: "top 75%", end: "bottom 60%", scrub: 0.5 } });
      }

      /* Animated counters: <span data-count="4">0</span> */
      $$("[data-count]").forEach(function (el) {
        var end = parseFloat(el.getAttribute("data-count")) || 0, o = { v: 0 };
        ST.create({ trigger: el, start: "top 90%", once: true, onEnter: function () {
          gsap.to(o, { v: end, duration: 1.6, ease: "power2.out", onUpdate: function () { el.textContent = Math.round(o.v); } });
        } });
      });
    } catch (err) {
      // Animation is an enhancement only: never let it break the page.
      root.classList.remove("gsap-on");
      if (window.console) console.warn("[NEXORA] GSAP enhancement skipped:", err);
    }
  }

  // GSAP loads with `defer` before this file; if the CDN is slow/blocked we simply skip.
  if (window.gsap) initGsap();
  else window.addEventListener("load", function () { if (window.gsap) initGsap(); });
})();
