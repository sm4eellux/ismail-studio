/* ==========================================================================
   NEXORA — main.js
   Shared namespace (window.NX), helpers, icon set, config binding, loader and
   page transitions. Loaded on every page BEFORE the feature scripts.
   ========================================================================== */
(function () {
  "use strict";

  var CFG = window.NEXORA_CONFIG || {};
  var NX = (window.NX = window.NX || {});
  NX.cfg = CFG;
  NX.reduceMotion = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---------- tiny helpers ---------- */
  NX.$ = function (sel, root) { return (root || document).querySelector(sel); };
  NX.$$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };
  NX.esc = function (s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  };
  NX.debounce = function (fn, ms) { var t; return function () { var a = arguments, c = this; clearTimeout(t); t = setTimeout(function () { fn.apply(c, a); }, ms); }; };

  /* Reveal queue — animations.js replaces this with the real observer. */
  var queue = [];
  NX.reveal = function (scope) { queue.push(scope || document); };
  NX._flush = function () { var q = queue; queue = []; q.forEach(function (s) { NX.reveal(s); }); };

  /* ---------- icon set (24px stroke icons) ---------- */
  var P = {
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.2"/>',
    layers: '<path d="M12 3l9 5-9 5-9-5 9-5z"/><path d="M3 13l9 5 9-5"/>',
    chip: '<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4"/>',
    trend: '<path d="M3 17l6-6 4 4 8-8"/><path d="M15 7h6v6"/>',
    pie: '<path d="M12 3v9h9"/><path d="M20.5 15A9 9 0 1 1 9 3.5"/>',
    gear: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1"/>',
    bulb: '<path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.2 1 2.1h5c0-.9.4-1.6 1-2.1A6 6 0 0 0 12 3z"/>',
    users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><circle cx="17" cy="9" r="2.5"/><path d="M17 14.5a5 5 0 0 1 4.5 5"/>',
    shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6l8-3z"/><path d="M9 12l2 2 4-4"/>',
    compass: '<circle cx="12" cy="12" r="9"/><path d="M15.5 8.5l-2 5-5 2 2-5z"/>',
    building: '<rect x="4" y="3" width="10" height="18" rx="1"/><path d="M14 9h6v12h-6M8 7h2M8 11h2M8 15h2"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/>',
    heart: '<path d="M12 20s-7-4.5-7-10a4 4 0 0 1 7-2.5A4 4 0 0 1 19 10c0 5.5-7 10-7 10z"/>',
    bag: '<path d="M5 8h14l-1 12H6L5 8z"/><path d="M9 8a3 3 0 0 1 6 0"/>',
    truck: '<path d="M2 6h11v10H2zM13 9h4l4 4v3h-8"/><circle cx="7" cy="18" r="2"/><circle cx="17" cy="18" r="2"/>',
    briefcase: '<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M9 7V5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2M3 13h18"/>',
    book: '<path d="M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2V5z"/><path d="M4 19a2 2 0 0 1 2-2h13"/>',
    coffee: '<path d="M4 9h13v5a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5V9z"/><path d="M17 11h2a2 2 0 0 1 0 4h-2M8 3v3M12 3v3"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
    close: '<path d="M5 5l14 14M19 5L5 19"/>',
    upload: '<path d="M12 16V4M7 9l5-5 5 5"/><path d="M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3"/>',
    mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',
    phone: '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/>',
    pin: '<path d="M12 21s7-6.2 7-11.5A7 7 0 0 0 5 9.5C5 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    chat: '<path d="M4 20l1.4-4.2A8 8 0 1 1 8.2 18.6L4 20z"/>',
    map: '<path d="M9 4L3 6v14l6-2 6 2 6-2V4l-6 2-6-2zM9 4v14M15 6v14"/>'
  };
  NX.icon = function (name, cls) {
    return '<svg class="' + (cls || "") + '" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' + (P[name] || P.target) + "</svg>";
  };
  NX.iconBox = function (name) { return '<span class="icon-box">' + NX.icon(name) + "</span>"; };
  NX.social = {
    linkedin: "M4.98 3.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5zM3 9.5h4V21H3zM9.5 9.5h3.8v1.6h.1c.5-1 1.8-1.9 3.7-1.9 4 0 4.9 2.6 4.9 6V21h-4v-5.1c0-1.2 0-2.8-1.7-2.8s-2 1.3-2 2.7V21h-4z",
    x: "M18.2 3h3.1l-6.8 7.7L22.5 21h-6.3l-4.9-6.4L5.6 21H2.5l7.3-8.3L2 3h6.4l4.4 5.9L18.2 3zm-1.1 16.2h1.7L7.3 4.7H5.5l11.6 14.5z",
    youtube: "M21.6 7.2a2.5 2.5 0 0 0-1.8-1.8C18.3 5 12 5 12 5s-6.3 0-7.8.4A2.5 2.5 0 0 0 2.4 7.2C2 8.7 2 12 2 12s0 3.3.4 4.8a2.5 2.5 0 0 0 1.8 1.8C5.7 19 12 19 12 19s6.3 0 7.8-.4a2.5 2.5 0 0 0 1.8-1.8c.4-1.5.4-4.8.4-4.8s0-3.3-.4-4.8zM10 15V9l5.2 3L10 15z"
  };
  NX.socialIcon = function (name) { return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="' + NX.social[name] + '"/></svg>'; };

  /* Image helper: local illustration by default, optional `photo` URL override
     that falls back to the illustration if it fails to load. */
  NX.img = function (item, alt, w, h, eager) {
    var src = item.photo || item.image;
    var fb = item.photo ? ' onerror="this.onerror=null;this.src=\'' + NX.esc(item.image) + '\'"' : "";
    return '<img src="' + NX.esc(src) + '" alt="' + NX.esc(alt) + '" width="' + (w || 1600) + '" height="' + (h || 1000) + '"' + (eager ? "" : ' loading="lazy"') + ' decoding="async"' + fb + ">";
  };

  /* ---------- contact links built from config ---------- */
  NX.links = function () {
    var c = CFG.contact || {};
    var wa = String(c.whatsappNumber || "").replace(/\D/g, "");
    return {
      email: c.email ? "mailto:" + c.email : "",
      careers: c.careersEmail ? "mailto:" + c.careersEmail : "",
      phone: c.phone ? "tel:" + String(c.phone).replace(/[^\d+]/g, "") : "",
      whatsapp: wa ? "https://wa.me/" + wa + "?text=" + encodeURIComponent(c.whatsappMessage || "") : "",
      maps: "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(c.mapsQuery || (c.addressLines || []).join(" "))
    };
  };

  /* Fill [data-cfg="..."] elements from config. */
  function bindConfig() {
    var c = CFG.contact || {}, L = NX.links();
    NX.$$("[data-link]").forEach(function (el) {            // href-only bindings
      var h = L[el.getAttribute("data-link")]; if (h) el.href = h;
    });
    NX.$$("[data-cfg]").forEach(function (el) {
      var k = el.getAttribute("data-cfg");
      switch (k) {
        case "address": el.innerHTML = (c.addressLines || []).map(NX.esc).join("<br>"); break;
        case "phone": el.textContent = c.phone || ""; if (el.tagName === "A") el.href = L.phone; break;
        case "email": el.textContent = c.email || ""; if (el.tagName === "A") el.href = L.email; break;
        case "careersEmail": el.textContent = c.careersEmail || ""; if (el.tagName === "A") el.href = L.careers; break;
        case "linkedin": el.href = c.linkedin || "#"; break;
        case "x": el.href = c.x || "#"; break;
        case "youtube": el.href = c.youtube || "#"; break;
        case "maps": el.href = L.maps; break;
        case "whatsapp":
          if (L.whatsapp) { el.href = L.whatsapp; el.removeAttribute("aria-disabled"); }
          else { el.removeAttribute("href"); el.setAttribute("aria-disabled", "true"); var s = el.querySelector("[data-wa-text]"); if (s) s.textContent = "Not configured — add your number in js/config.js"; }
          break;
        case "hours":
          el.innerHTML = (CFG.hours || []).map(function (h) { return "<div><span>" + NX.esc(h[0]) + "</span><span>" + NX.esc(h[1]) + "</span></div>"; }).join("");
          break;
      }
    });
  }

  /* ---------- loader (home page only) ---------- */
  function initLoader() {
    var loader = NX.$(".loader");
    var done = false;
    function finish() {
      if (done) return; done = true;
      try { sessionStorage.setItem("nexora-loaded", "1"); } catch (e) {}
      if (loader) loader.classList.add("is-done");
      document.documentElement.classList.add("nx-loaded");
      setTimeout(function () { NX.isReady = true; document.dispatchEvent(new CustomEvent("nx:ready")); }, loader ? 250 : 0);
    }
    NX.ready = finish;
    if (!loader || document.documentElement.classList.contains("no-loader")) { finish(); return; }
    var start = Date.now(), min = 1100;
    function whenLoaded() { setTimeout(finish, Math.max(0, min - (Date.now() - start))); }
    if (document.readyState === "complete") whenLoaded(); else window.addEventListener("load", whenLoaded);
    setTimeout(finish, 4000); // hard failsafe: never block the page
  }

  /* ---------- smooth page transitions ---------- */
  function initTransitions() {
    var curtain = NX.$(".curtain");
    if (!curtain || NX.reduceMotion) return;
    document.addEventListener("click", function (e) {
      var a = e.target.closest && e.target.closest("a[href]");
      if (!a || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
      if (a.target && a.target !== "_self") return;
      if (a.hasAttribute("download")) return;
      var url;
      try { url = new URL(a.href, location.href); } catch (err) { return; }
      if (url.origin !== location.origin || !/\.html?$|\/$/.test(url.pathname)) return;
      if (url.pathname === location.pathname && (url.hash || url.search === location.search)) return; // same-page anchor
      e.preventDefault();
      curtain.classList.add("is-active");
      setTimeout(function () { location.href = url.href; }, 420);
    });
    window.addEventListener("pageshow", function (e) { if (e.persisted) curtain.classList.remove("is-active"); });
  }

  /* ---------- generic filter helper used by services/industries/team/jobs ---------- */
  NX.filterable = function (opts) {
    var bar = opts.bar, items = opts.items, status = opts.status, noun = opts.noun || "items";
    if (!bar) return;
    function apply(val) {
      var n = 0;
      items().forEach(function (el) {
        var cats = (el.getAttribute("data-cat") || "").split(" ");
        var show = val === "all" || cats.indexOf(val) > -1;
        el.classList.toggle("is-hidden", !show);
        if (show) { n++; el.classList.remove("fade-up"); void el.offsetWidth; el.classList.add("fade-up"); }
      });
      if (status) status.textContent = "Showing " + n + " " + (n === 1 ? noun.replace(/s$/, "") : noun);
      if (opts.onChange) opts.onChange(val, n);
    }
    bar.addEventListener("click", function (e) {
      var b = e.target.closest("[data-filter]");
      if (!b) return;
      NX.$$("[data-filter]", bar).forEach(function (x) { x.setAttribute("aria-pressed", String(x === b)); });
      apply(b.getAttribute("data-filter"));
    });
    return apply;
  };
  NX.filterButtons = function (list, active) {
    return list.map(function (f) {
      return '<button type="button" class="filter-btn" data-filter="' + NX.esc(f.id) + '" aria-pressed="' + (f.id === (active || "all")) + '">' + NX.esc(f.label) + "</button>";
    }).join("");
  };

  /* Expand/collapse helper for [aria-controls] toggles using the .expand pattern. */
  NX.toggleExpand = function (btn, panel, force) {
    var open = typeof force === "boolean" ? force : btn.getAttribute("aria-expanded") !== "true";
    btn.setAttribute("aria-expanded", String(open));
    panel.classList.toggle("is-open", open);
    // inert keeps hidden content out of the tab order
    if ("inert" in panel) panel.inert = !open;
    return open;
  };

  /* Accessible modal built on the native <dialog> element.
     const m = NX.dialog("article-modal", "Article"); m.open(html, triggerElement); */
  NX.dialog = function (id, label) {
    var d = document.getElementById(id);
    if (d && d._nx) return d._nx;
    d = document.createElement("dialog");
    d.id = id; d.className = "modal"; d.setAttribute("aria-label", label || "Details");
    d.innerHTML = '<div class="modal__panel"><button type="button" class="modal__close" aria-label="Close dialog">' + NX.icon("close") + '</button><div class="modal__content"></div></div>';
    document.body.appendChild(d);
    var content = d.querySelector(".modal__content"), panel = d.querySelector(".modal__panel"), trigger = null;
    function close() { if (d.close) d.close(); else d.removeAttribute("open"); }
    d.querySelector(".modal__close").addEventListener("click", close);
    d.addEventListener("click", function (e) { if (e.target === d) close(); });
    d.addEventListener("close", function () { document.body.classList.remove("no-scroll"); if (trigger && trigger.focus && document.contains(trigger)) trigger.focus({ preventScroll: true }); });
    function open(html, t) {
      trigger = t || document.activeElement;
      content.innerHTML = html;
      if (typeof d.showModal === "function") { if (!d.open) d.showModal(); } else d.setAttribute("open", "");
      document.body.classList.add("no-scroll");
      panel.scrollTop = 0;
    }
    d._nx = { el: d, open: open, close: close, content: content };
    return d._nx;
  };

  /* ---------- boot ---------- */
  function boot() {
    bindConfig();
    var y = NX.$("[data-year]"); if (y) y.textContent = new Date().getFullYear();
    initLoader();
    initTransitions();
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot); else boot();
})();
