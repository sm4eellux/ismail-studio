# NEXORA — Corporate Business Website (demo)

A nine-page, multi-page corporate website for **NEXORA — STRATEGY. INNOVATION. GROWTH.**, a **fictional** consulting company, built as a demonstration project inside the ISMAIL.STUDIO portfolio. Plain HTML5, CSS3 and vanilla JavaScript, plus GSAP/ScrollTrigger and Three.js (loaded from cdnjs). No frameworks, no build step, works on GitHub Pages.

> Everything on the site (company, people, clients, case studies, metrics, articles, vacancies, contact details) is fictional demonstration content and is labelled as such. Do not present it as real.

## 1. Project structure

```
projects/corporate/
├── index.html  services.html  solutions.html  industries.html  about.html
├── team.html   insights.html  contact.html    careers.html
├── css/
│   ├── style.css        tokens (colours/fonts), reset, layout, header, hero, footer, buttons
│   ├── components.css   cards, filters, forms, modals, accordions, tables, page blocks
│   ├── animations.css   keyframes, scroll-reveal, reduced-motion rules
│   └── responsive.css   breakpoints (1280 / 1100 / 1024 / 768 / 480 / 360)
├── js/
│   ├── config.js        ★ contact details, EmailJS, newsletter, 3D settings (edit this first)
│   ├── main.js          shared helpers (window.NX), icons, loader, page transitions, modal helper
│   ├── navigation.js    sticky header, progress bar, mobile menu
│   ├── animations.js    scroll reveal + GSAP/ScrollTrigger enhancements
│   ├── services.js      ★ DATA + rendering: SERVICES, SOLUTIONS, INDUSTRIES
│   ├── insights.js      ★ DATA + rendering: ARTICLES, search, filters, reader modal
│   ├── interactions.js  ★ DATA: TEAM, JOBS; FAQ, form validation, newsletter
│   └── scene.js         Three.js hero scene (homepage only)
└── assets/
    ├── images/          hero fallback, OG image, portfolio previews
    ├── illustrations/   all original vector artwork (services, solutions, industries, portraits…)
    ├── icons/           favicon / logo mark
    └── videos/          empty — drop optional hero/background videos here
```

Navigation, footer and the page `<head>` are repeated in each HTML file (so pages work without JavaScript and are SEO-friendly). To change the nav, edit the `<header>`/mobile menu/footer block in each page.

## 2. Editing the branding

* **Name / tagline:** search for `NEXORA` and `STRATEGY. INNOVATION. GROWTH.` in the HTML files (header, mobile menu, footer, loader) and `js/config.js`.
* **Colours:** the CSS variables at the top of `css/style.css` (`--accent`, `--dark`, `--navy`, `--soft`, …). The illustrations use the same palette baked into the SVGs.
* **Fonts:** Manrope (headings), Inter (body), DM Sans (UI) and Playfair Display (editorial accents) load from Google Fonts in each page `<head>`; the font-family variables are in `style.css`. System fonts are the fallback.
* **Logo / favicon:** `assets/icons/favicon.svg` and `logo-mark.svg`.
* **Social/OG image:** `assets/images/og-image.png` (1200×630). Open Graph crawlers need **absolute** URLs: after deploying, change `og:image` in each page to `https://YOUR-DOMAIN/projects/corporate/assets/images/og-image.png`.

## 3. Replacing images

All artwork is bundled, original vector art — nothing is hot-linked, so there are no broken images. Two ways to swap in real photography:

1. **Same filename:** overwrite a file in `assets/illustrations/` with your own image of the same name (keep the extension the data expects, or update the path).
2. **Per-item `photo` field (recommended):** in `js/services.js`, `js/insights.js` or `js/interactions.js`, add `photo: "assets/images/your-photo.jpg"` to an item. The bundled illustration automatically remains the fallback if the photo fails to load.

   ```js
   { id: "strategy", name: "Business Strategy", image: "assets/illustrations/service-strategy.svg", photo: "assets/images/strategy.jpg", … }
   ```

Photos used on a client site must be licensed (e.g. your own, a stock licence, or Unsplash/Pexels with attribution rules followed). Static page images (about, careers, contact map) are referenced directly in the HTML. Recommended size: 1600×1000 JPG/WebP, under ~250 KB.

## 4. Visual assets & 3D (Three.js)

* The homepage hero is a Three.js scene: a stepped glass-and-metal "growth tower", orbiting rings, satellites, particles and a reflective floor. The mouse moves the camera and lights; scrolling lifts the camera.
* **Settings:** `js/config.js → scene` (`enabled`, `particles`, `accent`, `accent2`, `mouseStrength`, `rotationSpeed`). Set `enabled: false` to always show the static hero.
* **Fallbacks:** if Three.js/WebGL is unavailable, an error occurs, the user prefers reduced motion, or the CDN is blocked, the static `assets/images/hero-fallback.svg` stays visible. Rendering pauses when the hero is off-screen or the tab is hidden; mobile uses fewer particles and no antialiasing.
* **Editing the scene:** `js/scene.js` is commented section by section (materials, tower, rings, satellites, floor, particles, camera).
* **Libraries:** Three.js r128 and GSAP 3.12.5 from cdnjs (same versions the other portfolio projects use). To self-host, download them into `js/vendor/` and change the `<script src>` URLs.

## 5. Editing content

All content lives in plain JavaScript arrays — **no HTML changes needed**.

| What | File | Variable |
|---|---|---|
| Services (name, summary, description, benefits, expertise, related solutions) | `js/services.js` | `SERVICES` (+ `SERVICE_GROUPS` for filter buttons) |
| Solutions (explanation, challenges, benefits, methodology, related services) | `js/services.js` | `SOLUTIONS`, `CHALLENGES` (finder), `COMPARE` (table) |
| Industries (overview, challenges, services, opportunities, recommendations) | `js/services.js` | `INDUSTRIES` (+ `IND_GROUPS`) |
| Team profiles | `js/interactions.js` | `TEAM` (+ `TEAM_GROUPS`) |
| Job listings | `js/interactions.js` | `JOBS` (+ `JOB_GROUPS`) |
| Articles | `js/insights.js` | `ARTICLES`, `CATEGORIES` |
| FAQ, hero copy, case studies, client logos, about copy | the relevant `.html` file | — |

Notes: a `group` value ties an item to a filter button; `related` / `services` arrays use item `id`s; the first article with `featured: true` is the featured post. Article reader links work as `insights.html#article-id`, services as `services.html#strategy`, industries as `industries.html#healthcare`.

## 6. Contact forms, EmailJS and WhatsApp

Edit `js/config.js` → `contact` once; the footer, contact page and form fallbacks all read from it.

**Honest behaviour:** the site never fakes delivery. Forms validate required fields, email, phone, message length (and CV type/size on careers). With no delivery service configured, the user sees a clear *"valid but not sent"* notice, a submission summary, and direct email/WhatsApp alternatives.

**EmailJS (contact form):**
1. Create an account at emailjs.com, add an email service and a template.
2. In the template use these variables: `{{from_name}} {{from_email}} {{company}} {{phone}} {{service}} {{budget}} {{subject}} {{message}}` (set *Reply-To* to `{{reply_to}}`).
3. Put your **public key**, **service ID** and **template ID** into `config.js → emailjs`. The SDK loads on demand only when all three are set; success is shown only after EmailJS confirms.

**Careers form:** EmailJS can't carry the CV file on its free tier, so the form never claims delivery unless you set `config.js → careers.endpoint` to a multipart-capable endpoint (e.g. a Formspree form URL). Without it, applicants get a prefilled `mailto:` instead.

**Newsletter:** set `config.js → newsletter.endpoint` to a URL that accepts `POST {"email": "…"}`; otherwise the form says it is in demo mode and stores nothing.

**WhatsApp:** set `config.js → contact.whatsappNumber` (international format, digits only, e.g. `447700900123`). While empty, the WhatsApp card is shown as "not configured" instead of linking to a fake number.

## 7. Deploying to GitHub Pages

The site uses only relative paths, so it works from a sub-folder. Commit the whole portfolio (including `projects/corporate/`) and enable **Settings → Pages → Deploy from branch** on `main`. The live URL will be `https://<user>.github.io/<repo>/projects/corporate/index.html`. The portfolio's `js/projects.js` already points its "View live website" button there.

## 8. Accessibility & performance notes

Skip link, semantic landmarks, one `<h1>` per page, labelled form fields with inline errors, `aria-expanded` toggles, native `<dialog>` modals with focus return, a focus-trapped mobile menu, visible focus rings, `prefers-reduced-motion` support, content that remains readable without JavaScript. Images are lazy-loaded SVG/JPG; scripts are `defer`red; the 3D scene pauses when not visible.

## 9. Known limits

* Artwork is original vector illustration, not photography — swap in licensed photos as described above.
* Portraits are illustrated placeholders for fictional people.
* Social links are generic platform URLs until you replace them.
