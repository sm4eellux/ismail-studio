/* NOIR — 5-step booking flow. DEMO MODE unless NOIR_CONFIG.booking.endpoint is set. */
(function(){
const D=NOIR_DATA,C=NOIR_CONFIG,$=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const form=$('#booking');if(!form)return;
const S={service:'',barber:'any',date:'',time:''};let step=0;const panes=$$('.pane'),bars=$$('.steps i');
const qs=new URLSearchParams(location.search);
if(qs.get('service'))S.service=qs.get('service');
if(qs.get('barber'))S.barber=qs.get('barber');
if(qs.get('package')){const m={essential:'classic',gentleman:'combo',royal:'royal'};S.service=m[qs.get('package')]}
const svcBox=$('#opt-service'),brbBox=$('#opt-barber'),timeBox=$('#opt-time');
const optHTML=(arr,key)=>arr.map(o=>`<button type="button" class="opt" data-k="${key}" data-v="${o.id}">${o.name}${o.price?` · €${o.price}`:''}</button>`).join('');
svcBox.innerHTML=optHTML(D.services,'service');
brbBox.innerHTML=optHTML([{id:'any',name:'Any Available Barber'},...D.barbers],'barber');
timeBox.innerHTML=['09:00','10:00','11:00','12:00','14:00','15:00','16:00','17:00','18:00'].map(t=>`<button type="button" class="opt" data-k="time" data-v="${t}">${t}</button>`).join('');
const d=$('#date');const t=new Date();d.min=t.toISOString().slice(0,10);
function mark(){$$('.opt').forEach(o=>o.classList.toggle('on',S[o.dataset.k]===o.dataset.v))}
form.addEventListener('click',e=>{const o=e.target.closest('.opt');if(!o)return;S[o.dataset.k]=o.dataset.v;mark();$('#err-'+(o.dataset.k==='time'?'dt':o.dataset.k)).textContent=''});
d.onchange=()=>{S.date=d.value;$('#err-dt').textContent=''};
function show(n){step=n;panes.forEach((p,i)=>p.classList.toggle('on',i===n));bars.forEach((b,i)=>b.classList.toggle('on',i<=n));if(n===4)summary();scrollTo({top:$('.steps').offsetTop-140,behavior:'smooth'})}
function check(){const e=(id,m)=>{$('#err-'+id).textContent=m;return false};
 if(step===0&&!S.service)return e('service','Please choose a service.');
 if(step===1&&!S.barber)return e('barber','Please choose a barber.');
 if(step===2){if(!S.date)return e('dt','Please pick a date.');if(new Date(S.date)<new Date(d.min))return e('dt','Date cannot be in the past.');if(!S.time)return e('dt','Please pick a time.')}
 if(step===3&&!NOIR_validate($('#cust')))return false;return true}
function info(){return NOIR_validate($('#cust'))||{}}
function summary(){const s=D.services.find(x=>x.id===S.service),b=D.barbers.find(x=>x.id===S.barber),c=info();
 S.text=`Booking request — NOIR (DEMO)\nService: ${s.name}\nBarber: ${b?b.name:'Any available'}\nDate: ${S.date} ${S.time}\nName: ${c.name}\nPhone: ${c.phone}\nEmail: ${c.email}\nNotes: ${c.notes||'-'}`;
 $('#sum').innerHTML=`<p><span>Service</span><b>${s.name}</b></p><p><span>Barber</span><b>${b?b.name:'Any Available Barber'}</b></p><p><span>Date</span><b>${S.date}</b></p><p><span>Time</span><b>${S.time}</b></p><p><span>Example price</span><b>€${s.price}</b></p><p><span>Name</span><b>${c.name}</b></p><p><span>Email</span><b>${c.email}</b></p><p><span>Phone</span><b>${c.phone}</b></p>`}
$$('[data-next]').forEach(b=>b.onclick=()=>{if(check())show(step+1)});
$$('[data-prev]').forEach(b=>b.onclick=()=>show(step-1));
$('#confirm').onclick=async()=>{const out=$('#done'),ep=C.booking.endpoint;let sent=false;
 if(ep){try{const r=await fetch(ep,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(S)});sent=r.ok}catch(e){}}
 panes.forEach(p=>p.classList.remove('on'));$('.steps').style.display='none';
 out.classList.add('on');out.innerHTML=sent?`<h2>Request received.</h2><p class="lead">Your request was sent to the shop. They will confirm your time.</p>`
 :`<h2>Demo request prepared.</h2><p class="lead">This website is a demonstration and no booking system is connected, so <b>no appointment was created</b>. To send this request for real, use one of the options below.</p><div class="sum" style="margin-top:24px"><pre style="white-space:pre-wrap;font:inherit;color:var(--muted)">${S.text}</pre></div><div class="row"><a class="btn solid" href="https://wa.me/${C.whatsappNumber}?text=${encodeURIComponent(S.text)}">Send via WhatsApp</a><a class="btn" href="mailto:${C.contact.email}?subject=Booking%20request&body=${encodeURIComponent(S.text)}">Send via Email</a></div>`};
mark();show(0);
})();
