/* NOIR — scroll reveal (GSAP ScrollTrigger when present, IntersectionObserver fallback) + parallax */
(function(){
const reduce=matchMedia('(prefers-reduced-motion:reduce)').matches;
function reveal(){const els=[...document.querySelectorAll('.rv:not(.in)')];
 if(reduce||!('IntersectionObserver' in window)){els.forEach(e=>e.classList.add('in'));return}
 const io=new IntersectionObserver(es=>es.forEach(x=>{if(x.isIntersecting){x.target.classList.add('in');io.unobserve(x.target)}}),{threshold:.12});els.forEach(e=>io.observe(e))}
reveal();document.querySelectorAll('[data-render]').forEach(()=>{});
if(window.gsap&&window.ScrollTrigger&&!reduce){gsap.registerPlugin(ScrollTrigger);
 document.querySelectorAll('[data-par]').forEach(el=>gsap.to(el,{yPercent:-8,ease:'none',scrollTrigger:{trigger:el,scrub:true}}));
 document.querySelectorAll('.eyebrow').forEach(el=>gsap.from(el,{opacity:0,x:-20,duration:.9,scrollTrigger:{trigger:el,start:'top 90%'}}))}
})();
