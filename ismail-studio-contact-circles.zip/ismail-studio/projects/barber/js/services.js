/* NOIR — DATA: services, barbers, packages. Edit text/prices here. Prices are fictional. */
window.NOIR_DATA = {
  img: u => `https://images.unsplash.com/${u}?auto=format&fit=crop&w=1200&q=75`,
  services: [
    {id:"classic",name:"Classic Haircut",cat:"hair",dur:"45 min",price:25,photo:"photo-1503951914875-452162b0f3f1",short:"Traditional barbering with modern precision.",desc:"Consultation, scissor and clipper work, neck shave and a styled finish tailored to your face shape."},
    {id:"fade",name:"Skin Fade",cat:"hair",dur:"50 min",price:30,photo:"photo-1621605815971-fbc98d665033",short:"A clean, detailed fade tailored to your style.",desc:"A seamless gradient from skin to length, blended by hand and finished with precise linework."},
    {id:"beard",name:"Beard Sculpting",cat:"beard",dur:"30 min",price:20,photo:"photo-1599351431202-1e0f0137899a",short:"Professional beard shaping and detailing.",desc:"Contour mapping, trimming, razor-edged lines and conditioning oil."},
    {id:"shave",name:"Hot Towel Shave",cat:"beard",dur:"40 min",price:28,photo:"photo-1585747860715-2ba37e788b70",short:"A traditional shave with premium products.",desc:"Hot towels, pre-shave oil, rich lather and a straight-razor shave, closed with a cooling balm."},
    {id:"combo",name:"Hair & Beard Combo",cat:"ritual",dur:"75 min",price:40,photo:"photo-1503951914875-452162b0f3f1",short:"A complete grooming experience.",desc:"Our premium haircut paired with full beard sculpting and a hot towel finish."},
    {id:"royal",name:"Royal Grooming",cat:"ritual",dur:"120 min",price:65,photo:"photo-1621605815971-fbc98d665033",short:"An exclusive full-service grooming ritual.",desc:"Haircut, beard treatment, hot towel shave, facial grooming and premium products, unhurried."}
  ],
  barbers: [
    {id:"adam",name:"Adam Laurent",spec:"classic",specLabel:"Classic Barbering",yrs:12,photo:"photo-1519085360753-af0119f7cbe7",bio:"Fictional profile. Adam favours scissor work and timeless side-parted cuts.",philosophy:"Restraint is the highest form of style."},
    {id:"karim",name:"Karim Benali",spec:"fade",specLabel:"Modern Fades",yrs:8,photo:"photo-1500648767791-00dcc994a43e",bio:"Fictional profile. Karim is known here for razor-clean blends and sharp lineups.",philosophy:"A fade is geometry you can feel."},
    {id:"lucas",name:"Lucas Moreau",spec:"beard",specLabel:"Beard Design",yrs:10,photo:"photo-1492562080023-ab3db95bfbce",bio:"Fictional profile. Lucas designs beards to frame the jaw and balance the face.",philosophy:"A beard should look grown, never built."}
  ],
  packages: [
    {id:"essential",name:"The Essential",price:25,items:["Classic Haircut","Styling Finish","Professional Consultation"]},
    {id:"gentleman",name:"The Gentleman",price:40,rec:true,items:["Premium Haircut","Beard Sculpting","Hot Towel Treatment","Styling Finish"]},
    {id:"royal",name:"The Royal Experience",price:65,items:["Premium Haircut","Professional Beard Treatment","Hot Towel Shave","Facial Grooming","Premium Grooming Products"]}
  ],
  testimonials: [
    ["Precise, calm and unhurried. The best cut I have had.","Demo Client A"],
    ["The hot towel shave alone is worth the visit.","Demo Client B"],
    ["Feels like a private club, not a salon.","Demo Client C"]
  ]
};
