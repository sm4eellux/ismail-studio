/* NOIR — 3D hero: procedural vintage barber chair on dark marble. Three.js r128 (global THREE).
   Falls back to the static gradient if WebGL is unavailable. Reduced on mobile / reduced-motion. */
(function(){
const cv=document.getElementById('scene');if(!cv)return;
const hero=cv.closest('.hero');
function fail(){document.documentElement.classList.add('no-webgl')}
try{
if(!window.THREE)return fail();
const t=document.createElement('canvas');if(!(t.getContext('webgl')||t.getContext('experimental-webgl')))return fail();
const reduce=matchMedia('(prefers-reduced-motion:reduce)').matches,mobile=innerWidth<768;
const r=new THREE.WebGLRenderer({canvas:cv,antialias:!mobile,alpha:true});
r.setPixelRatio(Math.min(devicePixelRatio,mobile?1.25:2));r.shadowMap.enabled=!mobile;r.shadowMap.type=THREE.PCFSoftShadowMap;
const sc=new THREE.Scene();sc.fog=new THREE.FogExp2(0x080807,.075);
const cam=new THREE.PerspectiveCamera(36,1,.1,60);
const G=new THREE.Group();sc.add(G);
const M=(c,m,ro)=>new THREE.MeshStandardMaterial({color:c,metalness:m,roughness:ro});
const gold=M(0xC6A66B,1,.28),leather=M(0x14110e,.1,.45),dark=M(0x1b1a17,.6,.35),chrome=M(0xb9b6ae,1,.2);
const add=(g,m,x,y,z,p=G)=>{const o=new THREE.Mesh(g,m);o.position.set(x,y,z);o.castShadow=o.receiveShadow=true;p.add(o);return o};
// floor: procedural dark marble checker
const c=document.createElement('canvas');c.width=c.height=512;const x=c.getContext('2d');
for(let i=0;i<8;i++)for(let j=0;j<8;j++){x.fillStyle=(i+j)%2?'#12110f':'#1c1a16';x.fillRect(i*64,j*64,64,64)}
x.strokeStyle='rgba(198,166,107,.08)';for(let k=0;k<40;k++){x.beginPath();x.moveTo(Math.random()*512,0);x.bezierCurveTo(Math.random()*512,170,Math.random()*512,340,Math.random()*512,512);x.stroke()}
const tex=new THREE.CanvasTexture(c);tex.wrapS=tex.wrapT=THREE.RepeatWrapping;tex.repeat.set(5,5);
const fl=new THREE.Mesh(new THREE.CircleGeometry(14,64),new THREE.MeshStandardMaterial({map:tex,metalness:.5,roughness:.18}));fl.rotation.x=-Math.PI/2;fl.receiveShadow=true;sc.add(fl);
// chair
add(new THREE.CylinderGeometry(1.15,1.3,.14,48),dark,0,.07,0);
add(new THREE.TorusGeometry(1.2,.03,12,64),gold,0,.15,0).rotation.x=Math.PI/2;
add(new THREE.CylinderGeometry(.22,.3,.9,32),chrome,0,.6,0);
add(new THREE.CylinderGeometry(.34,.34,.12,32),gold,0,1.1,0);
add(new THREE.BoxGeometry(1.5,.28,1.4),leather,0,1.3,0);               // seat
add(new THREE.BoxGeometry(1.5,.08,1.4),gold,0,1.12,0);
const back=add(new THREE.BoxGeometry(1.4,1.7,.3),leather,0,2.2,-.62);back.rotation.x=-.12;   // back
add(new THREE.BoxGeometry(.7,.45,.28),leather,0,3.2,-.72).rotation.x=-.12;                    // headrest
add(new THREE.CylinderGeometry(.04,.04,.3,12),gold,0,3.0,-.7);
[-1,1].forEach(s=>{add(new THREE.BoxGeometry(.18,.1,1.1),gold,s*.88,1.95,-.05);add(new THREE.BoxGeometry(.2,.62,.2),leather,s*.88,1.62,.35);add(new THREE.BoxGeometry(.2,.62,.2),leather,s*.88,1.62,-.45);add(new THREE.BoxGeometry(.16,.12,1.15),leather,s*.88,1.84,-.05)});
add(new THREE.CylinderGeometry(.05,.05,1,12),chrome,0,.9,.95).rotation.x=.5;
add(new THREE.BoxGeometry(1.1,.1,.55),gold,0,.5,1.25).rotation.x=.2;                          // footrest
G.position.y=0;
// lights
sc.add(new THREE.AmbientLight(0xffffff,.22));
const key=new THREE.SpotLight(0xffe2b0,2.4,30,.5,.6);key.position.set(-4,9,5);key.castShadow=!mobile;key.shadow.mapSize.set(1024,1024);key.target=G;sc.add(key);
const rim=new THREE.PointLight(0xC6A66B,1.8,18);rim.position.set(4,3,-4);sc.add(rim);
const mouseLight=new THREE.PointLight(0xE2C99B,.9,10);mouseLight.position.set(0,3,4);sc.add(mouseLight);
// dust particles
const N=mobile?60:220,pg=new THREE.BufferGeometry(),pp=new Float32Array(N*3);
for(let i=0;i<N*3;i+=3){pp[i]=(Math.random()-.5)*14;pp[i+1]=Math.random()*7;pp[i+2]=(Math.random()-.5)*10}
pg.setAttribute('position',new THREE.BufferAttribute(pp,3));
const dust=new THREE.Points(pg,new THREE.PointsMaterial({color:0xE2C99B,size:.035,transparent:true,opacity:.6}));sc.add(dust);
// interaction
let mx=0,my=0,sy=0;
addEventListener('pointermove',e=>{mx=e.clientX/innerWidth-.5;my=e.clientY/innerHeight-.5},{passive:true});
addEventListener('scroll',()=>{sy=Math.min(scrollY/innerHeight,1)},{passive:true});
function size(){const w=hero.clientWidth,h=hero.clientHeight;r.setSize(w,h,false);cam.aspect=w/h;cam.updateProjectionMatrix();
 G.position.x=w>860?2.2:0;G.scale.setScalar(w>860?1:.8)}
size();addEventListener('resize',size);
let vis=true;new IntersectionObserver(e=>vis=e[0].isIntersecting).observe(hero);
const clk=new THREE.Clock();
function loop(){requestAnimationFrame(loop);if(!vis)return;const t=clk.getElapsedTime();
 if(!reduce)G.rotation.y=t*.18;
 cam.position.x+=((mx*1.6)-cam.position.x)*.04;cam.position.y+=((3.4-my*1.2-sy*1.5)-cam.position.y)*.04;cam.position.z=9.5-sy*1.5;cam.lookAt(G.position.x*.6,1.9,0);
 mouseLight.position.x=mx*8;mouseLight.position.y=3-my*3;
 if(!reduce)dust.rotation.y=t*.01,dust.position.y=Math.sin(t*.3)*.15;
 r.render(sc,cam)}
loop();cv.classList.add('live');hero.classList.add('has-3d');
}catch(e){console.warn('NOIR 3D disabled:',e);fail()}
})();
