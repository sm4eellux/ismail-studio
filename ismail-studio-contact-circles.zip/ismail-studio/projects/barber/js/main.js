/* NOIR — shared UI: loader, nav, data rendering, modals, FAQ, contact form */
(function(){
const D=window.NOIR_DATA,C=window.NOIR_CONFIG,$=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const img=(u,alt)=>`<img src="${D.img(u)}" alt="${alt}" loading="lazy" onerror="this.onerror=null;this.src='assets/images/fallback.svg'">`;
// loader + header
addEventListener('load',()=>setTimeout(()=>{$('#loader')?.classList.add('done');document.body.classList.add('ready')},700));
setTimeout(()=>{$('#loader')?.classList.add('done');document.body.classList.add('ready')},3000); // safety
const h=$('.hdr');const sc=()=>h.classList.toggle('stuck',scrollY>40);sc();addEventListener('scroll',sc,{passive:true});
const nav=$('.nav'),bg=$('.burger');
bg.onclick=()=>{const o=nav.classList.toggle('open');bg.setAttribute('aria-expanded',o);bg.textContent=o?'✕':'☰'};
$$('.nav a').forEach(a=>a.addEventListener('click',()=>nav.classList.remove('open')));
// renderers
const svc=s=>`<article class="card rv"><div class="ph">${img(s.photo,s.name+' at NOIR')}</div><div class="tx"><h3>${s.name}</h3><p>${s.short}</p><div class="meta"><span>${s.dur}</span><span>€${s.price}</span></div><div class="row" style="margin:0"><button class="btn" data-svc="${s.id}">Details</button><a class="btn solid" href="booking.html?service=${s.id}">Book Now</a></div></div></article>`;
const brb=b=>`<article class="card rv"><div class="ph" style="aspect-ratio:4/5">${img(b.photo,'Portrait of fictional barber '+b.name)}</div><div class="tx"><h3>${b.name}</h3><div class="meta"><span>${b.specLabel}</span><span>${b.yrs} yrs (fictional)</span></div><p>${b.bio}</p><div class="row" style="margin:0"><button class="btn" data-brb="${b.id}">Profile</button><a class="btn solid" href="booking.html?barber=${b.id}">Book With ${b.name.split(' ')[0]}</a></div></div></article>`;
const pkg=p=>`<article class="card price rv ${p.rec?'rec':''}" data-pkg="${p.id}">${p.rec?'<span class="tag">RECOMMENDED</span>':''}<h3>${p.name}</h3><div class="big">€${p.price}</div><ul>${p.items.map(i=>`<li>${i}</li>`).join('')}</ul><button class="btn ${p.rec?'solid':''}" data-pick="${p.id}">Select Package</button></article>`;
const R={
 'services-preview':()=>D.services.filter((s,i)=>[0,1,2,5].includes(i)).map(svc).join(''),
 'services':()=>D.services.map(svc).join(''),'barbers':()=>D.barbers.map(brb).join(''),
 'packages':()=>D.packages.map(pkg).join(''),
 'testimonials':()=>D.testimonials.map(t=>`<blockquote class="quote rv">“${t[0]}”<small>${t[1]} · ILLUSTRATIVE</small></blockquote>`).join('')};
$$('[data-render]').forEach(e=>e.innerHTML=R[e.dataset.render]());
// filters
$$('.chips').forEach(c=>c.addEventListener('click',e=>{const b=e.target.closest('.chip');if(!b)return;$$('.chip',c).forEach(x=>x.classList.remove('on'));b.classList.add('on');
 const key=c.dataset.for,list=D[key],f=b.dataset.f,t=$('[data-render="'+key+'"]');
 t.innerHTML=list.filter(x=>f==='all'||(x.cat||x.spec)===f).map(key==='services'?svc:brb).join('');t.querySelectorAll('.rv').forEach(x=>x.classList.add('in'))}));
// modal
const m=$('#modal');
function open(o){m.querySelector('.box').innerHTML=`<button class="x" aria-label="Close">×</button>${img(o.photo,o.name)}<div class="tx"><div class="eyebrow">${o.meta}</div><h3>${o.name}</h3><p class="lead" style="margin:14px 0">${o.text}</p>${o.extra||''}<a class="btn solid" href="${o.href}">${o.cta}</a></div>`;m.classList.add('on');$('.x',m).focus()}
document.addEventListener('click',e=>{const t=e.target;
 if(t.dataset.svc){const s=D.services.find(x=>x.id===t.dataset.svc);open({photo:s.photo,name:s.name,meta:s.dur+' · €'+s.price+' (example)',text:s.desc,href:'booking.html?service='+s.id,cta:'Book Now'})}
 if(t.dataset.brb){const b=D.barbers.find(x=>x.id===t.dataset.brb);open({photo:b.photo,name:b.name,meta:b.specLabel,text:b.bio,extra:`<p class="quote" style="font-size:1.2rem;margin-bottom:20px">“${b.philosophy}”</p><p class="note" style="margin:0 0 20px">Fictional demonstration profile.</p>`,href:'booking.html?barber='+b.id,cta:'Book With This Barber'})}
 if(t.classList.contains('x')||t===m)m.classList.remove('on')});
addEventListener('keydown',e=>e.key==='Escape'&&m.classList.remove('on'));
// pricing selection + dynamic summary
const ps=$('#pkg-summary');
document.addEventListener('click',e=>{const id=e.target.dataset.pick;if(!id)return;if(!ps){location.href='pricing.html';return}const p=D.packages.find(x=>x.id===id);
 $$('[data-pkg]').forEach(x=>x.classList.toggle('sel',x.dataset.pkg===id));
 ps.innerHTML=`<div class="sum"><p><span>Selected package</span><b>${p.name}</b></p><p><span>Example price</span><b>€${p.price}</b></p><p><span>Includes</span><b>${p.items.join(', ')}</b></p></div><div class="row"><a class="btn solid" href="booking.html?package=${p.id}">Continue to Booking</a></div>`});
// FAQ
$$('.faq button').forEach(b=>b.onclick=()=>{b.classList.toggle('open');b.querySelector('span').textContent=b.classList.contains('open')?'−':'+'});
// contact config
$$('[data-cfg]').forEach(e=>{const k=e.dataset.cfg;
 if(k==='address')e.innerHTML=C.contact.address.join('<br>');
 if(k==='phone')e.textContent=C.contact.phone;
 if(k==='email'){e.textContent=C.contact.email;e.href='mailto:'+C.contact.email}
 if(k==='ig')e.href=C.contact.instagram;if(k==='map')e.href=C.contact.mapsLink;
 if(k==='wa')e.href='https://wa.me/'+C.whatsappNumber;
 if(k==='hours')e.innerHTML=C.hours.map(x=>`<li>${x[0]}: ${x[1]}</li>`).join('')});
// contact form
const cf=$('#contact-form');
if(cf)cf.addEventListener('submit',async e=>{e.preventDefault();const v=NOIR_validate(cf);if(!v)return;
 const out=$('#contact-out'),E=C.emailjs,ok=E.publicKey&&E.serviceId&&E.templateId;
 const sum=Object.entries(v).map(([k,x])=>`<p><span>${k}</span><b>${x}</b></p>`).join('');
 if(!ok){out.innerHTML=`<div class="sum">${sum}</div><p class="note">Email delivery is not configured, so nothing was sent. Reach us via <a href="mailto:${C.contact.email}?subject=${encodeURIComponent(v.subject)}&body=${encodeURIComponent(v.message)}" style="color:var(--gold)">email</a> or <a data-cfg="wa" href="https://wa.me/${C.whatsappNumber}" style="color:var(--gold)">WhatsApp</a>.</p>`;return}
 try{await new Promise((r,j)=>{const s=document.createElement('script');s.src='https://cdn.jsdelivr.net/npm/@emailjs/browser@4/dist/email.min.js';s.onload=r;s.onerror=j;document.head.appendChild(s)});
  emailjs.init({publicKey:E.publicKey});await emailjs.send(E.serviceId,E.templateId,v);out.innerHTML=`<div class="sum">${sum}</div><p class="note">Message sent.</p>`}
 catch(x){out.innerHTML=`<p class="note">Sending failed. Please use email or WhatsApp.</p>`}});
// shared validation (used by booking too)
window.NOIR_validate=function(f){let ok=true;const out={};
 $$('[data-req]',f).forEach(i=>{const v=i.value.trim();let m='';const t=i.dataset.req;
  if(!v)m='This field is required.';else if(t==='email'&&!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v))m='Enter a valid email address.';
  else if(t==='phone'&&!/^\+?[0-9 ()-]{7,18}$/.test(v))m='Enter a valid phone number.';
  i.classList.toggle('bad',!!m);i.nextElementSibling.textContent=m;if(m)ok=false;out[i.name]=v});
 $$('[name]:not([data-req])',f).forEach(i=>out[i.name]=i.value.trim());return ok?out:null};
})();
