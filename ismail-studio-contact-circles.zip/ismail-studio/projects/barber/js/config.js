/* NOIR — SITE CONFIGURATION. All values are FICTIONAL DEMO PLACEHOLDERS. Edit here only. */
window.NOIR_CONFIG = {
  contact: {
    address: ["12 Rue de l'Exemple", "00000 Your City, Country"], // placeholder
    phone: "+00 000 000 000", email: "hello@example.com",         // placeholders
    instagram: "https://www.instagram.com/",
    mapsLink: "https://www.google.com/maps/search/?api=1&query=barber+shop"
  },
  whatsappNumber: "000000000000", // digits only, e.g. "212600000000". Placeholder until set.
  hours: [["Monday – Friday","09:00 – 20:00"],["Saturday","09:00 – 18:00"],["Sunday","Closed"]],
  emailjs: { publicKey: "", serviceId: "", templateId: "" }, // contact form sends ONLY if all three are filled
  booking: { endpoint: "" } // optional: URL of a real booking backend. Empty = demo mode
};
