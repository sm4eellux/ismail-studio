# NOIR — The Gentlemen's Barber Club (demo)
Fictional luxury barber site, a portfolio project by ISMAIL.STUDIO. Plain HTML/CSS/JS + Three.js r128 + GSAP (CDN). No build step; works on GitHub Pages (all paths are relative).

## Structure
`index, services, pricing, barbers, about, booking, contact .html` · `css/` (style, animations, 3d, responsive) · `js/` (config, services = data, main, animations, booking, three-scene) · `assets/`.

## Edit things
- **Branding / colours / fonts:** CSS variables at the top of `css/style.css`. Logo text is in each page header and footer.
- **Services, prices, barbers, packages, testimonials:** `js/services.js` (one object, all pages read from it).
- **Images:** photos are Unsplash IDs in `js/services.js` (and `<img>` tags in the pages). Replace with local files in `assets/images/` by changing the `img()` helper or the `src`. Failed images fall back to `assets/images/fallback.svg`. **Check Unsplash licensing and that every URL loads before publishing.**
- **Contact details, hours, WhatsApp, Instagram, Maps:** `js/config.js` only. Set `whatsappNumber` (digits only).
- **Booking:** demo mode by default: nothing is created, the confirmation screen says so and offers WhatsApp/email. To go live, set `booking.endpoint` in `config.js` to a backend that accepts the JSON POST (service, barber, date, time + customer text).
- **EmailJS:** fill `publicKey`, `serviceId`, `templateId` in `config.js`. Template variables: `name, email, phone, subject, message`. Until all three are set the form shows a summary and email/WhatsApp fallbacks and sends nothing.
- **3D scene:** `js/three-scene.js`. The chair is built from primitives (no model file). To use a glTF model, add the GLTFLoader and load it from `assets/models/`, replacing the chair block. Lights, particles and mobile reductions are in the same file. Falls back to a static gradient without WebGL.
- **Deploy:** commit the folder; GitHub Pages serves it at `/projects/barber/index.html`.

## Notes
All names, prices, testimonials and contact data are fictional placeholders.
