/* ==========================================================================
   MAISON ÉLÉGANCE — SITE CONFIGURATION
   Edit this single file to change contact details, hours, WhatsApp number,
   EmailJS credentials and the photography used across the whole website.
   All values below are FICTIONAL DEMO PLACEHOLDERS.
   ========================================================================== */

window.SITE_CONFIG = {
  brand: {
    name: "MAISON ÉLÉGANCE",
    tagline: "An Artful Expression of Fine Dining.",
    demoNotice: "Demonstration project — all content is fictional."
  },

  contact: {
    address: ["12 Rue de l'Exemple", "00000 Your City, Country"],   // placeholder
    phone: "+00 000 000 000",                                        // placeholder
    email: "hello@example.com",                                      // placeholder
    instagram: "https://www.instagram.com/",                         // replace with real profile
    // Google Maps link (search link works without any API key)
    mapsLink: "https://www.google.com/maps/search/?api=1&query=fine+dining+restaurant",
    // Optional embed URL (leave "" to show the styled location card only)
    mapsEmbed: ""
  },

  // WhatsApp number: international format, digits only, no "+" or spaces.
  // Example: "212600000000". Leave placeholder until you have a real number.
  whatsappNumber: "000000000000",

  hours: [
    { days: "Tuesday – Thursday", time: "18:00 – 22:30" },
    { days: "Friday – Saturday",  time: "18:00 – 23:30" },
    { days: "Sunday",             time: "12:00 – 16:00" },
    { days: "Monday",             time: "Closed" }
  ],

  /* EmailJS (optional). The contact form only sends if ALL three are filled in.
     Otherwise it shows a configuration message and email / WhatsApp fallbacks. */
  emailjs: {
    publicKey: "",
    serviceId: "",
    templateId: ""
  },

  /* Photography. Remote photos (Unsplash) are used for the demo.
     Every <img> falls back to a local SVG in assets/images/ if a photo fails.
     To use your own photos, drop files in assets/images/ and change the
     paths here AND in the HTML pages (see README). */
  images: {
    base: "https://images.unsplash.com/photo-",
    ids: {
      hero:      "1517248135467-4c7edcad34c4",
      interior1: "1555396273-367ea4eb4db5",
      interior2: "1466978913421-dad2ebd01d17",
      interior3: "1559339352-11d035aa65de",
      dish1:     "1414235077428-338989a2e8c0",
      dish2:     "1551218808-94e220e084d2",
      dish3:     "1476224203421-9ac39bcb3327",
      dish4:     "1504674900247-0877df9cc836",
      dish5:     "1544025162-d76694265947",
      dish6:     "1600891964092-4316c288032e",
      dessert1:  "1578985545062-69928b1d9587",
      salad1:    "1540189549336-e6e99c3679fe",
      drink1:    "1551024709-8f23befc6f87",
      drink2:    "1470337458703-46ad1756a187",
      kitchen1:  "1556910103-1c02745aae4d",
      kitchen2:  "1519708227418-c8fd9a32b7a2",
      table1:    "1485182708500-e8f1f318ba72"
    }
  }
};

/* Helper: build an image URL from a key, e.g. meImg("hero", 1600) */
window.meImg = function (key, width) {
  var c = window.SITE_CONFIG.images;
  return c.base + c.ids[key] + "?auto=format&fit=crop&w=" + (width || 1200) + "&q=75";
};
