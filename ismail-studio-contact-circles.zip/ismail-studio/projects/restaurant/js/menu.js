/* ==========================================================================
   MAISON ÉLÉGANCE — MENU
   All dishes live in the MENU_ITEMS array below. To add, edit or remove a
   dish, change only that array. Everything is SAMPLE (fictional) content.

   Fields:
     id        unique string
     category  "starters" | "mains" | "desserts" | "beverages"
     name, description, price (number)
     image     key from SITE_CONFIG.images.ids (js/config.js) OR a local/remote URL
     tags      optional array, e.g. ["Vegetarian", "Gluten-free", "Vegan", "Alcohol-free"]
   ========================================================================== */
(function () {
  "use strict";

  var CURRENCY = "€";   // change the currency symbol here

  var CATEGORIES = [
    { id: "all", label: "All Dishes" },
    { id: "starters", label: "Starters" },
    { id: "mains", label: "Main Courses" },
    { id: "desserts", label: "Desserts" },
    { id: "beverages", label: "Beverages" }
  ];

  var CATEGORY_LABEL = { starters: "Starter", mains: "Main Course", desserts: "Dessert", beverages: "Beverage" };

  var MENU_ITEMS = [
    // ---- Starters ----
    { id: "s1", category: "starters", name: "Scallop Crudo", description: "Thinly sliced scallop, pomelo, yuzu dressing and sea herbs.", price: 24, image: "dish1", tags: ["Gluten-free"] },
    { id: "s2", category: "starters", name: "Heirloom Beetroot", description: "Roasted beetroot, whipped goat cheese, toasted walnut, aged balsamic.", price: 19, image: "salad1", tags: ["Vegetarian"] },
    { id: "s3", category: "starters", name: "Wild Mushroom Velouté", description: "Silky forest mushroom soup, truffle oil and warm brioche.", price: 18, image: "dish3", tags: ["Vegetarian"] },
    { id: "s4", category: "starters", name: "Tuna Tartare", description: "Hand-cut tuna, avocado, cucumber, citrus soy and sesame crisp.", price: 23, image: "dish2", tags: [] },
    // ---- Main courses ----
    { id: "m1", category: "mains", name: "Dry-Aged Beef Fillet", description: "Bone-marrow jus, charred shallot and silky potato purée.", price: 52, image: "dish5", tags: ["Gluten-free"] },
    { id: "m2", category: "mains", name: "Herb-Crusted Lamb Rack", description: "Garden herbs, roasted garlic and rosemary reduction.", price: 48, image: "dish6", tags: [] },
    { id: "m3", category: "mains", name: "Roasted Sea Bass", description: "Saffron beurre blanc, braised fennel and sea herbs.", price: 44, image: "dish4", tags: ["Gluten-free"] },
    { id: "m4", category: "mains", name: "Wild Mushroom Risotto", description: "Carnaroli rice, forest mushrooms, aged parmesan and chive oil.", price: 34, image: "dish3", tags: ["Vegetarian", "Gluten-free"] },
    // ---- Desserts ----
    { id: "d1", category: "desserts", name: "Dark Chocolate Sphere", description: "Valrhona-style dark chocolate shell, warm salted caramel poured at the table.", price: 18, image: "dessert1", tags: ["Vegetarian"] },
    { id: "d2", category: "desserts", name: "Vanilla Crème Brûlée", description: "Madagascar vanilla custard with a glass-thin caramelised crust.", price: 15, image: "dessert1", tags: ["Vegetarian", "Gluten-free"] },
    { id: "d3", category: "desserts", name: "Seasonal Fruit Tart", description: "Buttery pastry, light crème pâtissière and the best fruit of the week.", price: 16, image: "dish1", tags: ["Vegetarian"] },
    // ---- Beverages ----
    { id: "b1", category: "beverages", name: "Maison Champagne Cocktail", description: "Sparkling wine, sugar cube, bitters and a twist of orange.", price: 22, image: "drink1", tags: ["Contains alcohol"] },
    { id: "b2", category: "beverages", name: "Barrel-Aged Negroni", description: "Gin, vermouth and bitter aperitif, softly rounded in oak.", price: 20, image: "drink2", tags: ["Contains alcohol"] },
    { id: "b3", category: "beverages", name: "Elderflower Sparkle", description: "House elderflower cordial, lemon and sparkling water.", price: 10, image: "drink1", tags: ["Alcohol-free", "Vegan"] },
    { id: "b4", category: "beverages", name: "Cold-Brew Tonic", description: "Slow cold-brew coffee over tonic, orange peel and ice.", price: 12, image: "drink2", tags: ["Alcohol-free", "Vegan"] }
  ];

  /* ---------- Rendering ---------- */
  var grid = document.getElementById("menu-grid");
  var filtersEl = document.getElementById("menu-filters");
  var searchEl = document.getElementById("menu-search");
  var countEl = document.getElementById("menu-count");
  var emptyEl = document.getElementById("menu-empty");
  if (!grid || !filtersEl) return;

  var state = { category: "all", query: "" };
  var reduceMotion = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  /* Resolve an image key from config, or use the value as a URL/path */
  function imageUrl(img) {
    var ids = window.SITE_CONFIG && window.SITE_CONFIG.images.ids;
    if (ids && ids[img] && typeof window.meImg === "function") return window.meImg(img, 800);
    return img;
  }

  function formatPrice(n) { return CURRENCY + Number(n).toFixed(Number.isInteger(n) ? 0 : 2); }

  function card(item) {
    var tags = (item.tags || []).map(function (t) { return '<span class="tag">' + esc(t) + "</span>"; }).join("");
    return (
      '<article class="dish" data-id="' + esc(item.id) + '">' +
      '<div class="frame"><img src="' + esc(imageUrl(item.image)) + '" alt="' + esc(item.name) + ' — sample dish photograph" loading="lazy" data-fallback="dish"></div>' +
      '<p class="dish__cat">' + esc(CATEGORY_LABEL[item.category] || item.category) + "</p>" +
      '<div class="dish__top"><h3>' + esc(item.name) + '</h3><span class="dish__price">' + formatPrice(item.price) + "</span></div>" +
      "<p>" + esc(item.description) + "</p>" +
      (tags ? '<div class="dish__tags">' + tags + "</div>" : "") +
      "</article>"
    );
  }

  function matches(item) {
    if (state.category !== "all" && item.category !== state.category) return false;
    var q = state.query.trim().toLowerCase();
    if (!q) return true;
    var hay = (item.name + " " + item.description + " " + (item.tags || []).join(" ")).toLowerCase();
    return hay.indexOf(q) !== -1;
  }

  function render() {
    var list = MENU_ITEMS.filter(matches);
    grid.innerHTML = list.map(card).join("");
    if (typeof window.meCheckImages === "function") window.meCheckImages(grid);
    countEl.textContent = list.length + (list.length === 1 ? " dish" : " dishes");
    emptyEl.classList.toggle("is-visible", list.length === 0);

    // Smooth entrance for the freshly rendered cards
    var cards = grid.querySelectorAll(".dish");
    if (reduceMotion) return;
    cards.forEach(function (el, i) {
      el.classList.add("is-entering");
      el.style.transitionDelay = Math.min(i * 60, 480) + "ms";
    });
    requestAnimationFrame(function () {
      requestAnimationFrame(function () {
        cards.forEach(function (el) { el.classList.remove("is-entering"); });
        // Clear stagger delays once the entrance is done so filtering stays snappy
        setTimeout(function () { cards.forEach(function (el) { el.style.transitionDelay = ""; }); }, 1100);
      });
    });
  }

  /* Fade current cards out, then render the new set */
  function update() {
    if (reduceMotion) { render(); return; }
    var current = grid.querySelectorAll(".dish");
    current.forEach(function (el) { el.style.transitionDelay = ""; el.classList.add("is-hiding"); });
    setTimeout(render, current.length ? 280 : 0);
  }

  function buildFilters() {
    filtersEl.innerHTML = CATEGORIES.map(function (c) {
      var on = c.id === state.category;
      return '<button type="button" class="filter-btn' + (on ? " is-active" : "") + '" data-cat="' + c.id + '" aria-pressed="' + on + '">' + esc(c.label) + "</button>";
    }).join("");
  }

  filtersEl.addEventListener("click", function (e) {
    var btn = e.target.closest(".filter-btn");
    if (!btn) return;
    state.category = btn.getAttribute("data-cat");
    filtersEl.querySelectorAll(".filter-btn").forEach(function (b) {
      var on = b === btn;
      b.classList.toggle("is-active", on);
      b.setAttribute("aria-pressed", String(on));
    });
    update();
  });

  if (searchEl) {
    var timer;
    searchEl.addEventListener("input", function () {
      clearTimeout(timer);
      timer = setTimeout(function () { state.query = searchEl.value; update(); }, 180);
    });
  }

  buildFilters();
  render();

  // Expose data for testing/debugging
  window.MENU_ITEMS = MENU_ITEMS;
})();
