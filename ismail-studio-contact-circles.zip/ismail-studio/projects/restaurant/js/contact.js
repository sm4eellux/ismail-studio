/* ==========================================================================
   MAISON ÉLÉGANCE — CONTACT PAGE
   - Fills contact details, hours and map from js/config.js (single source)
   - Contact form: sends through EmailJS ONLY when fully configured.
     Otherwise it never pretends to send; it shows a clear configuration
     message plus email / WhatsApp alternatives with the message prefilled.
   ========================================================================== */
(function () {
  "use strict";

  var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

  /* ---------- Pure helpers (also exported for Node tests) ---------- */
  function validate(v) {
    var e = {};
    var name = (v.name || "").trim(), email = (v.email || "").trim();
    var subject = (v.subject || "").trim(), message = (v.message || "").trim();
    if (name.length < 2) e.name = "Please enter your name.";
    else if (name.length > 80) e.name = "Name must be 80 characters or fewer.";
    if (!email) e.email = "Please enter your email address.";
    else if (!EMAIL_RE.test(email) || email.length > 120) e.email = "Please enter a valid email address.";
    if (subject.length < 3) e.subject = "Please add a short subject (3+ characters).";
    else if (subject.length > 120) e.subject = "Subject must be 120 characters or fewer.";
    if (message.length < 10) e.message = "Please write a message of at least 10 characters.";
    else if (message.length > 2000) e.message = "Message must be 2000 characters or fewer.";
    return e;
  }

  function emailJsConfigured(cfg) {
    var j = (cfg && cfg.emailjs) || {};
    return !!(j.publicKey && j.serviceId && j.templateId);
  }

  function whatsappUrl(cfg, text) {
    var n = (cfg.whatsappNumber || "").replace(/\D/g, "");
    var ok = /^\d{8,15}$/.test(n) && !/^0+$/.test(n);
    return (ok ? "https://wa.me/" + n : "https://wa.me/") + "?text=" + encodeURIComponent(text);
  }

  function composeText(v) {
    return "Subject: " + v.subject.trim() + "\n\n" + v.message.trim() + "\n\n— " + v.name.trim() + " (" + v.email.trim() + ")";
  }

  var api = { validate: validate, emailJsConfigured: emailJsConfigured, whatsappUrl: whatsappUrl, composeText: composeText };
  if (typeof module === "object" && module.exports) module.exports = api;
  if (typeof document === "undefined") return;
  window.MEContact = api;

  var CFG = window.SITE_CONFIG;
  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  /* ---------- Details, hours, map ---------- */
  var waValid = /^\d{8,15}$/.test((CFG.whatsappNumber || "").replace(/\D/g, "")) && !/^0+$/.test(CFG.whatsappNumber);
  var details = document.getElementById("contact-details");
  if (details) {
    var c = CFG.contact;
    var waHref = whatsappUrl(CFG, "Hello Maison Élégance, I would like to ask a question.");
    details.innerHTML =
      '<li><span class="k">Address</span><span>' + c.address.map(esc).join("<br>") + "</span></li>" +
      '<li><span class="k">Phone</span><a href="tel:' + esc(c.phone.replace(/[^\d+]/g, "")) + '">' + esc(c.phone) + "</a></li>" +
      '<li><span class="k">Email</span><a href="mailto:' + esc(c.email) + '">' + esc(c.email) + "</a></li>" +
      '<li id="whatsapp"><span class="k">WhatsApp</span><span><a href="' + esc(waHref) + '" target="_blank" rel="noopener noreferrer">Message us on WhatsApp</a>' +
      (waValid ? "" : '<br><small class="muted">Demo: number not configured yet.</small>') + "</span></li>" +
      '<li><span class="k">Instagram</span><a href="' + esc(c.instagram) + '" target="_blank" rel="noopener noreferrer">Follow on Instagram</a></li>' +
      '<li><span class="k">Maps</span><a href="' + esc(c.mapsLink) + '" target="_blank" rel="noopener noreferrer">Open in Google Maps</a></li>';
  }
  var hoursEl = document.getElementById("contact-hours");
  if (hoursEl) {
    hoursEl.innerHTML = CFG.hours.map(function (h) {
      return "<li><span>" + esc(h.days) + "</span><span>" + esc(h.time) + "</span></li>";
    }).join("");
  }
  var addrEl = document.getElementById("location-address");
  if (addrEl) addrEl.innerHTML = CFG.contact.address.map(esc).join("<br>");
  var mapBox = document.getElementById("map-box");
  var mapLink = document.getElementById("map-link");
  if (mapLink) mapLink.href = CFG.contact.mapsLink;
  if (mapBox && CFG.contact.mapsEmbed) {
    mapBox.innerHTML = '<iframe src="' + esc(CFG.contact.mapsEmbed) + '" title="Restaurant location map" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>';
  }

  /* ---------- Contact form ---------- */
  var form = document.getElementById("contact-form");
  if (!form) return;
  var FIELDS = ["name", "email", "subject", "message"];
  var els = {};
  FIELDS.forEach(function (f) { els[f] = document.getElementById("c-" + f); });
  var statusEl = document.getElementById("c-status");
  var submitBtn = document.getElementById("c-submit");
  var honeypot = document.getElementById("c-website");
  var configured = emailJsConfigured(CFG);
  var sdkPromise = null;

  function setError(f, msg) {
    els[f].closest(".field").classList.toggle("has-error", !!msg);
    els[f].setAttribute("aria-invalid", msg ? "true" : "false");
    document.getElementById("cerr-" + f).textContent = msg || "";
  }
  FIELDS.forEach(function (f) {
    els[f].addEventListener("input", function () { if (els[f].getAttribute("aria-invalid") === "true") setError(f, ""); });
  });

  function showStatus(kind, html) {
    statusEl.className = "notice" + (kind === "ok" ? " notice--ok" : kind === "warn" ? " notice--warn" : "");
    statusEl.innerHTML = html;
    statusEl.hidden = false;
    statusEl.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }

  function loadSdk() {
    if (window.emailjs) return Promise.resolve(window.emailjs);
    if (sdkPromise) return sdkPromise;
    sdkPromise = new Promise(function (resolve, reject) {
      var s = document.createElement("script");
      s.src = "https://cdn.jsdelivr.net/npm/@emailjs/browser@4/dist/email.min.js";
      s.onload = function () { window.emailjs ? resolve(window.emailjs) : reject(new Error("EmailJS did not load")); };
      s.onerror = function () { reject(new Error("EmailJS could not be loaded")); };
      document.head.appendChild(s);
    });
    return sdkPromise;
  }

  function fallbackHtml(v, intro) {
    var text = composeText(v);
    var mail = "mailto:" + encodeURIComponent(CFG.contact.email).replace(/%40/g, "@") +
      "?subject=" + encodeURIComponent(v.subject.trim()) + "&body=" + encodeURIComponent(text);
    return "<strong>" + intro + "</strong><br>You can still reach us right now:" +
      '<div class="alt-contact"><a class="btn btn--sm" href="' + esc(mail) + '">Send by email</a>' +
      '<a class="btn btn--sm" href="' + esc(whatsappUrl(CFG, text)) + '" target="_blank" rel="noopener noreferrer">Send via WhatsApp</a></div>';
  }

  var sending = false;
  form.addEventListener("submit", function (e) {
    e.preventDefault();
    if (honeypot && honeypot.value) return;
    if (sending) return;   // no duplicate submissions

    var v = {};
    FIELDS.forEach(function (f) { v[f] = els[f].value; });
    var errors = validate(v);
    FIELDS.forEach(function (f) { setError(f, errors[f]); });
    var bad = FIELDS.filter(function (f) { return errors[f]; })[0];
    if (bad) { els[bad].focus(); return; }

    if (!configured) {
      // Honest behaviour: nothing was sent.
      showStatus("warn", fallbackHtml(v, "Online sending is not configured yet, so your message has NOT been sent."));
      return;
    }

    sending = true;
    submitBtn.disabled = true;
    submitBtn.textContent = "Sending…";
    loadSdk().then(function (emailjs) {
      emailjs.init({ publicKey: CFG.emailjs.publicKey });
      return emailjs.send(CFG.emailjs.serviceId, CFG.emailjs.templateId, {
        from_name: v.name.trim(), reply_to: v.email.trim(), from_email: v.email.trim(),
        subject: v.subject.trim(), message: v.message.trim()
      });
    }).then(function () {
      form.reset();
      showStatus("ok", "<strong>Thank you.</strong> Your message has been sent. We will reply to you by email.");
    }).catch(function () {
      showStatus("warn", fallbackHtml(v, "We could not send your message online."));
    }).then(function () {
      sending = false;
      submitBtn.disabled = false;
      submitBtn.textContent = "Send Message";
    });
  });
})();
