/* ==========================================================================
   MAISON ÉLÉGANCE — MAIN SCRIPT (shared by every page)
   - Injects the shared header + footer (edit them once, here)
   - Scroll-aware header, active link, mobile menu
   - Scroll reveal, image fallback, optional GSAP parallax
   Requires js/config.js to be loaded first.
   ========================================================================== */
(function () {
  "use strict";

  var CFG = window.SITE_CONFIG;
  var body = document.body;
  var currentPage = body.getAttribute("data-page") || "home";
  document.documentElement.classList.add("js");

  /* Escape text before putting it into HTML */
  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  /* ---------- Navigation data ---------- */
  var NAV = [
    { id: "home", label: "Home", href: "index.html" },
    { id: "menu", label: "Menu", href: "menu.html" },
    { id: "about", label: "Our Story", href: "about.html" },
    { id: "gallery", label: "Gallery", href: "gallery.html" },
    { id: "reservations", label: "Reservations", href: "reservations.html" },
    { id: "contact", label: "Contact", href: "contact.html" }
  ];

  /* ---------- Header ---------- */
  function buildHeader() {
    var host = document.getElementById("site-header");
    if (!host) return;
    var links = NAV.map(function (n) {
      var active = n.id === currentPage;
      return '<a href="' + n.href + '"' + (active ? ' class="is-active" aria-current="page"' : "") + ">" + n.label + "</a>";
    }).join("");
    var parts = CFG.brand.name.split(" ");
    host.className = "site-header" + (body.hasAttribute("data-solid-header") ? " is-solid" : "");
    host.innerHTML =
      '<div class="container nav">' +
      '<a class="logo" href="index.html" aria-label="' + esc(CFG.brand.name) + ' — home">' +
      esc(parts[0]) + " <span>" + esc(parts.slice(1).join(" ")) + "</span></a>" +
      '<nav class="nav-links" id="primary-nav" aria-label="Main navigation">' + links +
      '<a class="btn btn--sm nav-links__cta" href="reservations.html">Reserve a Table</a></nav>' +
      '<a class="btn btn--sm nav-cta" href="reservations.html">Reserve a Table</a>' +
      '<button class="nav-toggle" type="button" aria-expanded="false" aria-controls="primary-nav" aria-label="Open menu"><span></span></button>' +
      "</div>";

    var toggle = host.querySelector(".nav-toggle");
    var nav = host.querySelector(".nav-links");

    function setMenu(open) {
      nav.classList.toggle("is-open", open);
      toggle.setAttribute("aria-expanded", String(open));
      toggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
      body.classList.toggle("menu-open", open);
      host.classList.toggle("menu-open", open);
    }
    toggle.addEventListener("click", function () { setMenu(!nav.classList.contains("is-open")); });
    nav.addEventListener("click", function (e) { if (e.target.closest("a")) setMenu(false); });
    document.addEventListener("keydown", function (e) { if (e.key === "Escape") setMenu(false); });
    window.addEventListener("resize", function () { if (window.innerWidth > 1100) setMenu(false); });

    function onScroll() { host.classList.toggle("is-scrolled", window.scrollY > 40); }
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
  }

  /* ---------- Footer ---------- */
  function buildFooter() {
    var host = document.getElementById("site-footer");
    if (!host) return;
    var c = CFG.contact;
    var wa = CFG.whatsappNumber && /^\d{8,15}$/.test(CFG.whatsappNumber) && !/^0+$/.test(CFG.whatsappNumber)
      ? "https://wa.me/" + CFG.whatsappNumber : "contact.html#whatsapp";
    var hours = CFG.hours.map(function (h) {
      return "<li><span>" + esc(h.days) + "</span><span>" + esc(h.time) + "</span></li>";
    }).join("");
    var links = NAV.map(function (n) { return '<li><a href="' + n.href + '">' + n.label + "</a></li>"; }).join("");
    host.className = "site-footer";
    host.innerHTML =
      '<div class="container"><div class="footer-grid">' +
      '<div class="footer-brand"><a class="logo" href="index.html">' + esc(CFG.brand.name) + "</a>" +
      "<p>Contemporary gastronomy, exceptional ingredients and an unhurried evening. " + esc(CFG.brand.demoNotice) + "</p></div>" +
      "<div><h4>Explore</h4><ul>" + links + "</ul></div>" +
      "<div><h4>Opening Hours</h4><ul class=\"hours\">" + hours + "</ul></div>" +
      "<div><h4>Visit &amp; Connect</h4><ul>" +
      "<li>" + c.address.map(esc).join("<br>") + "</li>" +
      '<li><a href="tel:' + esc(c.phone.replace(/[^\d+]/g, "")) + '">' + esc(c.phone) + "</a></li>" +
      '<li><a href="mailto:' + esc(c.email) + '">' + esc(c.email) + "</a></li>" +
      '<li><a href="' + esc(c.instagram) + '" target="_blank" rel="noopener noreferrer">Instagram</a> · ' +
      '<a href="' + wa + '" target="_blank" rel="noopener noreferrer">WhatsApp</a></li></ul></div>' +
      "</div>" +
      '<div class="footer-bottom"><span>&copy; ' + new Date().getFullYear() + " " + esc(CFG.brand.name) + ". Fictional demo restaurant.</span>" +
      "<span>Website design &amp; development: ISMAIL.STUDIO</span></div></div>";
  }

  /* ---------- Image fallback (never leave a broken image) ---------- */
  var FALLBACKS = {
    interior: "assets/images/fallback-interior.svg",
    dish: "assets/images/fallback-dish.svg",
    table: "assets/images/fallback-table.svg"
  };
  function applyFallback(img) {
    if (img.dataset.fellBack || img.hasAttribute("data-own-fallback")) return;
    img.dataset.fellBack = "1";
    img.removeAttribute("srcset");
    img.src = FALLBACKS[img.getAttribute("data-fallback")] || FALLBACKS.interior;
  }
  window.meApplyFallback = applyFallback;
  document.addEventListener("error", function (e) {
    if (e.target && e.target.tagName === "IMG") applyFallback(e.target);
  }, true);
  function checkImages(root) {
    (root || document).querySelectorAll("img").forEach(function (img) {
      if (img.complete && img.naturalWidth === 0 && img.getAttribute("src")) applyFallback(img);
    });
  }
  window.meCheckImages = checkImages;

  /* ---------- Scroll reveal ---------- */
  function initReveal() {
    var els = document.querySelectorAll("[data-reveal], [data-curtain]");
    if (!els.length) return;
    if (!("IntersectionObserver" in window)) {
      els.forEach(function (el) { el.classList.add("is-visible"); });
      return;
    }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add("is-visible"); io.unobserve(en.target); }
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -6% 0px" });
    els.forEach(function (el) { io.observe(el); });
    /* Safety net: never leave content hidden */
    setTimeout(function () {
      els.forEach(function (el) { if (!el.classList.contains("is-visible") && el.getBoundingClientRect().top < window.innerHeight) el.classList.add("is-visible"); });
    }, 1800);
  }
  window.meReveal = function (root) {
    (root || document).querySelectorAll("[data-reveal]").forEach(function (el) { el.classList.add("is-visible"); });
  };

  /* ---------- Optional GSAP parallax (graceful if GSAP is not loaded) ---------- */
  function initParallax() {
    var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce || !window.gsap || !window.ScrollTrigger) return;
    window.gsap.registerPlugin(window.ScrollTrigger);
    document.querySelectorAll("[data-parallax]").forEach(function (el) {
      window.gsap.fromTo(el, { yPercent: -6 }, {
        yPercent: 6, ease: "none",
        scrollTrigger: { trigger: el.parentElement, start: "top bottom", end: "bottom top", scrub: true }
      });
    });
  }

  /* ---------- Init ---------- */
  buildHeader();
  buildFooter();
  document.addEventListener("DOMContentLoaded", function () {
    checkImages();
    initReveal();
    initParallax();
  });
  window.addEventListener("load", function () { checkImages(); });
})();
