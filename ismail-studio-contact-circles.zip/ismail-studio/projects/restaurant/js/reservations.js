/* ==========================================================================
   MAISON ÉLÉGANCE — RESERVATIONS
   Static-site friendly: the form is validated in the browser, then a
   formatted message is opened in WhatsApp for the visitor to send manually.
   There is NO booking database, NO live availability and NO automatic
   confirmation — the restaurant confirms by replying on WhatsApp.
   ========================================================================== */
(function () {
  "use strict";

  /* ------------------------------------------------------------------
     CONFIGURATION — edit these values
     ------------------------------------------------------------------ */
  var RESERVATION_CONFIG = {
    // Restaurant WhatsApp number: international format, DIGITS ONLY
    // (no "+", spaces or dashes). Example: "212600000000".
    // Leave "" to use SITE_CONFIG.whatsappNumber from js/config.js.
    whatsappNumber: "",

    restaurantName: "MAISON ÉLÉGANCE",
    minGuests: 1,
    maxGuests: 10,          // larger groups should contact the restaurant
    maxDaysAhead: 180,      // how far in advance a request can be made
    closedWeekdays: [1],    // 0 = Sunday ... 6 = Saturday (1 = Monday closed). Keep in sync with opening hours.
    minLeadMinutes: 60,     // for same-day requests, time slots must be at least this far away
    timeSlots: ["12:00", "12:30", "13:00", "13:30", "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30", "22:00"],
    duplicateCooldownMs: 30000 // identical requests inside this window are not re-sent
  };

  /* ------------------------------------------------------------------
     PURE HELPERS (no DOM) — also exported for testing in Node
     ------------------------------------------------------------------ */
  var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  var NAME_RE = /^[\p{L}][\p{L}\p{M}\s'.\-]{1,79}$/u;
  var PHONE_ALLOWED_RE = /^[+]?[\d\s().\-]+$/;

  function pad(n) { return (n < 10 ? "0" : "") + n; }

  function parseDate(str) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(str || "");
    if (!m) return null;
    var y = +m[1], mo = +m[2], d = +m[3];
    var dt = new Date(y, mo - 1, d);
    if (dt.getFullYear() !== y || dt.getMonth() !== mo - 1 || dt.getDate() !== d) return null;
    return dt;
  }

  function startOfDay(dt) { return new Date(dt.getFullYear(), dt.getMonth(), dt.getDate()); }
  function toISODate(dt) { return dt.getFullYear() + "-" + pad(dt.getMonth() + 1) + "-" + pad(dt.getDate()); }

  /* Returns an object of { field: "message" }. Empty object = valid. */
  function validate(values, now, cfg) {
    cfg = cfg || RESERVATION_CONFIG;
    now = now || new Date();
    var errors = {};
    var v = values;

    var name = (v.name || "").trim();
    if (!name) errors.name = "Please enter your full name.";
    else if (!NAME_RE.test(name)) errors.name = "Please enter a valid name (letters only, 2–80 characters).";

    var email = (v.email || "").trim();
    if (!email) errors.email = "Please enter your email address.";
    else if (email.length > 120 || !EMAIL_RE.test(email)) errors.email = "Please enter a valid email address, e.g. name@example.com.";

    var phone = (v.phone || "").trim();
    var digits = phone.replace(/\D/g, "");
    if (!phone) errors.phone = "Please enter your phone number.";
    else if (!PHONE_ALLOWED_RE.test(phone) || digits.length < 7 || digits.length > 15)
      errors.phone = "Please enter a valid phone number (7–15 digits, e.g. +33 1 23 45 67 89).";

    var date = parseDate(v.date);
    if (!v.date) errors.date = "Please choose a reservation date.";
    else if (!date) errors.date = "Please enter a valid date.";
    else {
      var today = startOfDay(now);
      var latest = new Date(today.getFullYear(), today.getMonth(), today.getDate() + cfg.maxDaysAhead);
      if (date < today) errors.date = "Reservation dates cannot be in the past.";
      else if (date > latest) errors.date = "Requests can be made up to " + cfg.maxDaysAhead + " days in advance.";
      else if (cfg.closedWeekdays.indexOf(date.getDay()) !== -1) errors.date = "The restaurant is closed on this day. Please choose another date.";
    }

    if (!v.time) errors.time = "Please choose a preferred time.";
    else if (cfg.timeSlots.indexOf(v.time) === -1) errors.time = "Please choose one of the available time slots.";
    else if (date && !errors.date) {
      var hm = v.time.split(":");
      var when = new Date(date.getFullYear(), date.getMonth(), date.getDate(), +hm[0], +hm[1]);
      if (when.getTime() < now.getTime() + cfg.minLeadMinutes * 60000)
        errors.time = "Please choose a later time — requests need at least " + cfg.minLeadMinutes + " minutes' notice.";
    }

    var g = Number(v.guests);
    if (!v.guests) errors.guests = "Please select the number of guests.";
    else if (!Number.isInteger(g) || g < cfg.minGuests || g > cfg.maxGuests)
      errors.guests = "We accept online requests for " + cfg.minGuests + "–" + cfg.maxGuests + " guests. For larger groups, please contact us.";

    if ((v.requests || "").length > 500) errors.requests = "Special requests must be 500 characters or fewer.";

    return errors;
  }

  function formatDateLong(dt) {
    return dt.toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
  }

  /* Build the plain-text WhatsApp message */
  function buildMessage(v, cfg) {
    cfg = cfg || RESERVATION_CONFIG;
    var date = parseDate(v.date);
    var lines = [
      "*Reservation request — " + cfg.restaurantName + "*",
      "",
      "Name: " + v.name.trim(),
      "Email: " + v.email.trim(),
      "Phone: " + v.phone.trim(),
      "Date: " + (date ? formatDateLong(date) : v.date),
      "Time: " + v.time,
      "Guests: " + v.guests,
      "Special requests: " + ((v.requests || "").trim() || "None"),
      "",
      "Please let me know if this table is available. Thank you."
    ];
    return lines.join("\n");
  }

  function validNumber(num) {
    return /^\d{8,15}$/.test(num || "") && !/^0+$/.test(num);
  }

  function buildWhatsAppUrl(number, message) {
    var base = validNumber(number) ? "https://wa.me/" + number : "https://wa.me/";
    return base + "?text=" + encodeURIComponent(message);
  }

  var api = {
    config: RESERVATION_CONFIG, validate: validate, buildMessage: buildMessage,
    buildWhatsAppUrl: buildWhatsAppUrl, validNumber: validNumber, parseDate: parseDate, toISODate: toISODate
  };
  if (typeof module === "object" && module.exports) module.exports = api;
  if (typeof document === "undefined") return;
  window.MEReservations = api;

  /* ------------------------------------------------------------------
     DOM BEHAVIOUR
     ------------------------------------------------------------------ */
  var form = document.getElementById("reservation-form");
  if (!form) return;

  var FIELDS = ["name", "email", "phone", "date", "time", "guests", "requests"];
  var els = {};
  FIELDS.forEach(function (f) { els[f] = document.getElementById("res-" + f); });
  var submitBtn = document.getElementById("res-submit");
  var summary = document.getElementById("res-summary");
  var summaryList = document.getElementById("res-summary-list");
  var notice = document.getElementById("res-notice");
  var warn = document.getElementById("res-warning");
  var waLink = document.getElementById("res-wa-link");
  var copyBtn = document.getElementById("res-copy");
  var editBtn = document.getElementById("res-edit");
  var honeypot = document.getElementById("res-website");
  var counter = document.getElementById("res-counter");
  var lastSignature = null, lastTime = 0, lastMessage = "";

  function whatsappNumber() {
    var n = (RESERVATION_CONFIG.whatsappNumber || (window.SITE_CONFIG && window.SITE_CONFIG.whatsappNumber) || "").replace(/\D/g, "");
    return n;
  }

  /* Populate time and guest selects from the config */
  RESERVATION_CONFIG.timeSlots.forEach(function (t) {
    var o = document.createElement("option"); o.value = t; o.textContent = t; els.time.appendChild(o);
  });
  for (var i = RESERVATION_CONFIG.minGuests; i <= RESERVATION_CONFIG.maxGuests; i++) {
    var o = document.createElement("option"); o.value = String(i); o.textContent = i + (i === 1 ? " guest" : " guests"); els.guests.appendChild(o);
  }
  /* Date limits */
  var todayDt = startOfDay(new Date());
  els.date.min = toISODate(todayDt);
  els.date.max = toISODate(new Date(todayDt.getFullYear(), todayDt.getMonth(), todayDt.getDate() + RESERVATION_CONFIG.maxDaysAhead));

  function values() {
    var v = {};
    FIELDS.forEach(function (f) { v[f] = els[f].value; });
    return v;
  }

  function showError(field, msg) {
    var wrap = els[field].closest(".field");
    var out = document.getElementById("err-" + field);
    wrap.classList.toggle("has-error", !!msg);
    els[field].setAttribute("aria-invalid", msg ? "true" : "false");
    out.textContent = msg || "";
  }

  function showErrors(errors) {
    FIELDS.forEach(function (f) { showError(f, errors[f]); });
  }

  // Clear a field's error as soon as the visitor edits it
  FIELDS.forEach(function (f) {
    ["input", "change"].forEach(function (evt) {
      els[f].addEventListener(evt, function () { if (els[f].getAttribute("aria-invalid") === "true") showError(f, ""); });
    });
  });
  // Validate on blur for immediate feedback
  FIELDS.forEach(function (f) {
    els[f].addEventListener("blur", function () {
      if (!els[f].value && !els[f].required) return;
      var e = validate(values());
      if (els[f].value || e[f]) showError(f, e[f]);
    });
  });
  if (counter) els.requests.addEventListener("input", function () { counter.textContent = els.requests.value.length + " / 500"; });

  function renderSummary(v) {
    var date = parseDate(v.date);
    var rows = [
      ["Name", v.name.trim()], ["Email", v.email.trim()], ["Phone", v.phone.trim()],
      ["Date", date ? formatDateLong(date) : v.date], ["Time", v.time], ["Guests", v.guests],
      ["Requests", (v.requests || "").trim() || "None"]
    ];
    summaryList.innerHTML = "";
    rows.forEach(function (r) {
      var div = document.createElement("div");
      var dt = document.createElement("dt"); dt.textContent = r[0];
      var dd = document.createElement("dd"); dd.textContent = r[1];   // textContent: safe against HTML injection
      div.appendChild(dt); div.appendChild(dd); summaryList.appendChild(div);
    });
  }

  form.addEventListener("submit", function (e) {
    e.preventDefault();

    // Honeypot: bots fill hidden fields. Silently ignore.
    if (honeypot && honeypot.value) return;
    if (submitBtn.disabled) return;   // prevents double submissions

    var v = values();
    var errors = validate(v);
    showErrors(errors);
    var firstBad = FIELDS.filter(function (f) { return errors[f]; })[0];
    if (firstBad) { els[firstBad].focus(); return; }

    var signature = JSON.stringify(v);
    var duplicate = signature === lastSignature && Date.now() - lastTime < RESERVATION_CONFIG.duplicateCooldownMs;

    var number = whatsappNumber();
    var configured = validNumber(number);
    lastMessage = buildMessage(v);
    var url = buildWhatsAppUrl(number, lastMessage);

    renderSummary(v);
    waLink.href = url;
    warn.hidden = configured;
    notice.hidden = false;
    form.hidden = true;
    summary.classList.add("is-visible");
    summary.scrollIntoView({ behavior: "smooth", block: "start" });

    // Brief lock so a double-click cannot open WhatsApp twice
    submitBtn.disabled = true;
    setTimeout(function () { submitBtn.disabled = false; }, 4000);

    if (!duplicate) {
      lastSignature = signature; lastTime = Date.now();
      window.open(url, "_blank", "noopener");   // opened from a user action, so popup blockers allow it
    }
  });

  if (editBtn) editBtn.addEventListener("click", function () {
    summary.classList.remove("is-visible");
    form.hidden = false;
    els.name.focus();
  });

  if (copyBtn) copyBtn.addEventListener("click", function () {
    function done(ok) {
      copyBtn.textContent = ok ? "Message copied" : "Copy failed — select the text manually";
      setTimeout(function () { copyBtn.textContent = "Copy message"; }, 2500);
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(lastMessage).then(function () { done(true); }, function () { done(false); });
    } else {
      done(false);
    }
  });
})();
