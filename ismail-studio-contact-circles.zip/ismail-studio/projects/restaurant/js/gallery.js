/* ==========================================================================
   MAISON ÉLÉGANCE — GALLERY
   - Category filter
   - Accessible lightbox: click to open, Next/Prev, arrow keys,
     Escape closes, focus is trapped and restored, touch swipe.
   ========================================================================== */
(function () {
  "use strict";

  var grid = document.getElementById("gallery-grid");
  var lb = document.getElementById("lightbox");
  if (!grid || !lb) return;

  var filters = document.getElementById("gallery-filters");
  var lbImg = document.getElementById("lb-img");
  var lbCap = document.getElementById("lb-caption");
  var lbCount = document.getElementById("lb-count");
  var btnClose = document.getElementById("lb-close");
  var btnPrev = document.getElementById("lb-prev");
  var btnNext = document.getElementById("lb-next");
  var allItems = Array.prototype.slice.call(grid.querySelectorAll(".g-item"));
  var current = 0;
  var lastFocus = null;
  var FALLBACKS = {
    interior: "assets/images/fallback-interior.svg",
    dish: "assets/images/fallback-dish.svg",
    table: "assets/images/fallback-table.svg"
  };

  /* Only the currently visible (filtered) items take part in navigation */
  function visibleItems() {
    return allItems.filter(function (el) { return !el.classList.contains("is-hidden"); });
  }

  /* ---------- Filtering ---------- */
  if (filters) {
    filters.addEventListener("click", function (e) {
      var btn = e.target.closest(".filter-btn");
      if (!btn) return;
      var f = btn.getAttribute("data-filter");
      filters.querySelectorAll(".filter-btn").forEach(function (b) {
        var on = b === btn;
        b.classList.toggle("is-active", on);
        b.setAttribute("aria-pressed", String(on));
      });
      allItems.forEach(function (el) {
        el.classList.toggle("is-hidden", !(f === "all" || el.getAttribute("data-cat") === f));
      });
    });
  }

  /* ---------- Lightbox ---------- */
  function show(index) {
    var list = visibleItems();
    if (!list.length) return;
    current = (index + list.length) % list.length;
    var item = list[current];
    var thumb = item.querySelector("img");
    var caption = item.getAttribute("data-caption") || "";

    lbImg.removeAttribute("data-fell-back");
    lbImg.onerror = function () {
      // Large image failed: fall back to the thumbnail, then to the local SVG
      lbImg.onerror = function () { lbImg.onerror = null; lbImg.src = FALLBACKS[item.getAttribute("data-fallback")] || FALLBACKS.interior; };
      lbImg.src = thumb.currentSrc || thumb.src;
    };
    lbImg.src = item.getAttribute("data-full") || thumb.src;
    lbImg.alt = thumb.alt;
    lbCap.textContent = caption;
    lbCount.textContent = (current + 1) + " / " + list.length;
    var multi = list.length > 1;
    btnPrev.style.display = btnNext.style.display = multi ? "" : "none";
  }

  function open(item) {
    lastFocus = document.activeElement;
    var list = visibleItems();
    show(list.indexOf(item));
    lb.classList.add("is-open");
    lb.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
    btnClose.focus();
  }

  function close() {
    lb.classList.remove("is-open");
    lb.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }

  function isOpen() { return lb.classList.contains("is-open"); }

  grid.addEventListener("click", function (e) {
    var item = e.target.closest(".g-item");
    if (item) open(item);
  });
  btnClose.addEventListener("click", close);
  btnPrev.addEventListener("click", function () { show(current - 1); });
  btnNext.addEventListener("click", function () { show(current + 1); });
  lb.addEventListener("click", function (e) { if (e.target === lb) close(); });

  document.addEventListener("keydown", function (e) {
    if (!isOpen()) return;
    if (e.key === "Escape") { close(); }
    else if (e.key === "ArrowRight") { show(current + 1); }
    else if (e.key === "ArrowLeft") { show(current - 1); }
    else if (e.key === "Tab") {
      // Keep keyboard focus inside the dialog
      var focusables = [btnClose, btnPrev, btnNext].filter(function (b) { return b.style.display !== "none"; });
      var first = focusables[0], last = focusables[focusables.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });

  /* Touch swipe */
  var startX = null;
  lb.addEventListener("touchstart", function (e) { startX = e.changedTouches[0].clientX; }, { passive: true });
  lb.addEventListener("touchend", function (e) {
    if (startX === null) return;
    var dx = e.changedTouches[0].clientX - startX;
    if (Math.abs(dx) > 50) show(current + (dx < 0 ? 1 : -1));
    startX = null;
  }, { passive: true });
})();
